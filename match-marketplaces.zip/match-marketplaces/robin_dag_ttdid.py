"""
Runs the apnids process and stats for the ID Graph.
"""

import json
import logging
import sys
import time
import datetime

# from datetime import datetime, timedelta
from pathlib import Path

from airflow import DAG
from airflow.operators.python import PythonOperator, get_current_context
from airflow.operators.email import EmailOperator
from airflow.models.param import Param
from airflow.operators.empty import EmptyOperator

sys.path.append(str(Path(__file__).resolve().parents[1]) + "/shared")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(funcName)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)

import shared.functions as sf
import shared.bucket_list as bl
import shared.utils.utils as sut

EMAIL_LIST = ["robin.potter@experian.com"]

def check_file_exists(bucket_name, prefix, pattern, xcom, file_not_folder=False):
    """
    Checks if the latest file exists in the given S3 bucket and prefix based on the pattern.
    logs an exception if the file is not found.
    """
    try:
        latest_file = sf.latest_path(bucket_name, prefix, pattern, is_pattern_parent_directory_name=not file_not_folder)
        logging.info(f"Latest file found: {latest_file}")
        context = get_current_context()
        context["ti"].xcom_push(key=xcom, value=latest_file)
        return latest_file
    except ValueError as e:
        logging.error(f"Exception {e}")
        logging.error(f"Missing file with pattern '{pattern}' in bucket '{bucket_name}' and prefix '{prefix}'")
        raise

with DAG(
    "marketplaces-ttdid-process",
    description="Process Marketplace data for Tradedesk ID",
    schedule_interval= "0 1 * * 0",# every sunday at 1am
    start_date=datetime.datetime(2023, 1, 1),
    catchup=False,
    params={
        "mask": Param(
            default=datetime.datetime.now().strftime("%Y-%m-%d"),
            type="string",
            format="date",
            description="Date on which process is run in format YYYY-MM-DD",
        ),
    },
) as dag:

    # task 1 - to check if a new metadata files is available in the bucket "client_delivery" in the taxonomy path with the pattern ttdid_marketplacefile
    # task 2 (dependant on task 1)- to read the data and format it and output to "output" bucket marketplaces/ttdid/metadata/{date_str}/ path
    # task 3 - to check if a new metadata files is available in the bucket "client_delivery" in the taxonomy path with the pattern ttdda_marketplacefile
    # task 4 (dependant on task 3) - to read the data and format it and output to "output" bucket marketplaces/ttdda/metadata/{date_str}/ path
    # task 5 (runs after 2 and 4 have completed, or not needed after 1 and 3) - to generate the data for TTDID from the metadata files output above using the functions in ems-code-shared\src\shared\marketplaces\graph_extract.py
    # task 6 (runs after 5) - to make copies of some of the TTDID files based on the list in ttdda where the number of the code is equivalent

    #task 1
    def check_for_new_ttdid_metadata_files(**context):
        bucket_name = bl.get_bucket_name("client_delivery")
        path = "taxonomy/"
        import shared.functions as sf
        try:
            new_metadata = sf.latest_path(bucket_name, path, "ttdid_marketplacefile", False)
        except Exception as e:
            logging.warning(f"bucket {bucket_name} - {e}")
            new_metadata = None
        if new_metadata:
            logging.info(f"New metadata file found: {new_metadata}")
            context["ti"].xcom_push(
                key="new_ttdid_metadata_file",
                value=new_metadata
            )
            return True
        else:
            logging.info("No new metadata file found.")
            return False

    task_check_for_new_ttdid_metadata_files = PythonOperator(
        task_id="check_for_new_ttdid_metadata_files",
        python_callable=check_for_new_ttdid_metadata_files,
        dag=dag,
    )

    # create emr serverless application using create_emr_application from shared.util.emr_application_factory
    def initialise_emr(**context):
        """
        Initialises the EMR application.
        """

        from shared.utils.emr_application_factory import create_emr_application

        logging.info(f"context is {context}")
        logging.info("Initialising EMR")
        emr_init_start = time.time()

        app_id =  create_emr_application(
            context, "marketplaces-ttdid", None, None #emr_subnet_ids, emr_security_group_ids
        )
        logging.info(f"Created EMR application {app_id}")

        context["task_instance"].xcom_push(
            key="application_id", value=app_id
        )
        context["task_instance"].xcom_push(
            key="emr_start_time", value=emr_init_start
        )
        emr_init_end = time.time()
        logging.info(
            f"Initialisation finished, created {app_id}, time taken: {datetime.timedelta(seconds=emr_init_end - emr_init_start)}"
        )
        return "Setup EMR application successfully"

    task_create_emr_app = PythonOperator(
        task_id="initialise",
        python_callable=initialise_emr,
        trigger_rule="one_success",  # Run if at least one upstream task succeeded
        dag=dag,
    )

    #task 2
    def process_ttdid_metadata_file(**context):
        new_metadata = context["ti"].xcom_pull(
            key="new_ttdid_metadata_file",
            task_ids="check_for_new_ttdid_metadata_files"
        )
        if not new_metadata:
            logging.info("No new metadata file to process.")
            return

        # runs pyspark job ti00_generate_metadata.py
        from shared.utils.emr_application_factory import start_emr_job
        start_time = time.time()

        env = sf.get_env()
        output_bucket = bl.get_bucket_name("output", env)
        execution_role_arn = sut.get_emr_serverless_role(env)
        log_bucket = bl.get_bucket_name("logs", env)
        code_bucket = bl.get_bucket_name("code", env)
        log_uri = f"s3://{log_bucket}/spark-logs/marketplaces/ttdid/{datetime.datetime.now().strftime('%Y-%m-%d')}/"
        code = (
            f"s3://{code_bucket}/zipped/ems-code-shared.zip,"
            f"s3://{code_bucket}/zipped/ems-code-marketplaces-tradedesk-id.zip,"
            f"s3://{code_bucket}/zipped/openpyxl.zip"
            # f"s3://{code_bucket}/zipped/s3fs.zip,"
            # f"s3://{code_bucket}/zipped/aiobotocore.zip,"
            # f"s3://{code_bucket}/zipped/aiohttp.zip,"
            # f"s3://{code_bucket}/zipped/remaining.zip"
        )
        libs = f"s3://{code_bucket}/zipped/openpyxl_blowfish.zip#venv"
        temp_bucket = bl.get_bucket_name("temp", env)
        email_data_key = f"marketplaces/ttdid/{datetime.datetime.now().strftime('%Y-%m-%d')}"

        job_script = f"s3://{code_bucket}/repos/ems-code-marketplaces-tradedesk-id/spark/process/ti00_generate_metadata.py"
        job_driver_arguments = [
            "--mask", context["params"]["mask"],
            "--email_data_bucket", temp_bucket,
            "--email_data_key", email_data_key,
            "--metadata_file", new_metadata,
            "--output_file", f"s3://{output_bucket}/marketplaces/ttdid/metadata/{datetime.datetime.now().strftime('%Y-%m-%d')}",
            "--segment_prefix", "SU",
            "--taxonomy_filter", "ttdid_marketplacefile",
        ]

        app_id = context["ti"].xcom_pull(
            key="application_id", task_ids="initialise"
        )

        spark_submit_params = f"--conf spark.submit.pyFiles={code}"
        if libs:
            spark_submit_params += f" --archives {libs}"
            #spark_submit_params += " --conf spark.pyspark.python=./venv/bin/python --conf spark.pyspark.driver.python=./venv/bin/python"

        logging.info(f"Starting EMR job {job_script} with args {job_driver_arguments} and spark_submit_params {spark_submit_params}")

        job = start_emr_job(
            task_id=f"process_ttdid_metadata_file",
            application_id=f"{app_id}",
            execution_role_arn=f"{execution_role_arn}",
            job_driver={
                "sparkSubmit": {
                    "entryPoint": job_script,
                    "entryPointArguments": job_driver_arguments,
                    "sparkSubmitParameters": spark_submit_params,
                },
            },
            configuration_overrides={
            "monitoringConfiguration": {
                "s3MonitoringConfiguration": {
                "logUri": log_uri,
                },
            }
            },
        )
        logging.info(f"created task {job}")

        job_id = job.execute(get_current_context())

        end_time = time.time()
        logging.info(
            f"Process finished, time taken: {datetime.timedelta(seconds=end_time - start_time)}"
        )

        s3 = sf.get_s3_client()

        subject = s3.get_object(
            Bucket=bl.get_bucket_name("temp", env),
            Key=f"{email_data_key}/subject.txt"
        )["Body"].read().decode('utf-8')

        html_content = s3.get_object(
            Bucket=bl.get_bucket_name("temp", env),
            Key=f"{email_data_key}/body.txt"
        )["Body"].read().decode('utf-8')

        email_op = EmailOperator(
            task_id="send_ttdids_quick_stats_email_report",
            to=EMAIL_LIST,
            subject=subject,
            html_content=html_content,
            dag=dag
        )

        email_op.execute(get_current_context())

        return f"Executed script... {job_id}"

    task_process_ttdid_metadata_file = PythonOperator(
        task_id="process_ttdid_metadata_file",
        python_callable=process_ttdid_metadata_file,
        trigger_rule="all_done",  # Run even if upstream just completes (will skip internally if no file)
        dag=dag,
    )

    #task 3
    def check_for_new_ttdda_metadata_files(**context):
        bucket_name = bl.get_bucket_name("client_delivery")
        path = "taxonomy/"
        import shared.functions as sf
        try:
            new_metadata = sf.latest_path(bucket_name, path, "ttdda_marketplacefile", False)
        except Exception as e:
            logging.warning(f"bucket {bucket_name} - {e}")
            new_metadata = None
        if new_metadata:
            logging.info(f"New metadata file found: {new_metadata}")
            context["ti"].xcom_push(
                key="new_ttdda_metadata_file",
                value=new_metadata
            )
            return True
        else:
            logging.info("No new metadata file found.")
            return False

    task_check_for_new_ttdda_metadata_files = PythonOperator(
        task_id="check_for_new_ttdda_metadata_files",
        python_callable=check_for_new_ttdda_metadata_files,
        dag=dag,
    )

    #task 4
    def process_ttdda_metadata_file(**context):
        new_metadata = context["ti"].xcom_pull(
            key="new_ttdda_metadata_file",
            task_ids="check_for_new_ttdda_metadata_files"
        )
        if not new_metadata:
            logging.info("No new metadata file to process.")
            return

        # runs pyspark job ti00_generate_metadata.py
        from shared.utils.emr_application_factory import start_emr_job
        start_time = time.time()

        env = sf.get_env()
        output_bucket = bl.get_bucket_name("output", env)
        execution_role_arn = sut.get_emr_serverless_role(env)
        log_bucket = bl.get_bucket_name("logs", env)
        code_bucket = bl.get_bucket_name("code", env)
        log_uri = f"s3://{log_bucket}/spark-logs/marketplaces/ttdda/{datetime.datetime.now().strftime('%Y-%m-%d')}/"
        code = (
            f"s3://{code_bucket}/zipped/ems-code-shared.zip,"
            f"s3://{code_bucket}/zipped/ems-code-marketplaces-tradedesk-id.zip,"
            f"s3://{code_bucket}/zipped/openpyxl.zip"
            # f"s3://{code_bucket}/zipped/awswrangler.zip"
            # f"s3://{code_bucket}/zipped/fsspec.zip,"
            # f"s3://{code_bucket}/zipped/s3fs.zip,"
            # f"s3://{code_bucket}/zipped/aiobotocore.zip,"
            # f"s3://{code_bucket}/zipped/aiohttp.zip,"
            # f"s3://{code_bucket}/zipped/remaining.zip"

        )
        libs = f"s3://{code_bucket}/zipped/openpyxl_blowfish.zip#venv"
        temp_bucket = bl.get_bucket_name("temp", env)
        email_data_key = f"marketplaces/ttdda/{datetime.datetime.now().strftime('%Y-%m-%d')}"

        job_script = f"s3://{code_bucket}/repos/ems-code-marketplaces-tradedesk-id/spark/process/ti00_generate_metadata.py"
        job_driver_arguments = [
            "--mask", context["params"]["mask"],
            "--email_data_bucket", temp_bucket,
            "--email_data_key", email_data_key,
            "--metadata_file", new_metadata,
            "--output_file", f"s3://{output_bucket}/marketplaces/ttdda/metadata/{datetime.datetime.now().strftime('%Y-%m-%d')}",
            "--segment_prefix", "DA",
            "--skiprows", "1",  # Skip the first row if needed
            "--taxonomy_filter", "ttdda_marketplacefile",
        ]

        app_id = context["ti"].xcom_pull(
            key="application_id", task_ids="initialise"
        )

        spark_submit_params = f"--conf spark.submit.pyFiles={code}"
        if libs:
            spark_submit_params += f" --archives {libs}"
            #spark_submit_params += " --conf spark.pyspark.python=./venv/bin/python --conf spark.pyspark.driver.python=./venv/bin/python"

        logging.info(f"Starting EMR job {job_script} with args {job_driver_arguments} and spark_submit_params {spark_submit_params}")

        job = start_emr_job(
            task_id=f"process_ttdda_metadata_file",
            application_id=f"{app_id}",
            execution_role_arn=f"{execution_role_arn}",
            job_driver={
                "sparkSubmit": {
                    "entryPoint": job_script,
                    "entryPointArguments": job_driver_arguments,
                    "sparkSubmitParameters": spark_submit_params,
                },
            },
            configuration_overrides={
            "monitoringConfiguration": {
                "s3MonitoringConfiguration": {
                "logUri": log_uri,
                },
            }
            },
        )
        logging.info(f"created task {job}")

        job_id = job.execute(get_current_context())

        end_time = time.time()
        logging.info(
            f"Process finished, time taken: {datetime.timedelta(seconds=end_time - start_time)}"
        )

        s3 = sf.get_s3_client()

        subject = s3.get_object(
            Bucket=bl.get_bucket_name("temp", env),
            Key=f"{email_data_key}/subject.txt"
        )["Body"].read().decode('utf-8')

        html_content = s3.get_object(
            Bucket=bl.get_bucket_name("temp", env),
            Key=f"{email_data_key}/body.txt"
        )["Body"].read().decode('utf-8')

        email_op = EmailOperator(
            task_id="send_ttdda_quick_stats_email_report",
            to=EMAIL_LIST,
            subject=subject,
            html_content=html_content,
            dag=dag
        )

        email_op.execute(context=context)

        return f"Executed script... {job_id}"

    task_process_ttdda_metadata_file = PythonOperator(
        task_id="process_ttdda_metadata_file",
        python_callable=process_ttdda_metadata_file,
        trigger_rule="all_done",  # Run even if upstream just completes (will skip internally if no file)
        dag=dag,
    )

    #tas4.5

    env = sf.get_env()

    check_metadata_file_ttdids = PythonOperator(
        task_id="check_metadata_file_ttdids",
        python_callable=check_file_exists,
        op_kwargs={
            "bucket_name": bl.get_bucket_name("output", env),
            "prefix": "marketplaces/ttdid/metadata/",
            "pattern": "ttdid_marketplacefile_",
            "file_not_folder": True,
            "xcom": "check_metadata_file_ttdids",
        },
        dag=dag
    )

    check_uid_graph_file = PythonOperator(
        task_id="check_uid_graph_file",
        python_callable=check_file_exists,
        op_kwargs={
            "bucket_name": bl.get_bucket_name("idgraph", env),
            "prefix": "uid",
            "pattern": "uid_",
            "file_not_folder": False,
            "xcom": "check_uid_graph_file",
        },
        dag=dag
    )

    check_maids_graph_file = PythonOperator(
        task_id="check_maids_graph_file",
        python_callable=check_file_exists,
        op_kwargs={
            "bucket_name": bl.get_bucket_name("idgraph", env),
            "prefix": "maids",
            "pattern": "maids_",
            "file_not_folder": False,
            "xcom": "check_maids_graph_file",
        },
        dag=dag
    )

    check_ttdids_graph_file = PythonOperator(
        task_id="check_ttdids_graph_file",
        python_callable=check_file_exists,
        op_kwargs={
            "bucket_name": bl.get_bucket_name("idgraph", env),
            "prefix": "ttdids",
            "pattern": "ttdids_",
            "file_not_folder": False,
            "xcom": "check_ttdids_graph_file",
        },
        dag=dag
    )

    check_experian_taxonomy_file = PythonOperator(
        task_id="check_experian_taxonomy_file",
        python_callable=check_file_exists,
        op_kwargs={
            "bucket_name": bl.get_bucket_name("interim", env),
            "prefix": "taxonomy",
            "pattern": "dt_long_cb_key_hh_s",
            "file_not_folder": False,
            "xcom": "check_experian_taxonomy_file",
        },
        dag=dag
    )

    check_match_id_lookup_file = PythonOperator(
        task_id="check_match_id_lookup_file",
        python_callable=check_file_exists,
        op_kwargs={
            "bucket_name": bl.get_bucket_name("lookup", env),
            "prefix": "id_graph/experian",
            "pattern": "match_id_lookup_experian",
            "file_not_folder": False,
            "xcom": "check_match_id_lookup_file",
        },
        dag=dag
    )

    #task 5
    def process_ttdid_data(**context):
        """
        Processes TTDID data using metadata files generated in previous steps.
        Uses the latest metadata file from the output bucket using sf.latest_path().
        """
        # Import needed libraries
        from shared.utils.emr_application_factory import start_emr_job
        start_time = time.time()

        # Set up environment variables
        env = sf.get_env()
        temp_output_bucket = bl.get_bucket_name("temp", env)
        execution_role_arn = sut.get_emr_serverless_role(env)
        log_bucket = bl.get_bucket_name("logs", env)
        code_bucket = bl.get_bucket_name("code", env)
        temp_bucket = bl.get_bucket_name("temp", env)
        log_uri = f"s3://{log_bucket}/spark-logs/marketplaces/ttdid/data/{datetime.datetime.now().strftime('%Y-%m-%d')}/"
        mask = context["params"]["mask"]

        # Set up metadata file paths

        # Set up code libraries and dependencies
        code = (
            f"s3://{code_bucket}/zipped/ems-code-shared.zip,"
            f"s3://{code_bucket}/zipped/ems-code-marketplaces-tradedesk-id.zip"
        )

        # Set up email notification path
        email_data_key = f"marketplaces/ttdid/data/{datetime.datetime.now().strftime('%Y-%m-%d')}"

        metadata_file = context["ti"].xcom_pull(
            key="check_metadata_file_ttdids",
            task_ids="check_metadata_file_ttdids"
        )

        logging.info(f"hello this is metadata_file: {metadata_file}")
        output_bucket = bl.get_bucket_name("output", env)

        latest_taxonomy_file = context["ti"].xcom_pull(
            key="check_experian_taxonomy_file",
            task_ids="check_experian_taxonomy_file"
        )

        latest_match_id_lookup_file = context["ti"].xcom_pull(
            key="check_match_id_lookup_file",
            task_ids="check_match_id_lookup_file"
        )

        latest_uid_graph_file = context["ti"].xcom_pull(
            key="check_uid_graph_file",
            task_ids="check_uid_graph_file"
        )

        latest_maids_graph_file = context["ti"].xcom_pull(
            key="check_maids_graph_file",
            task_ids="check_maids_graph_file"
        )

        latest_ttids_graph_file = context["ti"].xcom_pull(
            key="check_ttdids_graph_file",
            task_ids="check_ttdids_graph_file"
        )

        # Set up job script and arguments
        job_script = f"s3://{code_bucket}/repos/ems-code-marketplaces-tradedesk-id/spark/process/ti01_generate_data.py"
        job_driver_arguments = [
            "--mask", mask,
            "--email_data_bucket", temp_bucket,
            "--temp_bucket", temp_bucket,
            "--email_data_key", email_data_key,
            "--metadata_file", metadata_file,
            "--output_prefix", f"s3://{temp_output_bucket}/marketplaces/ttdid/data/{mask}",
            "--experian_taxonomy_file", latest_taxonomy_file,
            "--match_id_lookup_experian_file", latest_match_id_lookup_file,
            "--uid_graph_file", latest_uid_graph_file,
            "--days_filter", "30",  # Default value, can be adjusted
            "--segment_prefix", "SU",
            "--maids_graph_file", latest_maids_graph_file,
            "--ttids_graph_file", latest_ttids_graph_file,
        ]

        # Get application ID created in the initialization step
        app_id = context["ti"].xcom_pull(
            key="application_id", task_ids="initialise"
        )

        # Set up Spark submit parameters
        spark_submit_params = f"--conf spark.submit.pyFiles={code}"

        logging.info(f"Starting EMR job {job_script} with args {job_driver_arguments} and spark_submit_params {spark_submit_params}")

        # Start the EMR job
        job = start_emr_job(
            task_id=f"process_ttdid_data",
            application_id=f"{app_id}",
            execution_role_arn=f"{execution_role_arn}",
            job_driver={
                "sparkSubmit": {
                    "entryPoint": job_script,
                    "entryPointArguments": job_driver_arguments,
                    "sparkSubmitParameters": spark_submit_params,
                },
            },
            configuration_overrides={
                "monitoringConfiguration": {
                    "s3MonitoringConfiguration": {
                    "logUri": log_uri,
                    },
                }
            },
        )

        logging.info(f"Created task {job}")

        job_id = job.execute(get_current_context())

        end_time = time.time()
        logging.info(
            f"Process finished, time taken: {datetime.timedelta(seconds=end_time - start_time)}"
        )

        s3 = sf.get_s3_client()

        try:
            subject = s3.get_object(
                Bucket=bl.get_bucket_name("temp", env),
                Key=f"{email_data_key}/subject.txt"
            )["Body"].read().decode('utf-8')

            html_content = s3.get_object(
                Bucket=bl.get_bucket_name("temp", env),
                Key=f"{email_data_key}/body.txt"
            )["Body"].read().decode('utf-8')

            email_op = EmailOperator(
                task_id="send_ttdid_data_email_report",
                to=EMAIL_LIST,
                subject=subject,
                html_content=html_content,
                dag=dag
            )

            email_op.execute(get_current_context())
        except Exception as e:
            logging.warning(f"Failed to send email: {e}")

        return f"Executed script... {job_id}"

    task_process_ttdid_data = PythonOperator(
        task_id="process_ttdid_data",
        python_callable=process_ttdid_data,
        trigger_rule="all_done",  # Run even if upstream tasks just complete
        dag=dag,
    )

    def move_ttdids_fies(**context):
        # scan directories for files like this s3://eec-aws-uk-ms-consumersync-dev-output-bucket/marketplaces/ttdid/data/2025-07-29/Replace.TTDID.SU0000091.0.maids.20250729144736.csv.gzip/part-00000-17c5e168-c44e-4a8d-ba3e-cfb4e5123676-c000.csv.gz
        # move the file from s3://eec-aws-uk-ms-consumersync-dev-output-bucket/marketplaces/ttdid/data/2025-07-29/Replace.TTDID.SU0000091.0.maids.20250729144736.csv.gzip/part-00000-17c5e168-c44e-4a8d-ba3e-cfb4e5123676-c000.csv.gz
        # and rename to s3://eec-aws-uk-ms-consumersync-dev-output-bucket/marketplaces/ttdid/data/2025-07-29/Replace.TTDID.SU0000091.0.maids.20250729144736.csv.gzip
        # and then delete the directory s3://eec-aws-uk-ms-consumersync-dev-output-bucket/marketplaces/ttdid/data/2025-07-29/Replace.TTDID.SU0000091.0.maids.20250729144736.csv.gzip/

        try:

            env = sf.get_env()
            temp_output_bucket = bl.get_bucket_name("temp", env)
            output_bucket = bl.get_bucket_name("output", env)
            mask = context["params"]["mask"]
            quick_stats = []

            output_files = sf.list_files(
                temp_output_bucket,
                f"marketplaces/ttdid/data/{mask}/Replace",
                "part",
                is_pattern_parent_directory_name=False
            )

            logging.info(f"Output files found: {output_files}")

            s3 = sf.get_s3_client()

            for out in output_files:
                out_bucket, out_key = sf.parse_s3_path(out)
                final_key = "/".join(out_key.split("/")[:-1])
                s3.copy(CopySource={"Bucket": out_bucket, "Key": out_key}, Bucket=output_bucket, Key=final_key)
                logging.info(f"Moved file from {out_key} to {final_key}")
                sf.update_stats(quick_stats, "File move", "Success", f"Moved file from {out_key} to {final_key}")
                # TODO this will break since the permissions are not there to delete
                # s3.delete_object(Bucket=out_bucket, Key=out_key)

            logging.info(f"Moved all files to {output_bucket}/marketplaces/ttdid/data/{mask}/")

            success_flag = True
        except Exception as e:
            logging.error(f"Error moving files: {e}")
            sf.update_stats(quick_stats, "File move", "Falied", e)
            success_flag = False

        try:



            title = "TTDIDs Moved files to output bucket"
            subject = f"***{title} - {sf.emoji['green']}***" if success_flag else f"***{title} - {sf.emoji['red']}***"

            table = "<html><body><table><tr><th>Time</th><th>Milestone</th><th>Message</th><th>Status</th></tr>{data}</table></body></html>"
            email_body = table.format(data="".join([f"<tr><td>{q['Time']}</td><td>{q['Milestone']}</td><td>{q['Message']}</td><td>{q['Status']}</td></tr>" for q in quick_stats])
)
            email_op = EmailOperator(
                task_id="send_ttdid_data_email_report",
                to=EMAIL_LIST,
                subject=subject,
                html_content=email_body,
                dag=dag
            )

            email_op.execute(get_current_context())
        except Exception as e:
            logging.warning(f"Failed to send email: {e}")

        if not success_flag: raise Exception("Failed to move files")

        return f"Moved files to {output_bucket}/marketplaces/ttdid/data/{mask}/"

    task_move_ttdids_files = PythonOperator(
        task_id="move_ttdids_files",
        python_callable=move_ttdids_fies,
        trigger_rule="all_done",  # Run even if upstream tasks just complete
        dag=dag,
    )

    def make_appropriate_copies_for_ttdda(**context):

        try:

            quick_stats = []
            logging.info("Making copies for TTDDAs")
            mask = context["params"]["mask"]
            env = sf.get_env()
            s3 = sf.get_s3_client()
            output_bucket = bl.get_bucket_name("output", env)

            ttdda_metadata = sorted(sf.list_files(output_bucket,"marketplaces/ttdda/metadata/", is_pattern_parent_directory_name=False))[-1]
            ttdda_bucket, ttdda_key = sf.parse_s3_path(ttdda_metadata)
            ttdda_object = s3.get_object(Bucket=ttdda_bucket, Key=ttdda_key)["Body"]

            # need to use import csv
            import csv
            # read the csv file into dictrionary
            csv_reader = csv.DictReader(ttdda_object.read().decode('utf-8').splitlines())
            ttdda_list = []
            for row in csv_reader:
                if row['ElementId'] and row['ElementId'].startswith('DA'):
                    ttdda_list.append(row['ElementId'])

            ttdda_list = list(set(ttdda_list))  # Remove duplicates

            logging.info(f"Found {len(ttdda_list)} TTDDAs in metadata file: {ttdda_metadata}")
            # chopp off the codes at the start and compare numbers

            ttdda_codes = [int(x[2:]) for x in ttdda_list]

            output_files = sf.list_files(output_bucket, f"marketplaces/ttdid/data/{mask}", is_pattern_parent_directory_name=False)
            sf.update_stats(quick_stats, "File move", "Success", f"Found {len(output_files)} output files to process for TTDDAs")

            for out in output_files:
                out_bucket, out_key = sf.parse_s3_path(out)
                if not out_key.endswith(".csv.gzip"):
                    continue

                # Extract the code from the filename
                code = out_key.split("/")[-1].split(".")[2]
                code_number = int(code[2:])
                if code_number in ttdda_codes:
                    # Copy the file to the ttdda directory
                    new_key = f"marketplaces/ttdda/data/{mask}/{out_key.split('/')[-1]}".replace("Replace.TTDID.SU", "Replace.TTDDA.DA")
                    #print(new_key)
                    s3.copy(CopySource={"Bucket": out_bucket, "Key": out_key}, Bucket=output_bucket, Key=new_key)
                    sf.update_stats(quick_stats, "File copy", "Success", f"Copied {out_key} to {new_key}")
                    logging.info(f"Copied {out_key} to {new_key}")

            success_flag = True

        except Exception as e:
            logging.error(f"Error making copies for TTDDAs: {e}")
            sf.update_stats(quick_stats, "File copy", "Failed", e)
            success_flag = False

        try:


            title = "TTDDA - Copied TTDDA files to output bucket"
            subject = f"***{title} - {sf.emoji['green']}***" if success_flag else f"***{title} - {sf.emoji['red']}***"

            table = "<html><body><table><tr><th>Time</th><th>Milestone</th><th>Message</th><th>Status</th></tr>{data}</table></body></html>"
            email_body = table.format(data="".join([f"<tr><td>{q['Time']}</td><td>{q['Milestone']}</td><td>{q['Message']}</td><td>{q['Status']}</td></tr>" for q in quick_stats]))
            email_op = EmailOperator(
                task_id="send_ttdid_data_email_report",
                to=EMAIL_LIST,
                subject=subject,
                html_content=email_body,
                dag=dag
            )

            email_op.execute(get_current_context())
        except Exception as e:
            logging.warning(f"Failed to send email: {e}")

        if not success_flag: raise Exception("Failed to move files")

        return f"Copied files to {output_bucket}/marketplaces/ttdda/data/{mask}/"

    task_copy_ttdids_files_for_ttdda = PythonOperator(
        task_id="copy_ttdids_files_for_ttdda",
        python_callable=make_appropriate_copies_for_ttdda,
        trigger_rule="all_done",  # Run even if upstream tasks just complete
        dag=dag,
    )

    def finalise_emr(**context):
        """
        Deletes the EMR application and finalises the workflow.
        """
        from shared.utils.emr_application_factory import delete_emr_application

        logging.info("Finalising DAG with context %s", context)

        app_id = context["task_instance"].xcom_pull(
            key="application_id", task_ids="initialise"
        )

        emr_flow_start = context["task_instance"].xcom_pull(
            key="emr_start_time", task_ids="initialise"
        )

        logging.info(f"Emr was started at {emr_flow_start}")

        emr_application_name = f"killing-the-application"
        delete_emr_application(
            context, emr_application_name, app_id
        )

        emr_flow_end = time.time()
        logging.info(
            f"Workflow finished, time taken:{datetime.timedelta(seconds=emr_flow_end - emr_flow_start)}"
        )
        return "Completed finalisation"

    task_delete_emr_app = PythonOperator(
        task_id="finalise",
        python_callable=finalise_emr,
        trigger_rule="none_failed",  # Run only if no upstream task has failed
        dag=dag,
    )

    node = EmptyOperator(
        task_id="node",
        trigger_rule="all_success",  # Run only if no upstream task has failed
        dag=dag,
    )

    # Set task dependencies

    # task_check_for_new_ttdid_metadata_files >> task_create_emr_app >> task_process_ttdid_metadata_file >> task_check_for_new_ttdda_metadata_files >> task_process_ttdda_metadata_file >> task_delete_emr_app
    # Run both checks in parallel first
    task_check_for_new_ttdid_metadata_files
    task_check_for_new_ttdda_metadata_files

    # Create EMR app if any check found files, then process each file if available
    [task_check_for_new_ttdid_metadata_files, task_check_for_new_ttdda_metadata_files] >> task_create_emr_app

    # Process each file only if its corresponding check found something
    task_create_emr_app >> task_process_ttdid_metadata_file
    task_create_emr_app >> task_process_ttdda_metadata_file

    # Update the DAG dependencies to include the new task
    [task_process_ttdid_metadata_file, task_process_ttdda_metadata_file] >> node

    node >> [
        check_metadata_file_ttdids,
        check_experian_taxonomy_file,
        check_match_id_lookup_file,
        check_uid_graph_file,
        check_maids_graph_file,
        check_ttdids_graph_file,
    ] >> task_process_ttdid_data >>  task_move_ttdids_files >> task_copy_ttdids_files_for_ttdda >> task_delete_emr_app