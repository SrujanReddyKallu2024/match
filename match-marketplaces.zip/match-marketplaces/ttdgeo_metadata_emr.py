"""
Script Name: ttdgeo_metadata_emr.py
Description: EMR-compatible version of TTD geo metadata processing
Date: 2025-07-29
"""

# ----------------------------------------------------------------------
# STANDARD IMPORTS
# ----------------------------------------------------------------------

import os
import sys
import datetime
import argparse
import logging
from typing import Dict
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from timeit import default_timer as timer
import pandas as pd
from shared.functions import save_formatted_report

# Configure root logger
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

# Use the module logger
logger = logging.getLogger(__name__)

# ----------------------------------------------------------------------
# SCRIPT CONFIGURATION
# ----------------------------------------------------------------------

SCRIPT_CODE = "TTDGEO_META"

# Status emojis to match on-premises
STATUS_EMOJIS = {
    'green': '✅',
    'red': '❌'
}

# ----------------------------------------------------------------------
# HELPER FUNCTIONS
# ----------------------------------------------------------------------

def update_stats(stats, milestone, status="success", message=""):
    """
    Update the stats dictionary with the milestone, status and message
    """
    stats.append({
        "Time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "Milestone": milestone,
        "Message": message,
        "Status": STATUS_EMOJIS['green'] if status.lower()=="success" else STATUS_EMOJIS['red']
    })

def format_metadata(df, country):
    """
    Format the marketplace file based on desired format
    """
    df1 = (
        df[["SEGMENT ID","Parent  ID","Segment Name","Full Path","PRICING ($)","Buyable 1(YES) or 0(NO)", "MediaCostRate"]].rename({
            "SEGMENT ID":"ElementId",
            "Parent  ID":"ParentId",
            "Segment Name":"Name",
            "Full Path":"Segment_Description",
            "PRICING ($)":"CPMRate",
            "Buyable 1(YES) or 0(NO)":"Buyable",
            "MediaCostRate": "MediaCostRate",
        },axis=1)
    )
    df1.replace(r"N/A","",inplace=True)
    logger.info(f"replaced N/A with empty string in input data")
    logger.info(f"input data shape: {df1.shape}")
    df1['Segment_Description'] = df1['Segment_Description'].str.replace('\u00A0', ' ', regex=False)
    df2 = df1[df1.ElementId.str.match(f"{country}\d+") | df1.ParentId.str.match("ROOT")].copy()
    logger.info(f"filtered out non-country segments, current count: {df2.shape[0]:,} rows")
    df2.loc[df2.ParentId == "ROOT", "Segment_Description"] = f"{country} > " + df2.loc[df2.ParentId == "ROOT", "Segment_Description"]
    df2["num"] = df2[df2.ParentId!="ROOT"].ElementId.str.replace(country,"").astype("int")
    df2.num = df2.num.fillna(0)
    df2.num = df2.num * 1000000 + df2.index
    df2.sort_values("num",inplace=True)
    df2.drop(columns=["num"],inplace=True)

    # Validation check
    if df2[df2.ElementId.str.match(f"{country}\d+")][["CPMRate","Buyable","MediaCostRate"]].isnull().all().any():
        raise ValueError(f"Columns CPMRate, Buyable, or MediaCostRate contain no data for country {country} in ElementId column")

    return df2

# ----------------------------------------------------------------------
# ARGUMENT PARSING
# ----------------------------------------------------------------------

def create_parser():
    """Create argument parser for the script."""
    parser = argparse.ArgumentParser(description="Process TTD geo metadata for EMR")
    
    parser.add_argument("--input_path", type=str, required=True,
                      help="S3 path to TTD metadata Excel file")
    parser.add_argument("--output_path", type=str, required=True,
                      help="S3 path for metadata output CSV")
    parser.add_argument("--country", type=str, required=True,
                      help="Country code to filter segments")
    parser.add_argument("--execution_date", type=str, required=True,
                      help="Execution date in YYYY-MM-DD format")
    parser.add_argument("--formatted_stats_path", type=str, required=True,
                      help="S3 path for saving formatted statistics report")
    
    return parser

# ----------------------------------------------------------------------
# MAIN FUNCTION
# ----------------------------------------------------------------------

def main():
    """Main entry point for the script."""
    start_time = timer()
    
    # Parse arguments
    parser = create_parser()
    args, unknown = parser.parse_known_args()
    
    if unknown:
        logger.warning(f"Unknown arguments: {unknown}")
    
    # Initialize Spark Session
    spark = (SparkSession.builder
        .appName("TTD Geo Metadata Processing")
        .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
        .config("spark.hadoop.fs.s3a.aws.credentials.provider", "com.amazonaws.auth.DefaultAWSCredentialsProvider")
        .getOrCreate())
    
    spark.sparkContext.setLogLevel("WARN")
    
    logger.info("Starting TTD Geo Metadata Processing")
    logger.info(f"Input path: {args.input_path}")
    logger.info(f"Output path: {args.output_path}")
    logger.info(f"Country: {args.country}")
    
    # Initialize stats like on-premises
    quick_stats = []
    success_flag = False
    
    try:
        # Read Excel file from S3
        logger.info(f"Reading Excel file from S3: {args.input_path}")
        input_df = pd.read_excel(args.input_path, sheet_name="Experian Taxonomy", skiprows=1)
        logger.info("read data from marketplace file")
        
        update_stats(quick_stats, "TTD Metadata Input", "Success", f"Found total of {input_df.shape[0]:,} rows from Path: {args.input_path}")
        
        # Format metadata
        df_formatted = format_metadata(input_df, args.country.upper())
        logger.info(f"formatted input data and filtered out non-country segments, current count: {df_formatted.shape[0]:,} rows")
        
        # Convert to Spark DataFrame and save to S3
        spark_df = spark.createDataFrame(df_formatted)
        spark_df.repartition(1).write.csv(args.output_path, header=True, mode="overwrite")
        logger.info(f"saved formatted data to S3 path: {args.output_path}")
        
        update_stats(quick_stats, "TTD Metadata Output", "Success", f"Formatted and saved {df_formatted.shape[0]:,} rows and {df_formatted.shape[1]:,} columns to local path: {args.output_path}")
        
        # Validate expected shape (from original logic)
        if df_formatted.shape[0] != 278 or df_formatted.shape[1] != 7:
            warning_msg = f"Input data shape is not as expected, found {df_formatted.shape}, expected (278, 7)"
            logger.warning(warning_msg)
            update_stats(quick_stats, "TTD Metadata Validation", "Failed", warning_msg)
        else:
            update_stats(quick_stats, "TTD Metadata Validation", "Success", f"Data shape validation passed: {df_formatted.shape}")
        
        success_flag = True
        
    except Exception as e:
        logger.error(e, exc_info=True)
        update_stats(quick_stats, "TTD Metadata Processing", "Failed", str(e))
        
    finally:
        # Calculate total time
        end_time = timer()
        time_taken = str(datetime.timedelta(seconds=round(end_time - start_time, 0)))
        
        # Create email-style report like on-premises
        alerts_df = pd.DataFrame(quick_stats)
        email_sub = f"***TEUG00 - Generate TTD metadata - {STATUS_EMOJIS['green']}***" if success_flag else f"***TEUG00 - Generate TTD metadata - {STATUS_EMOJIS['red']}***"
        
        # Format report content similar to on-premises
        report_content = f"{email_sub}\n\n"
        report_content += f"Execution Date: {args.execution_date}\n"
        report_content += f"Country: {args.country}\n"
        report_content += f"Processing Time: {time_taken}\n\n"
        report_content += alerts_df.to_html(index=False)
        
        # Save formatted report
        logger.info(f"Saving formatted report to: {args.formatted_stats_path}")
        save_formatted_report(args.formatted_stats_path, report_content)
        logger.info("Formatted report saved successfully")
        
        logger.info(f"process completed in {time_taken}")
        
        if not success_flag:
            sys.exit(1)
        else:
            sys.exit(0)
    
    finally:
        spark.stop()

if __name__ == "__main__":
    main()