"""
DAG to process TTD Geo data ingestion.
Processes metadata and geo coordinate data for TTD.
"""

import json
import logging
import time
from datetime import datetime, timedelta

from airflow import DAG
from airflow.models.param import Param
from airflow.operators.python import PythonOperator, BranchPythonOperator, get_current_context
from airflow.operators.dummy import DummyOperator
from airflow.operators.email import EmailOperator
from airflow.models import Variable
from airflow.operators.trigger_dagrun import TriggerDagRunOperator

import pendulum
import re
import sys
import os
import tempfile
from pathlib import Path

# Set up paths
sys.path.append(str(Path(__file__).resolve().parents[1]))
sys.path.append(str(Path(__file__).resolve().parents[1]) + "/shared")

# Standard logging configuration
logging.getLogger(__name__).setLevel(logging.INFO)

# Import shared functions
import shared.functions
import shared.utils
import shared.utils.utils
import shared.bucket_list

logging.info(f"sys.path {sys.path}")

from shared.functions import platform, get_env, parse_s3_path

logging.info(f"Platform is {platform}")

# Import EMR application factory utilities
from shared.utils.emr_application_factory import create_emr_application, delete_emr_application, start_emr_job
import boto3

# Define DAG with parameters
with DAG(
    "ttdgeo_processing",
    description="Process TTD Geo data ingestion",
    catchup=False,
    start_date=pendulum.datetime(2023, 1, 1, tz="UTC"),
    schedule_interval="0 10 * * *",  # Daily at 10 AM
    tags=["ttdgeo", "ingestion"],
    default_args={
        'owner': 'airflow',
        'depends_on_past': False,
        'email_on_failure': True,
        'email_on_retry': False,
        'retries': 1,
        'retry_delay': timedelta(minutes=5),
    },
) as dag:

    def create_script_arguments(**context):
        """
        Calculate all paths and configuration needed for the workflow
        
        Args:
            context: Airflow task context
            
        Returns:
            None
        """
        from shared.bucket_list import get_bucket_name
        from shared.functions import latest_path, get_env, latest_file, file_exists
        
        logging.info("Creating script arguments")
        
        # Initialize workflow timing
        workflow_start_time = time.time()
        logging.info("Workflow started %s", datetime.fromtimestamp(workflow_start_time))
        
        # Get environment
        env = get_env()
        
        # Store workflow timing info
        context["task_instance"].xcom_push(key="workflow_start_time", value=workflow_start_time)
        context["task_instance"].xcom_push(key="env", value=env)
        
        # Use execution date directly
        execution_date = context["execution_date"]
        
        # Calculate date formats for file paths
        date_str = execution_date.strftime("%Y-%m-%d")
        now_str = datetime.now().strftime("%Y%m%d%H%M%S")
        
        # Store dates
        context["task_instance"].xcom_push(key="execution_date", value=date_str)
        context["task_instance"].xcom_push(key="stats_timestamp", value=now_str)
        
        # Define protocol
        PROTOCOL = "s3a"
        
        # Get bucket names
        source_bucket = get_bucket_name("source")  # eec-aws-uk-ms-consumersync-dev-client-delivery-bucket
        interim_bucket = get_bucket_name("interim")
        output_bucket = get_bucket_name("output")
        code_bucket = get_bucket_name("code")
        log_bucket = get_bucket_name("logs")
        stats_bucket = get_bucket_name("stats")
        
        # Store bucket names
        context["task_instance"].xcom_push(key="source_bucket", value=source_bucket)
        context["task_instance"].xcom_push(key="interim_bucket", value=interim_bucket)
        context["task_instance"].xcom_push(key="output_bucket", value=output_bucket)
        context["task_instance"].xcom_push(key="code_bucket", value=code_bucket)
        context["task_instance"].xcom_push(key="log_bucket", value=log_bucket)
        context["task_instance"].xcom_push(key="stats_bucket", value=stats_bucket)
        
        # Try to find input files
        try:
            # Look for metadata file (Excel)
            metadata_file = latest_path(
                source_bucket, "ttdgeo/", "ttdeu_marketplacefile", False
            )
        except Exception as e:
            logging.warning(f"Error finding metadata file: {e}")
            metadata_file = None
        
        try:
            # Look for data file (CSV)
            data_file = latest_path(
                source_bucket, "ttdgeo/", "ttd_marketplacefile", False
            )
        except Exception as e:
            logging.warning(f"Error finding data file: {e}")
            data_file = None
        
        # Define paths
        ttdgeo_filepaths = {
            "metadata_input": metadata_file,
            "data_input": data_file,
            "metadata_output": f"{PROTOCOL}://{interim_bucket}/ttdgeo/{date_str}/metadata/taxonomy.csv",
            "data_output_partitioned": f"{PROTOCOL}://{interim_bucket}/ttdgeo/{date_str}/data/ttd_{{cc}}__{now_str}.csv",
            "data_output_final": f"{PROTOCOL}://{output_bucket}/ttdgeo/{date_str}/final",
            "metadata_formatted_stats": f"{PROTOCOL}://{stats_bucket}/ttdgeo/metadata_stats_{now_str}_formatted.txt",
            "data_formatted_stats": f"{PROTOCOL}://{stats_bucket}/ttdgeo/data_stats_{now_str}_formatted.txt",
        }
        
        logging.info(f"Using TTD Geo filepaths {ttdgeo_filepaths}")
        
        # Store all paths
        context["task_instance"].xcom_push(key="TTDGEO_FILEPATHS", value=ttdgeo_filepaths)
        
        # Check if input files exist
        metadata_exists = False
        data_exists = False
        
        if metadata_file:
            try:
                bucket_name, key = parse_s3_path(metadata_file)
                metadata_exists = file_exists(bucket_name, key, is_pattern_parent_directory_name=False)
            except Exception as e:
                logging.error(f"Error checking metadata file: {str(e)}")
        
        if data_file:
            try:
                bucket_name, key = parse_s3_path(data_file)
                data_exists = file_exists(bucket_name, key, is_pattern_parent_directory_name=False)
            except Exception as e:
                logging.error(f"Error checking data file: {str(e)}")
        
        context["task_instance"].xcom_push(key="metadata_exists", value=metadata_exists)
        context["task_instance"].xcom_push(key="data_exists", value=data_exists)
        
        # Push EMR common configuration
        execution_role_arn = shared.utils.utils.get_emr_serverless_role(env)
        log_uri_prefix = f"s3://{log_bucket}/spark-logs"
        shared_code = [
            f"s3://{code_bucket}/zipped/ems-code-shared.zip",
        ]
        ttdgeo_code_prefix = f"s3://{code_bucket}/repos/ems-code-marketplaces"
        
        # Push common args
        context["task_instance"].xcom_push(key="EXECUTION_ROLE_ARN", value=execution_role_arn)
        context["task_instance"].xcom_push(key="LOG_URI_PREFIX", value=log_uri_prefix)
        context["task_instance"].xcom_push(key="SHARED_CODE", value=shared_code)
        context["task_instance"].xcom_push(key="TTDGEO_CODE_PREFIX", value=ttdgeo_code_prefix)
        
        return True

    def initialise(**context):
        """
        Initialize EMR Serverless application
        
        Args:
            context: Airflow task context
            
        Returns:
            String indicating success
        """
        logging.info("Initializing EMR Serverless application")
        
        # Get EMR subnets and security groups
        emr_subnet_ids = None
        emr_security_group_ids = None
        
        # Create application name with timestamp
        date = datetime.now().strftime("%Y%m%d%H%M%S")
        emr_application_name = f"ttdgeo-processing-{date}"
        
        logging.info(f"Creating EMR application with name {emr_application_name}")
        
        # Create EMR application
        app_id = create_emr_application(
            context, emr_application_name, emr_subnet_ids, emr_security_group_ids
        )
        
        # Store in XCom
        context["task_instance"].xcom_push(key="application_id", value=app_id)
        context["task_instance"].xcom_push(key="emr_application_name", value=emr_application_name)
        
        logging.info(f"Created EMR application {app_id}")
        
        return "Executed initialise..."

    def check_input_exists(**context):
        """
        Check if the input files exist in S3
        
        Args:
            context: Airflow task context
            
        Returns:
            Task ID of the next task to execute
        """
        metadata_exists = context["ti"].xcom_pull(key="metadata_exists", task_ids="create_script_arguments")
        data_exists = context["ti"].xcom_pull(key="data_exists", task_ids="create_script_arguments")
        
        if metadata_exists and data_exists:
            logging.info("Both input files exist, proceeding with processing")
            return "process_metadata"
        else:
            logging.warning("Input files do not exist, skipping processing")
            return "input_missing"

    def run_metadata_processing(**context):
        """
        Execute the TTD Geo metadata processing task
        
        Args:
            context: Airflow task context
            
        Returns:
            Message indicating completion
        """
        from shared.utils.emr_application_factory import start_emr_job
        
        start_time = time.time()
        
        app_id = context["task_instance"].xcom_pull(key="application_id", task_ids="initialise")
        
        EXECUTION_ROLE_ARN = context["task_instance"].xcom_pull(
            key="EXECUTION_ROLE_ARN", task_ids="create_script_arguments"
        )
        LOG_URI_PREFIX = context["task_instance"].xcom_pull(
            key="LOG_URI_PREFIX", task_ids="create_script_arguments"
        )
        SHARED_CODE = context["task_instance"].xcom_pull(
            key="SHARED_CODE", task_ids="create_script_arguments"
        )
        TTDGEO_CODE_PREFIX = context["task_instance"].xcom_pull(
            key="TTDGEO_CODE_PREFIX", task_ids="create_script_arguments"
        )
        
        # Get paths from TTDGEO_FILEPATHS
        ttdgeo_filepaths = context["task_instance"].xcom_pull(
            key="TTDGEO_FILEPATHS", task_ids="create_script_arguments"
        )
        execution_date = context["task_instance"].xcom_pull(key="execution_date", task_ids="create_script_arguments")
        
        # Extract country code from file name (assume SE, DK, etc.)
        input_path = ttdgeo_filepaths["metadata_input"]
        country = "DK"  # Default, could extract from filename
        if "_dk_" in input_path.lower():
            country = "DK"
        elif "_se_" in input_path.lower():
            country = "SE"
        
        # Set up job arguments including stats paths
        job_args = [
            "--input_path", input_path,
            "--output_path", ttdgeo_filepaths["metadata_output"],
            "--country", country,
            "--execution_date", execution_date,
            "--formatted_stats_path", ttdgeo_filepaths["metadata_formatted_stats"]
        ]
            
        main = f"{TTDGEO_CODE_PREFIX}/ttdgeo_metadata_emr.py"
        
        # Set the parameters for the EMR job
        job = start_emr_job(
            task_id="process_metadata",
            application_id=app_id,
            execution_role_arn=EXECUTION_ROLE_ARN,
            job_driver={
                "sparkSubmit": {
                    "entryPoint": main,
                    "entryPointArguments": job_args,
                    "sparkSubmitParameters": f"--conf spark.submit.pyFiles={','.join(SHARED_CODE) if isinstance(SHARED_CODE, list) else SHARED_CODE}",
                },
            },
            configuration_overrides={
                "monitoringConfiguration": {
                    "s3MonitoringConfiguration": {
                        "logUri": f"{LOG_URI_PREFIX}/ttdgeo_metadata",
                    },
                }
            },
        )
        
        job_id = job.execute(get_current_context())
        
        end_time = time.time()
        logging.info(f"Metadata processing finished, time taken: {timedelta(seconds=end_time - start_time)}")
        
        return f"Executed TTD Geo metadata processing: {job_id}"

    def run_data_processing(**context):
        """
        Execute the TTD Geo data processing task
        
        Args:
            context: Airflow task context
            
        Returns:
            Message indicating completion
        """
        from shared.utils.emr_application_factory import start_emr_job
        
        start_time = time.time()
        
        app_id = context["task_instance"].xcom_pull(key="application_id", task_ids="initialise")
        
        EXECUTION_ROLE_ARN = context["task_instance"].xcom_pull(
            key="EXECUTION_ROLE_ARN", task_ids="create_script_arguments"
        )
        LOG_URI_PREFIX = context["task_instance"].xcom_pull(
            key="LOG_URI_PREFIX", task_ids="create_script_arguments"
        )
        SHARED_CODE = context["task_instance"].xcom_pull(
            key="SHARED_CODE", task_ids="create_script_arguments"
        )
        TTDGEO_CODE_PREFIX = context["task_instance"].xcom_pull(
            key="TTDGEO_CODE_PREFIX", task_ids="create_script_arguments"
        )
        
        # Get paths from TTDGEO_FILEPATHS
        ttdgeo_filepaths = context["task_instance"].xcom_pull(
            key="TTDGEO_FILEPATHS", task_ids="create_script_arguments"
        )
        execution_date = context["task_instance"].xcom_pull(key="execution_date", task_ids="create_script_arguments")
        
        # Set up job arguments including stats paths
        job_args = [
            "--input_path", ttdgeo_filepaths["data_input"],
            "--output_path", ttdgeo_filepaths["data_output_partitioned"],
            "--final_output_path", ttdgeo_filepaths["data_output_final"],
            "--execution_date", execution_date,
            "--formatted_stats_path", ttdgeo_filepaths["data_formatted_stats"]
        ]
            
        main = f"{TTDGEO_CODE_PREFIX}/ttdgeo_data_emr.py"
        
        # Set the parameters for the EMR job
        job = start_emr_job(
            task_id="process_data",
            application_id=app_id,
            execution_role_arn=EXECUTION_ROLE_ARN,
            job_driver={
                "sparkSubmit": {
                    "entryPoint": main,
                    "entryPointArguments": job_args,
                    "sparkSubmitParameters": f"--conf spark.submit.pyFiles={','.join(SHARED_CODE) if isinstance(SHARED_CODE, list) else SHARED_CODE}",
                },
            },
            configuration_overrides={
                "monitoringConfiguration": {
                    "s3MonitoringConfiguration": {
                        "logUri": f"{LOG_URI_PREFIX}/ttdgeo_data",
                    },
                }
            },
        )
        
        job_id = job.execute(get_current_context())
        
        end_time = time.time()
        logging.info(f"Data processing finished, time taken: {timedelta(seconds=end_time - start_time)}")
        
        return f"Executed TTD Geo data processing: {job_id}"

    def finalise(**context):
        """
        Delete EMR Serverless application and log workflow completion
        
        Args:
            context: Airflow task context
            
        Returns:
            Message indicating completion
        """
        logging.info("Finalizing EMR application")
        
        app_id = context["task_instance"].xcom_pull(key="application_id", task_ids="initialise")
        emr_application_name = context["task_instance"].xcom_pull(key="emr_application_name", task_ids="initialise")
        workflow_start_time = context["task_instance"].xcom_pull(key="workflow_start_time", task_ids="create_script_arguments")
        
        logging.info(f"Finalization started, deleting application {app_id}")
        
        # Delete EMR application
        delete_emr_application(context, emr_application_name, app_id)
        
        end_time = time.time()
        logging.info(f"Workflow finished, time taken: {timedelta(seconds=end_time - workflow_start_time)}")
        
        return "Finalized EMR application"

    def send_metadata_stats_email(**context):
        """
        Send email with metadata processing statistics
        Reads the formatted stats file and sends via email
        
        Args:
            context: Airflow task context
            
        Returns:
            Message indicating completion
        """
        import boto3
        import tempfile
        import os
        
        # Get current date for email subject
        current_date = datetime.now()
        mask = current_date.strftime("%Y-%m-%d")
        
        # Set recipients
        recipients = ['emsactivatealerts@experian.com']
        
        # Get paths from TTDGEO_FILEPATHS
        ttdgeo_filepaths = context["task_instance"].xcom_pull(
            key="TTDGEO_FILEPATHS", task_ids="create_script_arguments"
        )
        
        formatted_stats_path = ttdgeo_filepaths["metadata_formatted_stats"]
        
        logging.info(f"Sending metadata stats email using file at: {formatted_stats_path}")
        
        try:
            # Parse S3 path
            bucket_name, key = parse_s3_path(formatted_stats_path)
            
            # Initialize S3 client
            s3 = boto3.client('s3')
            
            # Download the file to a temporary location
            with tempfile.NamedTemporaryFile(delete=False, suffix='.txt') as temp_file:
                s3.download_fileobj(bucket_name, key, temp_file)
                temp_file_path = temp_file.name
            
            # Read the text content
            with open(temp_file_path, 'r') as file:
                text_content = file.read()
            
            # Wrap content in HTML
            html_content = f"""
            <html>
            <body>
                <h2>TTD GEO Metadata Processing - {mask}</h2>
                <pre>{text_content}</pre>
                <p>This is an automated message from the Airflow system.</p>
            </body>
            </html>
            """
            
            # Create and send email
            email_op = EmailOperator(
                task_id="send_metadata_stats_email_report",
                to=recipients,
                subject=f"*** TEUG00: TTD GEO Metadata Processing *** - {mask}",
                html_content=html_content,
                files=[temp_file_path],
                dag=dag
            )
            
            email_op.execute(context=context)
            
            # Clean up the temporary file
            os.unlink(temp_file_path)
            
            logging.info(f"Sent metadata stats email for {mask}")
            return f"Sent metadata stats email for {mask}"
            
        except Exception as e:
            logging.error(f"Error sending metadata stats email: {str(e)}")
            # Don't fail the DAG if email fails
            return f"Error sending metadata stats email: {str(e)}"

    def send_data_stats_email(**context):
        """
        Send email with data processing statistics
        Reads the formatted stats file and sends via email
        
        Args:
            context: Airflow task context
            
        Returns:
            Message indicating completion
        """
        import boto3
        import tempfile
        import os
        
        # Get current date for email subject
        current_date = datetime.now()
        mask = current_date.strftime("%Y-%m-%d")
        
        # Set recipients
        recipients = ['emsactivatealerts@experian.com']
        
        # Get paths from TTDGEO_FILEPATHS
        ttdgeo_filepaths = context["task_instance"].xcom_pull(
            key="TTDGEO_FILEPATHS", task_ids="create_script_arguments"
        )
        
        formatted_stats_path = ttdgeo_filepaths["data_formatted_stats"]
        
        logging.info(f"Sending data stats email using file at: {formatted_stats_path}")
        
        try:
            # Parse S3 path
            bucket_name, key = parse_s3_path(formatted_stats_path)
            
            # Initialize S3 client
            s3 = boto3.client('s3')
            
            # Download the file to a temporary location
            with tempfile.NamedTemporaryFile(delete=False, suffix='.txt') as temp_file:
                s3.download_fileobj(bucket_name, key, temp_file)
                temp_file_path = temp_file.name
            
            # Read the text content
            with open(temp_file_path, 'r') as file:
                text_content = file.read()
            
            # Wrap content in HTML
            html_content = f"""
            <html>
            <body>
                <h2>TTD GEO Data Processing - {mask}</h2>
                <pre>{text_content}</pre>
                <p>This is an automated message from the Airflow system.</p>
            </body>
            </html>
            """
            
            # Create and send email
            email_op = EmailOperator(
                task_id="send_data_stats_email_report",
                to=recipients,
                subject=f"*** TEUG01: TTD GEO Data Processing *** - {mask}",
                html_content=html_content,
                files=[temp_file_path],
                dag=dag
            )
            
            email_op.execute(context=context)
            
            # Clean up the temporary file
            os.unlink(temp_file_path)
            
            logging.info(f"Sent data stats email for {mask}")
            return f"Sent data stats email for {mask}"
            
        except Exception as e:
            logging.error(f"Error sending data stats email: {str(e)}")
            # Don't fail the DAG if email fails
            return f"Error sending data stats email: {str(e)}"

    # Define tasks
    
    # Start task
    start = DummyOperator(task_id="start")
    
    # Create script arguments
    task_create_arguments = PythonOperator(
        task_id="create_script_arguments",
        python_callable=create_script_arguments,
        trigger_rule="none_failed",
        dag=dag,
    )
    
    # Initialize EMR application
    task_initialise = PythonOperator(
        task_id="initialise",
        python_callable=initialise,
        trigger_rule="none_failed",
        dag=dag,
    )
    
    # Check if input exists
    check_input = BranchPythonOperator(
        task_id="check_input",
        python_callable=check_input_exists,
        dag=dag,
    )
    
    # Handle case where input is missing
    input_missing = DummyOperator(task_id="input_missing", dag=dag)
    
    # Process metadata
    task_process_metadata = PythonOperator(
        task_id="process_metadata",
        python_callable=run_metadata_processing,
        trigger_rule="none_failed",
        dag=dag,
    )
    
    # Send metadata stats email
    task_send_metadata_stats_email = PythonOperator(
        task_id="send_metadata_stats_email",
        python_callable=send_metadata_stats_email,
        trigger_rule="none_failed",
        dag=dag,
    )
    
    # Process data
    task_process_data = PythonOperator(
        task_id="process_data",
        python_callable=run_data_processing,
        trigger_rule="none_failed",
        dag=dag,
    )
    
    # Send data stats email
    task_send_data_stats_email = PythonOperator(
        task_id="send_data_stats_email",
        python_callable=send_data_stats_email,
        trigger_rule="none_failed",
        dag=dag,
    )
    
    # Finalize EMR application
    task_finalise = PythonOperator(
        task_id="finalise",
        python_callable=finalise,
        trigger_rule="none_failed_min_one_success",
        dag=dag,
    )
    
    # Define task dependencies
    start >> task_create_arguments >> task_initialise >> check_input

    # Execute processing workflow when input files are available
    check_input >> task_process_metadata >> task_send_metadata_stats_email
    task_send_metadata_stats_email >> task_process_data >> task_send_data_stats_email 
    task_send_data_stats_email >> task_finalise

    # Handle exception path when required input is not available
    check_input >> input_missing >> task_finalise