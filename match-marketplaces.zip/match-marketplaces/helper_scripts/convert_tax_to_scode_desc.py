import pandas as pd
from datetime import datetime

today_date = datetime.now().strftime("%Y%m%d")

EXCEL_PATH = r"..\metadata\ExperianUK_Digital_Taxonomy_External-2024.xlsx"

df = pd.read_excel(EXCEL_PATH, sheet_name="Digital Taxonomy", skiprows=3)

df1 = df[["S-number","Segment Description"]].rename({
    "S-number":"S_Code",
    "Segment Description":"Segment_Description"
},axis=1)

df1.to_csv(rf"..\metadata\tax_metadata_{today_date}.csv", index=False)