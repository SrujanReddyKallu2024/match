import pandas as pd
from datetime import datetime

today_date = datetime.now().strftime("%Y%m%d")


df = pd.read_excel(r"..\metadata\Digital_Taxonomy_Master_Layout_created_20231117_Don.xlsx", sheet_name="Taxonomy", skiprows=2)
print("loaded excel sheet")

df1 = df[["S-number","C-number"]]
print("extracted columns")

df1["S_Code"] = df1.copy()['S-number'].str.replace(r'^S[0]*', 'S', regex=True)
print("created S_Code column by removing padding")

print(df1)

df1.to_csv(rf"..\metadata\scode_ccode_lookup_{today_date}.csv", index=False)
print("writen out data to csv")