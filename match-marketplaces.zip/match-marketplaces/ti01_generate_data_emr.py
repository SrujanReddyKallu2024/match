import pandas as pd
import sys
from pathlib import Path
import argparse
import os
from pyspark.sql import SparkSession, Window
import pyspark.sql.functions as F
import pyspark.sql.types as T
from datetime import datetime
import time
import logging

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(funcName)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)

sys.path.append(
    str(Path(__file__).resolve().parents[2])
)  # should be setting PYTHONPATH

import process.config as config
import shared.functions as functions
from shared.functions import emoji
import shared.marketplaces.graph_extract as ge

def log(df):
    import io
    buffer = io.StringIO()
    sys.stdout = buffer
    df.show(10, truncate=False)
    sys.stdout = sys.__stdout__
    logging.info(buffer.getvalue())

def logic_main(
    spark,
    mask,
    email_bucket,
    email_key,
    experian_taxonomy_file,
    metadata_file,
    segment_prefix,
    match_id_lookup_experian_file,
    maids_graph_file,
    ttids_graph_file,
    uid_graph_file,
    output_prefix,
    temp_bucket,
    days_filter=30,
):
    logging.info(f"running {__file__} script for mask: {mask}")
    quick_stats = []

    ### find most recent match2/taxonomy/*/process/dt_long_cb_key_hh_s.parquet    segments
    ### find recent "id_graph/lookup/experian/match_id_lookup_experian_*.parquet" matchid
    ### find most recent ip graph id_graph/graphs/ip/ip_*.parquet                 ip_graph
    ### find recent taxonomy file                                       segments list

    try:
        startime = datetime.now()
        # load segments data as hh_scode
        # load  taxonomy csv as taxonomy
        # giant select/filter (taxonomy) on hh_scode as df_hh_scode_extract
        try:

            section_name = "Load Data"

            maids_graph_extract_file = ge.extract_graph(
                graph_file=maids_graph_file,
                id_column="maids",
                temp_bucket=temp_bucket,
                days_to_filter=days_filter,
            )

            df_maids = spark.read.parquet(
                ge.dedupe_graph_with_source(
                    graph_extract_file=maids_graph_extract_file,
                    id_column="maids",
                    temp_bucket=temp_bucket,
                    top=1,
                )
            )

            uid_graph_extract_file = ge.extract_graph(
                graph_file=uid_graph_file,
                id_column="uid",
                temp_bucket=temp_bucket,
                days_to_filter=days_filter,
            )

            df_uid = spark.read.parquet(
                ge.dedupe_graph_with_source(
                    graph_extract_file=uid_graph_extract_file,
                    id_column="uid",
                    temp_bucket=temp_bucket,
                    top=1,
                )
            )

            ttdids_graph_extract_file = ge.extract_graph(
                graph_file=ttids_graph_file,
                id_column="ttdids",
                temp_bucket=temp_bucket,
                days_to_filter=days_filter,
            )

            df_ttdids = spark.read.parquet(
                ge.dedupe_graph_with_source(
                    graph_extract_file=ttdids_graph_extract_file,
                    id_column="ttdids",
                    temp_bucket=temp_bucket,
                    top=1,
                )
            )

            
            functions.update_stats(
                quick_stats,
                section_name,
                "Success",
                f"loading:\\n"
                f"maids_graph file {maids_graph_file},\\n"
                f"ttdids_graph {ttids_graph_file},\\n"
                f"uid_graph {ttids_graph_file}"
            )

            logging.info(f"found {df_maids.count()} maids, {df_uid.count()} uid, {df_ttdids.count()} ttdids in graphs")


            # read metadata file and convert scodes in list
            df_metadata = spark.read.csv(metadata_file, header=True)
            logging.info(f"read metadata file with {df_metadata.count()} rows")
            s_code_list = [int(s[0][2:]) for s in df_metadata.select("ElementId").collect()]


            ## extract taxonomy
            df_s_codes_match_id_file = ge.taxonomy_selection(
                experian_taxonomy_file=experian_taxonomy_file,
                match_id_lookup_experian_file=match_id_lookup_experian_file,
                s_codes_list=s_code_list,  # example S_Codes
                temp_bucket=temp_bucket,
            )

            logging.info(f"file found is {df_s_codes_match_id_file}")
            df_s_codes_match_id = spark.read.parquet(df_s_codes_match_id_file)

            logging.info(f"found {df_s_codes_match_id.count()} S_Codes in taxonomy")


            # make sure we only get s_codes that are in the data
            real_s_codes = (
                df_s_codes_match_id.select("S_Code").distinct().collect()
            )
            real_s_codes = [r["S_Code"] for r in real_s_codes]
            logging.info(f"found {len(real_s_codes)} real S_Codes in taxonomy: {real_s_codes}")

            logging.info("data loaded")

            functions.update_stats(
                quick_stats,
                section_name,
                "Success",
                f"loaded:\\n"
                f"df_maids_graph ({df_maids.count()}),\\n"
                f"df_ttdids_graph ({df_ttdids.count()}),\\n"
                f"df_uid_graph ({df_uid.count()}),\\n"
                f"taxonomy file: {experian_taxonomy_file},\\n"
                f"and used df_taxonomy to create df_matchid_scode_extract ({df_s_codes_match_id.count()})",
            )
        except Exception as e:
            functions.update_stats(quick_stats, section_name, "Failed", str(e))
            raise

        # load ip data as input_ip_graph

        # load match id graph lookup as match_id_hh_key
        # window sorted by descending last_seen and descending count of source take top 1 as df_ip_graph

        # Define the window specification
        #! window_spec = Window.partitionBy("key1", "key2").orderBy(F.desc("val1"), F.desc("val2"))
        # Add a row number to each row within the window
        #! df_with_row_num = input_ip_graph.withColumn("row_num", F.row_number().over(window_spec))
        # Filter to keep only the first row in each window partition
        #! df_ip_graph = df_with_row_num.filter(F.col("row_num") <= 5).drop("row_num")

        # match df_ip_graph to match_id_hh_key as df_graph
        # match df_graph to df_hh_scode_extract

        deduped = {}
        graph_data = {
            "maids": df_maids,
            "uid": df_uid,
            "ttdids": df_ttdids,
        }

        stats = {}

        #for id, df, lkup in zip(
        for id in graph_data.keys():
            df = graph_data[id]

            try:

                section_name = "Join and Extract"
                logging.info(f"joining {id} graph to s_codes")

                total = len(real_s_codes)
                total_duration = 0
                so_far = 0
                import time
                chunk_size = 1000000
                stats[id] = {}

                # will collect stats for quick stats on the number of records and chunks written per id and socde

                for s in real_s_codes:
                    stats[id][s] = {}
                    logging.info(f"processing s_code: {s} for {id}")
                    starting = time.time()
                    temp = (
                        df_s_codes_match_id.filter(F.col("S_Code") == s)
                        .join(
                            df.select(id, "match_id"),
                            on="match_id",
                            how="inner",
                        )
                        .select(id)
                        .distinct()
                    )
                    logging.info(f"found {temp.count()} rows for s_code: {s} and id: {id}")

                    file = f"{output_prefix}/{id}/S_Code={segment_prefix}{s}"

                    try:
                        rdd = temp.rdd.zipWithIndex().map(lambda x: (x[1],) + x[0])
                        temp = rdd.toDF(["chunk"] + temp.columns)
                        temp = temp.withColumn("chunk", F.col("chunk")/chunk_size)
                        temp = temp.withColumn("chunk", F.col("chunk").cast("int"))

                        chunks = temp.select("chunk").distinct().collect()
                        chunks = [int(c["chunk"]) for c in chunks]

                        # we added a number and outputting chunks
                        ( temp
                            .write
                            .partitionBy("chunk")
                            .csv(
                                file,
                                header=False,
                                compression="gzip", mode="overwrite"
                            )
                        )

                        stats[id][s] =  { "count": 0, "chunks": len(chunks) }

                        for chunk in chunks:
                            chunk_file = f"{file}/chunk={chunk}"
                            logging.info(f"wrote chunk file: {chunk_file}")
                            chunk_merge = spark.read.csv(
                                chunk_file,
                                header=False,
                                inferSchema=True,
                            )
                            count_in_chunk = chunk_merge.count()
                            logging.info(f"found {count_in_chunk} rows in chunk: {chunk} for s_code: {s} and id: {id}")
                            stats[id][s]["count"] += count_in_chunk
                            if count_in_chunk == 0:
                                logging.warning(f"no data in chunk: {chunk} for s_code: {s} and id: {id}, skipping")
                                stats[id][s]["output"] = False
                                continue

                            chunk_merge = chunk_merge.withColumnRenamed("_c0", id)
                            final_filename = f"Replace.TTDID.{segment_prefix}{s:07d}.{chunk}.{id}.{config.TTD_TTDIDS_DATE_TIME}.csv.gzip"
                            chunk_merge.repartition(1).write.mode("overwrite").csv(f"{output_prefix}/{final_filename}", header=True, compression="gzip")
                            logging.info(f"wrote chunk data file: {output_prefix}/{final_filename}")
                            stats[id][s]["output"] = True

                    except Exception as e:
                        logging.warning(f"failed to write file for audience: {s} error: {e}")

                    ending = time.time()
                    so_far = so_far + 1
                    duration = ending - starting
                    total_duration += duration
                    average_duration = total_duration / so_far
                    remaining = (total - so_far) * average_duration
                    units = "s"
                    if remaining > 60:
                        remaining = remaining / 60
                        units = "min"
                        if remaining > 60:
                            remaining = remaining / 60
                            units = "hr"

                    if so_far < 5:
                        logging.info(
                            f"written file for audience: {s}: {file}, time remaining: ..."
                        )
                    else:
                        logging.info(
                            f"written file for audience: {s}: {file}, time remaining: {remaining:.2f}{units}"
                        )


                functions.update_stats(
                    quick_stats,
                    section_name,
                    "Success",
                    f"Created output file eg.: {file} at {id} level",
                )

            except Exception as e:
                functions.update_stats(quick_stats, section_name, "Failed", str(e))
                raise

        section_name = "Final Stats"

        for id in stats:
            for s in stats[id]:
                if "count" in stats[id][s] and "chunks" in stats[id][s]:
                    stats[id][s]["average_chunk_size"] = stats[id][s]["count"] / stats[id][s]["chunks"]
                functions.update_stats(
                    quick_stats,
                    section_name,
                    "Success",
                    f"stats: id: {id} segment: {s} {stats[id][s]}",
                )

        success_flag = True

    except Exception as e:
        logging.error(e)
        success_flag = False
        # functions.send_status_email(
        #     "Error: ti01_generate_data script failed", e, email_to
        # )
        raise
    finally:
        alerts_df = pd.DataFrame(quick_stats)
        title = "TI01 - Generate Data"
        email_sub = (
            f"***{title} - {emoji['green']}***"
            if success_flag
            else f"***{title} - {emoji['red']}***"
        )
        email_body = alerts_df.to_html(index=False)
        s3 = functions.get_s3_client()
        email_data_bucket = email_bucket
        email_data_key = email_key
        s3.put_object(
            Bucket=email_data_bucket,
            Key=email_data_key + "/subject.txt",
            Body=email_sub,
        )
        s3.put_object(
            Bucket=email_data_bucket,
            Key=email_data_key + "/body.txt",
            Body=email_body,
        )
        endtime = datetime.now()
        logging.info(f"process completed in {str(endtime - startime).split('.')[0]}")


def setup_parser():
    ## Setup Args
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument(
        "-m",
        "--mask",
        help="date on which process is run in format YYYY-MM-DD",
        required=True,
    )
    parser.add_argument(
        "-op",
        "--output_prefix",
        required=True,
        help="formatted marketplace file sent to this s3 bucket+key file path",
    )
    parser.add_argument(
        "-tb",
        "--temp_bucket",
        required=True,
        help="S3 bucket to store temporary files for graph extractions etc",
    )
    parser.add_argument(
        "-md",
        "--metadata_file",
        help="local path to the ttdids marketplace file",
        required=True,
    )
    parser.add_argument(
        "-sp", "--segment_prefix", help="prefix for the segment id", default="SU"
    )
    parser.add_argument(
        "-df",
        "--days_filter",
        help="number of days to filter the data",
        default=config.TTD_TTDIDS_DAYS_FILTER,
        type=int,
    )
    parser.add_argument(
        "-etb",
        "--email_data_bucket",
        required=True,
        help="S3 bucket to store email data",
    )
    parser.add_argument(
        "-ek",
        "--email_data_key",
        required=True,
        help="S3 key prefix to store email data",
    )
    parser.add_argument(
        "-etf",
        "--experian_taxonomy_file",
        required=True,
        help="S3 path to the Experian taxonomy file",
    )
    parser.add_argument(
        "-mil",
        "--match_id_lookup_experian_file",
        required=True,
        help="S3 path to the match ID lookup file",
    )
    parser.add_argument(
        "-mgf",
        "--maids_graph_file",
        required=True,
        help="S3 path to the maids graph file",
    )
    parser.add_argument(
        "-ttgf",
        "--ttids_graph_file",
        required=True,
        help="S3 path to the Trade Desk IDs graph file",
    )
    parser.add_argument(
        "-ugf",
        "--uid_graph_file",
        required=True,
        help="S3 path to the UID graph file",
    )

    return parser


if __name__ == "__main__":

    parser = setup_parser()
    config_parser = config.setup_parser()

    # Manually add each argument from config.py to the main parser
    for action in config_parser._actions:
        parser._add_action(action)  # This adds the arguments from config.py

    args, unknown = parser.parse_known_args()

    if len(unknown) > 0:
        raise Exception(f"Unknown arguments passed: {unknown}")

    ## Setup Spark and logging
    name = os.path.basename(__file__)

    spark = SparkSession.builder.appName(f"{name}_{args.mask}").getOrCreate()
    spark.sparkContext.setLogLevel("WARN")

    # logging.info(f"args are {args}")
    # if functions.get_env() == "local":
    #     functions.protocol = "s3a"

    ## Process starts here
    logic_main(
        spark,
        args.mask,
        args.email_data_bucket,
        args.email_data_key,
        args.experian_taxonomy_file,
        args.metadata_file,
        args.segment_prefix,
        args.match_id_lookup_experian_file,
        args.maids_graph_file,
        args.ttids_graph_file,
        args.uid_graph_file,
        args.output_prefix,
        args.temp_bucket,
        days_filter=30,
    )


# Testing command
# docker run -it --rm -v %cd%:/hello -e PYTHONPATH=/hello/marketplaces -w /hello pysparktestboto /opt/spark/bin/spark-submit /hello/marketplaces/ttdids/ti01_generate_data.py --mask 2022-03-04 --base_path_hdfs /hello/testing/data/hdfs/user/unity --email_to robin.potter@experian.com --debug --output_folder testing/data/hdfs/match2/marketplaces/ttdids  | findstr /V 25/02
# spark-submit marketplaces/freewheel/ti01_generate_data.py --mask 2022-02-22 --base_path_hdfs /user/unity/testing/data/hdfs/user/unity --email_to robin.potter@experian.com --debug --output_folder testing/data/hdfs/match2/marketplaces/freewheel | grep fw
# spark-submit --master yarn --queue adam marketplaces/freewheel/ti01_generate_data.py --mask $(date +%Y-%m-%d) --email_to robin.potter@experian.com --debug --output_folder /user/unity/fw_testing/data/hdfs/match2/marketplaces/freewheel | grep fw