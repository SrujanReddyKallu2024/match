from pathlib import Path
import sys
from pyspark.sql import SparkSession, Window
import pyspark.sql.functions as F
import argparse
import time

sys.path.append(str(Path(__file__).resolve().parents[1]))

from config import *
from functions import *


def format_hems_graph(df, df_orig):
    """
    format the hems graph
    """   
    hems_hh = (
        df
        .groupby('match_id_audigent')   
        .count()
    ).where(F.col('count')<= 50)

    return (
        hems_hh
        .select('match_id_audigent')
        .join(df_orig, 'match_id_audigent', 'inner')
    )



def logic_main(ctx, logger, mask, idg_graph_path, idg_lookup_path, mid_with_scodes_path, out_path, email_to):
    logger.info(f"running preprocess stats for mask: {mask}")
    try:
        startime = datetime.now()        
        date180= (startime - datetime.timedelta(days= 180)).strftime("%Y-%m-%d")

        ##HEMS Graph
        idg_hems_file = latest_hdfs_file(f"{idg_graph_path}/hems", pattern='hems')
        logger.info("latest hems graph file: {idg_hems_file}}")

        idg_hems = ctx.read.parquet(idg_hems_file)
        logger.info("read latest hems graph")

        aud_lookup_file = latest_hdfs_file(f"{idg_lookup_path}/audigent", pattern = 'match_id_lookup_audigent')
        logger.info(f"audigent lookup file: {aud_lookup_file}")
        
        aud_lookup = ctx.read.parquet(aud_lookup_file)
        logger.info("read audigent lookup data")

        idg_hems_mids = aud_lookup.join(idg_hems, 'match_id', 'inner').drop("match_id")
        logger.info("joined audigent lookup with hems graph")

        idg_hems_fmt = format_hems_graph(idg_hems, idg_hems_mids)
        logger.info("formatted hems graph")

        mid_with_scodes_file = latest_hdfs_file(mid_with_scodes_path, pattern='mid_with_scodes')
        logger.info(f"latest matchid with scodes file: {mid_with_scodes_file}")

        mid_with_scodes = ctx.read.parquet(mid_with_scodes_file)
        logger.info("read matchid with scodes data")

        final_idg_hems = (
            idg_hems_fmt
            .join(mid_with_scodes, 'match_id_audigent', 'inner')
            .withColumnRenamed('match_id_audigent', 'hh_id')
        )
        logger.info("joined formatted hems graph with matchid with scodes to get final audigent hems graph")

        final_idg_hems.repartition(10).write.csv(out_path, header=True, mode='overwrite', compression='gzip')
        logger.info(f"written output to path: {out_path}")
        
        time.sleep(60)

        ## Rename it based on Audigent format i.e. UK__experianuk_hems_UK_{mask}_001.csv.gz
        all_hems_files = get_all_files(out_path)
        logger.info(f"all hems files: {all_hems_files}")

        rename_files(logger, mask, all_hems_files, 'hems')        

    except Exception as e:
        logger.error(e)
        send_status_email("Error: aud02_format_hems script failed", e, email_to)
        raise
    finally:
        endtime = datetime.now()
        logger.info(f"process completed in {str(endtime - startime).split('.')[0]}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-m", "--mask", help="date on which process is run in format YYYY-MM-DD", default=TODAY_DATE)
    parser.add_argument("-igp", "--idg_graph_path", help="idgraph parent path", default=IDG_GRAPH_PATH)
    parser.add_argument("-ilp", "--idg_lookup_path", help="idgraph parent lookup file path", default=LOOKUP_FILE_PATH)
    parser.add_argument("-mwsp", "--mid_with_scodes_file", help="parent matchid to scodes file path", default=LOOKUP_FILE_PATH)
    parser.add_argument("-op", "--out_path", help="cleaned audigent scodes are written out to this hdfs csv file path")
    parser.add_argument("-et", "--email_to", help="recepients of email alerts", default=EMAIL_TO)
    

    args = parser.parse_args()

    if args.out_path is None:
        args.out_path = f"{AUD_PATH_HDFS}/{args.mask}/audigent_hems_graph.csv"

    name = os.path.basename(__file__)
    logger = LogConfig(f"{LOGPATH}/{name}_{args.mask}.log").generate_logger(name)
    spark = SparkSession.builder.appName(f"aud02_{args.mask}").getOrCreate()
    logic_main(spark, logger, args.mask)

