# spark-submit marketplaces/ttdeugeo/eug02_output_original.py --output=tmp/testing/output --output_counts=tmp/testing/stats/output_counts --input_counts=tmp/testing/stats/input_count --local_sts_folder /data/ttd_geo

import subprocess
from pathlib import Path
import sys
import os
import pyspark.sql.functions as F
import argparse
from pyspark.sql import SparkSession

sys.path.append(str(Path(__file__).resolve().parents[1]))

import config
from functions import local_file_rows, add_header_to_local_file

name = os.path.basename(__file__)
logger = config.LogConfig(f"{config.LOGPATH}/{name}_{config.DATE_TIME}.log").generate_logger(name)

argparser = argparse.ArgumentParser()
argparser.add_argument("--output", required=True, help="output file location")
argparser.add_argument("--output_counts", required=True, help="output counts file location")
argparser.add_argument("--input_counts", required=True, help="where the input counts get written")
argparser.add_argument("--local_sts_folder", required=True, help="local sts output folder")
# if testing paste this line in shell rather than next
# args, unknown = argparser.parse_known_args(['--input', 'testing/dk_ttdgeoll_2025-01-07.csv', '--output', 'testing/output', '--output_counts', 'testing/stats/output_counts', '--input_counts', 'testing/stats/input_counts'])
# args, unknown = argparser.parse_known_args(['--input', 'ttd_geo/dk_ttdgeoll_2025-01-07.csv.gz', '--output', 'tmp/testing/output', '--output_counts', 'tmp/testing/stats/output_counts', '--input_counts', 'tmp/testing/stats/input_counts'])

# use parse known args to allow for other args which might be in any future config module
args, unknownargs = argparser.parse_known_args()

logger.info(args)

spark = ( SparkSession.builder.appName("ttdeugeo")
    #.config("spark.driver.memory", "10g") 
    #.config("spark.executor.memory", "10g") 
    #.config("spark.executor.memoryOverhead", "1g") 
    .getOrCreate()
)

logger.info(f"reading counts from {args.output_counts}/finalcounts")
check = spark.read.csv(args.output_counts + "/finalcounts" , header=True).cache()

# check number of files written per audience
# logger.info(f"reading file path counts from {args.output_counts}/filecheck")
# check2 = spark.read.csv(args.output_counts + "/filecheck", header=True).cache()

# mxfiles = check2.agg({"count": "max"}).collect()[0][0]
# logger.info(f"maximum number of files in each audience folder {mxfiles}")

# check2 says how many files have been written for each audience, if its 1 each then we can do a straight move/rename to sts folder
# if its more than 1 then we need to do a merge

# list of audiences
audiences = [a[0] for a in check.select("audience").collect()]
logger.info(f"found {len(audiences)} audiences {audiences}")

logger.info(f"running getmerge to local sts folder {args.local_sts_folder}")

# make a tmp folder
os.makedirs(args.local_sts_folder + f"/tmp", exist_ok=True)

error = False

# merge the files
for a in audiences:
    logger.info(f"merging to {args.local_sts_folder}/Replace.TTD.{a}.{config.DATE_TIME}.csv files for audience {a}")
    subprocess.run(["hdfs", "dfs", "-getmerge", args.output + f"/audience={a}", args.local_sts_folder + f"/tmp/Replace.TTD.{a}.{config.DATE_TIME}.csv"])
    add_header_to_local_file(f"{args.local_sts_folder}/tmp/Replace.TTD.{a}.{config.DATE_TIME}.csv", "LatDeg,LongDeg,RadMet", f"{args.local_sts_folder}/Replace.TTD.{a}.{config.DATE_TIME}.csv")
    num = local_file_rows(f"{args.local_sts_folder}/Replace.TTD.{a}.{config.DATE_TIME}.csv")
    check_count = int(check.filter(check.audience == a).collect()[0][1])
    if (num - check_count) ==1:
        logger.info(f"removing {args.local_sts_folder}/tmp/Replace.TTD.{a}.{config.DATE_TIME}.csv")
        os.remove(f"{args.local_sts_folder}/tmp/Replace.TTD.{a}.{config.DATE_TIME}.csv")
    else:
        logger.error(f"file length {num} does not match check count {check_count} for audience {a}")
        error = True

if error==False:
    logger.info("all files merged and checked")
    sys.exit(0)
else:
    logger.error("error in file length check, see log for details")
    sys.exit(1)


# # if this is a local process and files only need to be moved use the mxfile checks to see that they are mv/ren 
# if mxfiles == 1:
#     logger.info(f"moving files to local sts folder {args.local_sts_folder}")
    
#     for a in audiences:
#         logger.info(f"copying to {args.local_sts_folder}/Replace.TTD.{a}.{config.DATE_TIME}.csv file for audience {a}")
#         subprocess.run(["hdfs", "dfs", "-copyToLocal", args.output + f"/audience={a}/*", args.local_sts_folder + f"/tmp/Replace.TTD.{a}.{config.DATE_TIME}.csv"])
#         add_header(f"{args.local_sts_folder}/tmp/Replace.TTD.{a}.{config.DATE_TIME}.csv", "LatDeg,LongDeg,RadMet", f"{args.local_sts_folder}/Replace.TTD.{a}.{config.DATE_TIME}.csv")
#         log_output_check(f"{args.local_sts_folder}/Replace.TTD.{a}.{config.DATE_TIME}.csv")
# else:
#     logger.info(f"running getmerge to local sts folder {args.local_sts_folder}")
#     # merge the files
#     for a in audiences:
#         logger.info(f"merging to {args.local_sts_folder}/Replace.TTD.{a}.{config.DATE_TIME}.csv files for audience {a}")
#         subprocess.run(["hdfs", "dfs", "-getmerge", args.output + f"/audience={a}", args.local_sts_folder + f"/tmp/Replace.TTD.{a}.{config.DATE_TIME}.csv"])
#         add_header(f"{args.local_sts_folder}/tmp/Replace.TTD.{a}.{config.DATE_TIME}.csv", "LatDeg,LongDeg,RadMet", f"{args.local_sts_folder}/Replace.TTD.{a}.{config.DATE_TIME}.csv")
#         log_output_check(f"{args.local_sts_folder}/Replace.TTD.{a}.{config.DATE_TIME}.csv")
