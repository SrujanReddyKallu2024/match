import pandas as pd
import sys
from pathlib import Path
import argparse
import os
from pyspark.sql import SparkSession, Window
import pyspark.sql.functions as F
from datetime import datetime, timedelta
import time

sys.path.append(str(Path(__file__).resolve().parents[2]))

import config as c
import functions


INF_CONFIG = [
    {
        "id": inf_id, 
        "datecol": "last_seen" if inf_id == "ip" else "" if (inf_id=="hems" or inf_id=="udprn") else "date",
        "id_path": c.INF_UDPRN_PATH if inf_id=="udprn" else c.IDG_GRAPH_PATH
    }
    for inf_id in c.INF_IDS
]


def format_graph(idgdf, idg_datecol, cutoff):
    """
    format the given graph
    """
    idgdf = idgdf.where(F.col(idg_datecol)> cutoff)
    
    return (
        idgdf        
        .withColumn("source_array", F.split(F.col("source"),","))
        .withColumn('source_count', F.size('source_array'))
        .withColumn('chv', F.when(F.array_contains(F.col('source_array'), 'chv'), F.lit(1)).otherwise(F.lit(0)))
        .withColumn('de', F.when(F.array_contains(F.col('source_array'), 'de'), F.lit(1)).otherwise(F.lit(0)))
        .withColumn('uc', F.when(F.array_contains(F.col('source_array'), 'uc'), F.lit(1)).otherwise(F.lit(0)))        
    )


def apply_rank(idgdf, idg, idg_datecol):
    """
    apply rank to the graph based on the given identifier
    """
    if idg == "ip":
        order_by_columns = [
            F.col(idg_datecol).desc(),
            F.col('source_count').desc(),
            F.col('chv').desc(),
            F.col('de').desc(),
            F.col('uc').desc()
        ]
    else:
        order_by_columns = [
            F.col('diff'),
            F.col('source_count').desc(),
            F.col('chv').desc(),
            F.col('de').desc(),
            F.col('uc').desc(),
            F.col(idg_datecol).desc()
        ]

    winSpec1= Window.partitionBy('match_id').orderBy(*order_by_columns)
    winSpec2= Window.partitionBy(idg).orderBy(*order_by_columns)
    return (
        idgdf
        .withColumn('rnum', F.row_number().over(winSpec1))
        .where(F.col('rnum')<= 5)
        .withColumn('rnum2', F.row_number().over(winSpec2))
        .where(F.col('rnum2')<= 3) #TODO: This is where it restricts the count of identifiers per matchid, confirm if this is fine
    )


def agg_graph(df, idg, datecol):
    """
    aggregate the graph based on matchid and the identifier and calculate the max last_seen
    """    
    return (
        df
        .groupby('match_id', idg)
        .agg(F.max(datecol).alias('last_seen'))
    ) 


def format_output(df, inf_id):
    """
    format the output data to be 1 row per HHK with ids separated by pipe delimiter
    """
    df1 = (
        df
        .select(F.col("match_id_infosum").alias("match_id"), inf_id)
    )
    return(
        df1
        .groupBy("match_id")        
        .agg(F.concat_ws('|', F.collect_set(inf_id)).alias(inf_id))
    )


def logic_main(ctx, logger, mask, idg_lookup_path, lookup_window, inf_config, tax_path, out_path, email_to):
    logger.info(f"running inf01_generate_data script for mask: {mask}")
    quick_stats = []
    try:
        startime = datetime.now()
        try:
            inf_lookup_file = functions.latest_hdfs_file(f"{idg_lookup_path}/infosum", pattern = 'match_id_lookup_infosum')
            logger.info(f"infosum lookup file: {inf_lookup_file}")

            exp_lookup_file = functions.latest_hdfs_file(f"{idg_lookup_path}/experian", pattern = 'match_id_lookup_experian')
            logger.info(f"experian lookup file: {exp_lookup_file}")

            inf_lookup = ctx.read.parquet(inf_lookup_file).cache()            
            logger.info("read infosum lookup data")

            exp_lookup = ctx.read.parquet(exp_lookup_file).cache()            
            logger.info("read experian lookup data")

            functions.update_stats(quick_stats, "Loaded Infosum MatchIds", "Success", f"Latest Infosum lookup: {inf_lookup_file}, Experian lookup: {exp_lookup_file}, count of infosum matchids: {inf_lookup.count()} and count of experian matchids: {exp_lookup.count()}")
        except Exception as e:
            functions.update_stats(quick_stats, "Loaded Infosum MatchIds", "Failed", str(e))
            raise

        
        inf_ids = [i['id'] for i in inf_config]
        logger.info(f"all ids requested by infosum: {inf_ids}")

        for inf_id in inf_ids:
            inf_id_cap = inf_id.upper()
            ## Read Data           
            try:                
                id_path = [i['id_path'] for i in inf_config if i["id"]==inf_id][0]

                if inf_id != "udprn":
                    id_file = functions.latest_hdfs_file(f"{id_path}/{inf_id}", pattern=inf_id)
                else:
                    id_file = functions.latest_hdfs_file(f"{id_path}/20*/", pattern="udprn_lat_lon.parquet")
                logger.info(f"id graph file for {inf_id}: {id_file}")

                id_df = ctx.read.parquet(id_file)
                logger.info(f"read id graph data for {inf_id}")

                id_datecol = [i['datecol'] for i in inf_config if i["id"]==inf_id][0]
                logger.info(f"date column to be used for {inf_id}: {id_datecol}")

                functions.update_stats(quick_stats, f"{inf_id_cap} Data Load", "Success", f"Latest {inf_id} data: {id_file} loaded with {id_df.count():,} records, datecolumn: {id_datecol}")
            except Exception as e:
                functions.update_stats(quick_stats, f"{inf_id_cap} Data Load", "Failed", str(e))
                raise
            
            ## Format Data
            try:
                cutoff = (startime - timedelta(days= lookup_window)).strftime("%Y-%m-%d")
                logger.info(f"cut off date for {inf_id}: {cutoff}")

                if inf_id not in ["hems","udprn"]:
                   idg_fmt = format_graph(id_df, id_datecol, cutoff)
                   logger.info(f"formatted id graph data with newer than {cutoff} date, updated count: {idg_fmt.count()}")

                   idg_ranked = apply_rank(idg_fmt, inf_id, id_datecol).cache()
                   logger.info(f"ranked id graph data, updated count: {idg_ranked.count()}")
                   
                   if inf_id == "maids":
                    idg_ranked = idg_ranked.where(F.col('week0')> 0)
                    logger.info(f"filtered maids graph data for week0 > 0, updated count: {idg_ranked.count()}")
                    
                   id_deduped = agg_graph(idg_ranked, inf_id, id_datecol).cache()
                   logger.info(f"grabbed the latest record in the id graph data , updated count: {id_deduped.count()}")
                   idg_ranked.unpersist()
                else:
                    id_deduped = id_df
                    logger.info(f"no formatting required for {inf_id}, updated count: {id_deduped.count()}")
                
                functions.update_stats(quick_stats, f"{inf_id_cap} Data Format", "Success", f"Formatted {inf_id} data, updated count: {id_deduped.count()}")
            except Exception as e:
                functions.update_stats(quick_stats, f"{inf_id_cap} Data Format", "Failed", str(e))
                raise

            ## Join with lookup
            try:
                if inf_id!='udprn':
                    id_with_lookup = id_deduped.join(inf_lookup, on='match_id', how='inner').drop("match_id").cache()
                    logger.info(f"joined {inf_id} data with lookup, updated count: {id_with_lookup.count()}")
                    id_deduped.unpersist()
                else:
                    latest_tax_dir = functions.latest_hdfs_file(tax_path, pattern='2')
                    logger.info(f"latest taxonomy folder: {latest_tax_dir}")

                    latest_tax_file = os.path.join(latest_tax_dir, "process", "taxonomy.parquet")
                    logger.info(f"latest taxonomy file: {latest_tax_file}")

                    tax_df = ctx.read.parquet(latest_tax_file).select('cb_key_household', 'UDPRN').distinct().cache()
                    logger.info(f"read taxonomy data, unique udprn and cbk combination count: {tax_df.count()}")

                    tax_with_mid = tax_df.join(exp_lookup, on='cb_key_household', how='inner').select('match_id', 'UDPRN').withColumnRenamed("UDPRN", "udprn")
                    logger.info(f"joined taxonomy data with lookup, updated count: {tax_with_mid.count()}")

                    tax_with_info_mid = tax_with_mid.join(inf_lookup, on='match_id', how='inner').select('match_id_infosum', 'udprn').cache()
                    logger.info(f"joined taxonomy data with infosum lookup, updated count: {tax_with_info_mid.count()}")
                    tax_df.unpersist()                    

                    id_with_lookup = tax_with_info_mid

                functions.update_stats(quick_stats, f"{inf_id_cap} Data with MatchId", "Success", f"Joined {inf_id} data with lookup, updated count: {id_with_lookup.count()}")
            except Exception as e:
                functions.update_stats(quick_stats, f"{inf_id_cap} Data with MatchId", "Failed", str(e))
                raise

            ## Final Formatting
            try:
                final_data = format_output(id_with_lookup, inf_id).cache()
                logger.info(f"final data for {inf_id} with matchid, updated count: {final_data.count()}")

                functions.update_stats(quick_stats, f"{inf_id_cap} Data Final Format", "Success", f"Formatted {inf_id} data with matchid, updated count: {final_data.count()}")
            except Exception as e:
                functions.update_stats(quick_stats, f"{inf_id_cap} Data Final Format", "Failed", str(e))
                raise

            ## Write Data
            try:
                output_path = out_path.format(ident=inf_id)
                final_data.repartition(1).write.mode("overwrite").csv(output_path, header=True)
                logger.info(f"written {inf_id} data with matchid to path: {output_path}")
                final_data.unpersist()

                functions.update_stats(quick_stats, f"{inf_id_cap} Data Write", "Success", f"{inf_id} data written to path: {output_path}")
            except Exception as e:
                functions.update_stats(quick_stats, f"{inf_id_cap} Data Write", "Failed", str(e))
                raise

            ## Rename files
            time.sleep(60)

            try:
                ## Rename single part file to i.e. infosum_{inf_id}_graph_{mask}.csv
                all_id_files = functions.get_all_files(out_path.format(ident=inf_id))
                logger.info(f"all {inf_id} files: {all_id_files}")

                if len(all_id_files) == 0:
                    raise Exception("No files found to rename")

                functions.rename_files(logger, mask, all_id_files, inf_id, new_name_template = f"infosum_{{graph_type}}_graph_{{mask}}.csv")

                new_files = functions.get_all_files(out_path.format(ident=inf_id))
                logger.info(f"new_files : {','.join(new_files)}")

                functions.update_stats(quick_stats, f"{inf_id_cap} Graph Rename", "Success", f"Renamed {len(all_id_files)} {inf_id} graph files as per Infosum Format i.e. {new_files[0]}")
            except Exception as e:
                functions.update_stats(quick_stats, f"{inf_id_cap} Graph Rename", "Failed", str(e))
                raise

        success_flag = True
    except Exception as e:
        logger.error(e)
        success_flag = False
        functions.send_status_email("Error: inf01_generate_data script failed", e, email_to)
        raise
    finally:
        alerts_df = pd.DataFrame(quick_stats)    
        email_sub = f"***INFO01 - Generate Infosum Data - {c.STATUS_EMOJIS['green']}***" if success_flag else f"***INFO01 - Generate Infosum Data - {c.STATUS_EMOJIS['red']}***"
        functions.send_teams_email(mask, email_sub, alerts_df.to_html(index=False))
        endtime = datetime.now()
        logger.info(f"process completed in {str(endtime - startime).split('.')[0]}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-m", "--mask", help="date on which process is run in format YYYY-MM-DD", default=c.TODAY_DATE)
    parser.add_argument("-ilp", "--idg_lookup_path", help="idgraph parent lookup file path", default=c.LOOKUP_FILE_PATH)    
    parser.add_argument("-lw", "--lookup_window", help="lookup window for insofum", default=c.INF_LOOKUP_WINDOW)    
    parser.add_argument("-ic", "--inf_config", help="ids requested by infosum", default=INF_CONFIG)
    parser.add_argument("-tp", "--tax_path", help="ids requested by infosum", default=c.TAX_PATH)
    parser.add_argument("-op", "--out_path", help="cleaned audigent scodes are written out to this hdfs csv file path")
    parser.add_argument("-et", "--email_to", help="recipients of email alerts", default=c.EMAIL_TO)
    
    args = parser.parse_args()

    if args.out_path is None:
        args.out_path = f"{c.INF_PATH_HDFS}/{args.mask}/infosum_{{ident}}_graph.csv"

    name = os.path.basename(__file__)
    logger = c.LogConfig(f"{c.LOGPATH}/{name}_{args.mask}.log").generate_logger(name)
    spark = SparkSession.builder.appName(f"{name}_{args.mask}").getOrCreate()

    logic_main(spark, logger, args.mask, args.idg_lookup_path, args.lookup_window, args.inf_config, args.tax_path, args.out_path, args.email_to)
