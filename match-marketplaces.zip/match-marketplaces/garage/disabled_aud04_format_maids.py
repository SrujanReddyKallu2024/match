from pathlib import Path
import sys
from pyspark.sql import SparkSession, Window
import pyspark.sql.functions as F
import argparse
import time

sys.path.append(str(Path(__file__).resolve().parents[1]))

from config import *
from functions import *


def format_maids_graph(df):
    """
    format the maids graph
    """
    return (
        df
        .withColumn("source_array", F.split(F.col("source"),","))
        .withColumn('source_count', F.size('source_array'))
        .withColumn('chv', F.when(F.array_contains(F.col('source_array'), 'chv'), F.lit(1)).otherwise(F.lit(0)))
        .withColumn('de', F.when(F.array_contains(F.col('source_array'), 'de'), F.lit(1)).otherwise(F.lit(0)))
        .withColumn('uc', F.when(F.array_contains(F.col('source_array'), 'uc'), F.lit(1)).otherwise(F.lit(0)))
    )
    

def apply_rank(df):
    """
    apply rank to the dataframe
    """
    winspec1 = (
        Window
        .partitionBy('match_id')
        .orderBy(
            F.col('diff'),
            F.col('source_count').desc(),
            F.col('chv').desc(),
            F.col('de').desc(),
            F.col('uc').desc(),
            F.col('date').desc()
        )
    )
    winspec2= (
        Window.partitionBy('maids')
        .orderBy(
            F.col('diff'),
            F.col('source_count').desc(),
            F.col('chv').desc(),
            F.col('de').desc(),
            F.col('uc').desc(),
            F.col('date').desc()    
        )
    )
    return (
        df
        .withColumn('rnum', F.row_number().over(winspec1))
        .where(F.col('rnum')<= 5)
        .withColumn('rnum2', F.row_number().over(winspec2))
        .where(F.col('rnum2')<= 3)
    )


def logic_main(ctx, logger, mask, idg_graph_path, idg_lookup_path, mid_with_scodes_path, out_path, email_to):
    logger.info(f"running preprocess stats for mask: {mask}")
    try:
        startime = datetime.now()        
        date180= (startime - datetime.timedelta(days= 180)).strftime("%Y-%m-%d")

        ##maids Graph
        idg_maids_file = latest_hdfs_file(f"{idg_graph_path}/maids", pattern='maids')
        logger.info("latest maids graph file: {idg_maids_file}}")

        idg_maids = ctx.read.parquet(idg_maids_file)
        logger.info("read latest maids graph")        

        idg_maids_fmt = format_maids_graph(idg_maids)
        logger.info("formatted maids graph")

        idg_maids_ranked = apply_rank(idg_maids_fmt).where(F.col('week0')> 0)
        logger.info("ranked maids graph")

        idg_maids_agg = (
            idg_maids_ranked
            .select('match_id', 'maids')
            .distinct()
        )
        idg_maids_agg.cache().count()
        logger.info("identified unique combination of match_id and maids")

        aud_lookup_file = latest_hdfs_file(f"{idg_lookup_path}/audigent", pattern = 'match_id_lookup_audigent')
        logger.info(f"audigent lookup file: {aud_lookup_file}")
        
        aud_lookup = ctx.read.parquet(aud_lookup_file)
        logger.info("read audigent lookup data")

        idg_maids_mids = aud_lookup.join(idg_maids_agg, 'match_id', 'inner').drop("match_id")
        logger.info("joined audigent lookup with aggregated maids graph")       

        mid_with_scodes_file = latest_hdfs_file(mid_with_scodes_path, pattern='mid_with_scodes')
        logger.info(f"latest matchid with scodes file: {mid_with_scodes_file}")

        mid_with_scodes = ctx.read.parquet(mid_with_scodes_file)
        logger.info("read matchid with scodes data")

        final_idg_maids = (
            idg_maids_mids
            .join(mid_with_scodes, 'match_id_audigent', 'inner')
            .withColumnRenamed('match_id_audigent', 'hh_id')
            .select('hh_id', 'maids', 's_code')
        )
        logger.info("joined formatted maids graph with matchid with scodes to get final audigent maids graph")

        final_idg_maids.repartition(10).write.csv(out_path, header=True, mode='overwrite', compression='gzip')
        logger.info(f"written output to path: {out_path}")

        time.sleep(60)

        ## Rename it based on Audigent format i.e. UK__experianuk_maids_UK_{mask}_001.csv.gz
        all_maids_files = get_all_files(out_path)
        logger.info(f"all maids files: {all_maids_files}")

        rename_files(logger, mask, all_maids_files, 'maids')        

    except Exception as e:
        logger.error(e)
        send_status_email("Error: aud02_format_maids script failed", e, email_to)
        raise
    finally:
        endtime = datetime.now()
        logger.info(f"process completed in {str(endtime - startime).split('.')[0]}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-m", "--mask", help="date on which process is run in format YYYY-MM-DD", default=TODAY_DATE)
    parser.add_argument("-igp", "--idg_graph_path", help="idgraph parent path", default=IDG_GRAPH_PATH)
    parser.add_argument("-ilp", "--idg_lookup_path", help="idgraph parent lookup file path", default=LOOKUP_FILE_PATH)
    parser.add_argument("-mwsp", "--mid_with_scodes_file", help="parent matchid to scodes file path", default=LOOKUP_FILE_PATH)
    parser.add_argument("-op", "--out_path", help="cleaned audigent scodes are written out to this hdfs csv file path")
    parser.add_argument("-et", "--email_to", help="recepients of email alerts", default=EMAIL_TO)
    

    args = parser.parse_args()

    if args.out_path is None:
        args.out_path = f"{AUD_PATH_HDFS}/{args.mask}/audigent_maids_graph.csv"

    name = os.path.basename(__file__)
    logger = LogConfig(f"{LOGPATH}/{name}_{args.mask}.log").generate_logger(name)
    spark = SparkSession.builder.appName(f"aud02_{args.mask}").getOrCreate()
    logic_main(spark, logger, args.mask)

