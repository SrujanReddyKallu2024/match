

import os
import sys
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, IntegerType
from timeit import default_timer as timer
import pandas as pd
import contextlib
import datetime   
import contextlib                                                               
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
import time
from collections import Counter
import numpy as np
import re
import time

import pandas as pd
import pyspark.pandas as ps

# SETTINGS ----------------------------------------------------------------------------------------



# match-id ----------------------------------------------------------------------------------------
filename= latest_file('/user/unity/id_graph/lookup/audigent', pattern= 'match_id_lookup_audigent')
filename

id01= spark.read.parquet(filename)
id01.show()
id01.count()


filename= latest_file('/user/unity/id_graph/lookup/experian', pattern= 'match_id_lookup_experian')
filename

id02= spark.read.parquet(filename)
id02.show()
id02.count()

#id03= id01.join(id02, 'match_id', 'inner').select('cb_key_household', 'match_id_evorra')
#id03.count()

temp= id02.join(id01, 'match_id', 'inner')
id03= temp.select('cb_key_household', 'match_id_audigent')
id03.show()

id01= id01.select('match_id', 'match_id_audigent')
id01.show()


# S_Codes ----------------------------------------------------------------------------------------
#sup01= pd.read_csv('/data/griffin/evorra_suppression.csv')
#pub01= pd.read_csv('/data/griffin/S_CODE_PUBMATIC.csv')
#pub01

aud01= pd.read_excel('/data/data_from_sts/marketplace_input_files/audigent_marketplacefile_2024-12-04.xlsx')
aud01

#sup01['flag']= 1
#sup01

#ev01= pd.merge(pub01, sup01, how= 'left', on= 'S_Code')
#ev01

#ev02= ev01[ev01['flag']!=1]
#ev02

aud03= ps.from_pandas(aud01)
aud04= aud03.to_spark()
aud05= aud04.drop('flag')
aud05.show()
aud05.count()

aud06= aud05.withColumn('S_Code', F.regexp_replace('UK Taxonomy S codes', r'^S[0]*', 'S')).drop('UK Taxonomy S codes')
aud06.show()

# taxonomy ----------------------------------------------------------------------------------------
filename= latest_file('/user/unity/match2/taxonomy', pattern= '2')
filename

tx01= spark.read.parquet(f'{filename}/process/dt_long_cb_key_hh_s.parquet')
# tx01.show()
# tx01.groupby('S_Code').count().show()
# tx01.groupby('S_Code').count().count()

# check= tx01.groupby('S_Code').count()

# check2= check.join(aud06, 'S_Code', 'inner')
# check2.count()

# tx01.show()


# tx01.count()
# tx01.groupby('cb_key_household', 'S_Code').count().count()

# join evorra codes
tx02= tx01.select('cb_key_household', 'S_Code').join(aud06, 'S_Code', 'inner')
tx02.groupby('S_Code').count().count()


# Put S_Codes into list
tx03= tx02.groupby('cb_key_household').agg(F.collect_list('S_Code').alias('S_Code'))
tx04= tx03.withColumn('SEGID', F.concat_ws(',', 'S_Code')).drop('S_Code')
tx05= id03.join(tx04, 'cb_key_household', 'inner').drop('cb_key_household').withColumnRenamed('SEGID', 's_code')
tx05.write.parquet('datascience/griffin/audigent/tx05.parquet', mode= 'overwrite')
tx06= spark.read.parquet('datascience/griffin/audigent/tx05.parquet')
tx06.show()


# ip ----------------------------------------------------------------------------------------------
# maids with type no gz -------------------------------------------------------------------------------------------
latest_ip= latest_file('/user/unity/id_graph/graphs/ip', 'ip_')
latest_ip

ip01= spark.read.parquet(latest_ip)
#ip01.show()
#ip01.printSchema()

now= datetime.datetime.now()
nowdate = now.strftime("%Y-%m%-d")
nowdate

date180= now- datetime.timedelta(days= 180)
date180 = date180.strftime("%Y-%m-%d")
date180


# ty01= ip01.groupby('maids', 'type_uid').count().drop('count').withColumnRenamed('type_uid', 'type').cache()
# ty01.count()
# ty01.show()
# #ty01.groupby('maids').count().count()

# window1= Window.partitionBy('maids') \
    # .orderBy(
        # F.col('type')
    # )

# ty02= ty01.withColumn('rnum', F.row_number().over(window1))
# ty03= ty02.where(F.col('rnum')<= 1).drop('rnum').cache()

# ty03.count()
# #ty03.groupBy('maids').count().count()
# #ty03.groupby('type').count().show()
# ty03.show()

ip02= ip01.where(F.col('last_seen')> date180)
ip02.show()

ip03= ip02.withColumn("source_array", F.split(F.col("source"),","))
#ip03.show()
ip04= ip03.withColumn('source_count', F.size('source_array'))
#ip04.show()

#ip04.groupby('source').count().show()

ip05= ip04.withColumn('chv', F.when(F.array_contains(F.col('source_array'), 'chv'), F.lit(1)).otherwise(F.lit(0)))
ip06= ip05.withColumn('de', F.when(F.array_contains(F.col('source_array'), 'de'), F.lit(1)).otherwise(F.lit(0)))
ip07= ip06.withColumn('uc', F.when(F.array_contains(F.col('source_array'), 'uc'), F.lit(1)).otherwise(F.lit(0)))
#ip07.show()

window1= Window.partitionBy('match_id') \
    .orderBy(
        F.col('last_seen').desc(), \
        F.col('source_count').desc(), \
        F.col('chv').desc(), \
        F.col('de').desc(), \
        F.col('uc').desc() 
    )

ip08= ip07.withColumn('rnum', F.row_number().over(window1))
ip09= ip08.where(F.col('rnum')<= 5)
#ip09.show()

window2= Window.partitionBy('ip') \
    .orderBy(
        F.col('last_seen').desc(), \
        F.col('source_count').desc(), \
        F.col('chv').desc(), \
        F.col('de').desc(), \
        F.col('uc').desc(), \
    )

ip10= ip09.withColumn('rnum2', F.row_number().over(window2))
ip11= ip10.where(F.col('rnum2')<= 3)

#ip12.unpersist()
# ip12= ip11.where(F.col('week0')> 0).cache()
# ip12.count()
#ip12.show()
#ip12.groupby('match_id').count().count()
#ip12.groupby('maids').count().count()

#ip12.count()
#ip12.groupby('match_id', 'maids').count().count()

#ip14.unpersist()
ip14= ip11.groupby('match_id', 'ip').agg(F.max('last_seen').alias('last_seen')).cache()
ip14.count()




# Join evorra match id ----------------------------------------------------------------------------
#id01.show()
ip15= id01.join(ip14, 'match_id', 'inner').drop('match_id')
ip15.show()
#ip15.count()
#ip15.groupby('match_id_evorra', 'maids').count().count()
#ip15_2= ip15.join(ty03, 'maids', 'inner')
#ip15_2.count()
#ip15_2.show()

#tx06.show()
ip16= ip15.join(tx06, 'match_id_audigent', 'inner').withColumnRenamed('match_id_audigent', 'hh_id')
#ip16.show()
#ip16.count()
#ip16.groupby('hh_id', 'maids').count().count()
#ip16.count()
#ip16.select('maids').show(truncate= False)
ip16_2= ip16.select('hh_id', 'ip', 'last_seen', 's_code')
# ip16_3= ip16_2.withColumn('type',
    # F.when(F.col('type')== 'android', 'gaid').otherwise(F.col('type'))
# )
#ip16_3.show()

ip16_2.write.parquet('datascience/griffin/audigent/output/temp.parquet', mode= 'overwrite')
ip17= spark.read.parquet('datascience/griffin/audigent/output/temp.parquet')
ip17.show()

ip17.repartition(3).write.csv('datascience/griffin/audigent/output/ip.csv', header= True, mode= 'overwrite')
#check= spark.read.parquet('datascience/griffin/evorra/output/maids.parquet')
#check.show()

os.system(f'hdfs dfs -rm -r datascience/griffin/audigent/output/temp.parquet')

lst= list_files('/user/unity/datascience/griffin/audigent/output/ip.csv', pattern= 'part')
lst

loc= '/user/unity/datascience/griffin/audigent/output/ip.csv'
locl= '/data/griffin/audigent/output'
locf= '/data/data_to_sts/marketplaces/audigent/data'
part1= lst[0].split('/')[-1]
part2= lst[1].split('/')[-1]
part3= lst[2].split('/')[-1]
part1
part2
part3
ident= 'ip'

os.system(f'hdfs dfs -get {loc}/{part1} {locl}')
os.system(f'hdfs dfs -get {loc}/{part2} {locl}')
os.system(f'hdfs dfs -get {loc}/{part3} {locl}')

# os.system(f'gzip {locl}/{part1}')
# os.system(f'gzip {locl}/{part2}')
# os.system(f'gzip {locl}/{part3}')

now= datetime.datetime.now()
nowdate = now.strftime("%Y-%m-%d")
nowdate

os.system(f'mv {locl}/{part1} {locl}/UK__experianuk_{ident}_UK_{nowdate}_001.csv')
os.system(f'mv {locl}/{part2} {locl}/UK__experianuk_{ident}_UK_{nowdate}_002.csv')
os.system(f'mv {locl}/{part3} {locl}/UK__experianuk_{ident}_UK_{nowdate}_003.csv')

os.system(f'gzip {locl}/UK__experianuk_{ident}_UK_{nowdate}_001.csv')
os.system(f'gzip {locl}/UK__experianuk_{ident}_UK_{nowdate}_002.csv')
os.system(f'gzip {locl}/UK__experianuk_{ident}_UK_{nowdate}_003.csv')

# os.system(f'mkdir /data/griffin/evorra/output/EXPERIAN_MAIDS')
# os.system(f'mv /data/griffin/evorra/output/experian_maids_* /data/griffin/evorra/output/EXPERIAN_MAIDS')

# cd /data/griffin/evorra/output
# zip -r EXPERIAN_MAIDS.zip EXPERIAN_MAIDS
# rm -r EXPERIAN_MAIDS

# unzip EXPERIAN_MOBILE.zip

os.system(f'cp {locl}/* {locf}')
os.system(f'chown -R unity:stsgrp {locf}')
os.system(f'chmod -R 774 {locf}')

os.system(f'hdfs dfs -rm -r datascience/griffin/evorra/output/ip.parquet')




# hems --------------------------------------------------------------------------------------------
filename= latest_file('/user/unity/id_graph/graphs/hems', 'hems')
filename

hm01= spark.read.parquet(filename)
hm01.show()
hm01.count()

id01.show()
hm02= id01.join(hm01, 'match_id', 'inner').drop('match_id')
hm02.show()

hm02_2= hm02.groupby('match_id_audigent').count()
hm02_2.count()

hm02_3= hm02_2.where(F.col('count')<= 50)
hm02_3.count()

hm02_4= hm02_3.select('match_id_audigent').join(hm02, 'match_id_audigent', 'inner')
hm02_4.groupby('hems').count().count()
hm02.groupby('hems').count().count()
hm02_4.show()
hm02.show()

hm03= hm02_4.join(tx06, 'match_id_audigent', 'inner').withColumnRenamed('match_id_audigent', 'hh_id')
#hm03.show()
#hm03.count()
#hm03.groupby('hh_id', 'hems').count().count()
#hm03.show()

hm03.repartition(2).write.csv('datascience/griffin/audigent/output/hems.csv', header= True, mode= 'overwrite')

lst= list_files('/user/unity/datascience/griffin/audigent/output/hems.csv', pattern= 'part')
lst

part0= lst[0]
part1= lst[1]
ident= 'hems'

os.system(f'hdfs dfs -get {part0} /data/griffin/audigent/output')
os.system(f'hdfs dfs -get {part1} /data/griffin/audigent/output')

# os.system(f'gzip /data/griffin/audigent/output/part-00000-5db16ff5-2889-46fb-ae63-682f75ade33b-c000.snappy.parquet')
# os.system(f'gzip /data/griffin/audigent/output/part-00001-5db16ff5-2889-46fb-ae63-682f75ade33b-c000.snappy.parquet')

now= datetime.datetime.now()
nowdate = now.strftime("%Y-%m-%d")
nowdate

os.system(f"mv /data/griffin/audigent/output/{part0.split('/')[-1]} /data/griffin/audigent/output/UK__experianuk_{ident}_UK_{nowdate}_001.csv")
os.system(f"mv /data/griffin/audigent/output/{part1.split('/')[-1]} /data/griffin/audigent/output/UK__experianuk_{ident}_UK_{nowdate}_002.csv")

#loc= '/user/unity/datascience/griffin/audigent/output/hems.parquet'
locl= '/data/griffin/audigent/output'
locf= '/data/data_to_sts/marketplaces/audigent/data'

os.system(f'gzip {locl}/UK__experianuk_{ident}_UK_{nowdate}_001.csv')
os.system(f'gzip {locl}/UK__experianuk_{ident}_UK_{nowdate}_002.csv')

os.system(f'cp {locl}/UK__experianuk_hems_UK* {locf}')
os.system(f'chown -R unity:stsgrp {locf}')
os.system(f'chmod -R 774 {locf}')

os.system(f'hdfs dfs -rm -r datascience/griffin/audigent/output/hems.parquet')


# os.system(f'mkdir /data/griffin/audigent/output/EXPERIAN_HEMS')
# os.system(f'mv /data/griffin/audigent/output/experian_hems_* /data/griffin/audigent/output/EXPERIAN_HEMS')

# cd /data/griffin/audigent/output
# zip -r EXPERIAN_HEMS.zip EXPERIAN_HEMS
# rm -r EXPERIAN_HEMS

# unzip EXPERIAN_HEMS.zip

# os.system(f'mv /data/griffin/audigent/output/* /data/data_to_sts/marketplaces/audigent')
# os.system(f'chown -R unity:stsgrp /data/data_to_sts/marketplaces/audigent/')
# os.system(f'chmod -R 774 /data/data_to_sts/marketplaces/audigent/')

# check= spark.read.parquet('datascience/griffin/audigent/output/hems.parquet')
# check.show()

# check2= check.where(F.col('s_code').contains('528,'))
# check2.show(truncate= False)


# maids with type no gz -------------------------------------------------------------------------------------------
latest_md= latest_file('/user/unity/id_graph/graphs/maids', 'maids_')
latest_md

md01= spark.read.parquet(latest_md)
#md01.show()
#md01.printSchema()

# ty01= md01.groupby('maids', 'type_uid').count().drop('count').withColumnRenamed('type_uid', 'type').cache()
# ty01.count()
# ty01.show()
# #ty01.groupby('maids').count().count()

# window1= Window.partitionBy('maids') \
    # .orderBy(
        # F.col('type')
    # )

# ty02= ty01.withColumn('rnum', F.row_number().over(window1))
# ty03= ty02.where(F.col('rnum')<= 1).drop('rnum').cache()

# ty03.count()
# #ty03.groupBy('maids').count().count()
# #ty03.groupby('type').count().show()
# ty03.show()


md03= md01.withColumn("source_array", F.split(F.col("source"),","))
#md03.show()
md04= md03.withColumn('source_count', F.size('source_array'))
#md04.show()

#md04.groupby('source').count().show()

md05= md04.withColumn('chv', F.when(F.array_contains(F.col('source_array'), 'chv'), F.lit(1)).otherwise(F.lit(0)))
md06= md05.withColumn('de', F.when(F.array_contains(F.col('source_array'), 'de'), F.lit(1)).otherwise(F.lit(0)))
md07= md06.withColumn('uc', F.when(F.array_contains(F.col('source_array'), 'uc'), F.lit(1)).otherwise(F.lit(0)))
#md07.show()

window1= Window.partitionBy('match_id') \
    .orderBy(
        F.col('diff'), \
        F.col('source_count').desc(), \
        F.col('chv').desc(), \
        F.col('de').desc(), \
        F.col('uc').desc(), \
        F.col('date').desc()    
    )

md08= md07.withColumn('rnum', F.row_number().over(window1))
md09= md08.where(F.col('rnum')<= 5)
#md09.show()

window2= Window.partitionBy('maids') \
    .orderBy(
        F.col('diff'), \
        F.col('source_count').desc(), \
        F.col('chv').desc(), \
        F.col('de').desc(), \
        F.col('uc').desc(), \
        F.col('date').desc()    
    )

md10= md09.withColumn('rnum2', F.row_number().over(window2))
md11= md10.where(F.col('rnum2')<= 3)

#md12.unpersist()
md12= md11.where(F.col('week0')> 0).cache()
md12.count()
#md12.show()
#md12.groupby('match_id').count().count()
#md12.groupby('maids').count().count()

#md12.count()
#md12.groupby('match_id', 'maids').count().count()

md14= md12.groupby('match_id', 'maids').count().drop('count').cache()
md14.count()



# Join evorra match id ----------------------------------------------------------------------------
#id01.show()
md15= id01.join(md14, 'match_id', 'inner').drop('match_id')
#md15.show()
#md15.count()
#md15.groupby('match_id_evorra', 'maids').count().count()
#md15_2= md15.join(ty03, 'maids', 'inner')
#md15_2.count()
#md15_2.show()

#tx06.show()
md16= md15.join(tx06, 'match_id_audigent', 'inner').withColumnRenamed('match_id_audigent', 'hh_id')
#md16.show()
#md16.count()
#md16.groupby('hh_id', 'maids').count().count()
#md16.count()
#md16.select('maids').show(truncate= False)
md16_2= md16.select('hh_id', 'maids', 's_code')
# md16_3= md16_2.withColumn('type',
    # F.when(F.col('type')== 'android', 'gaid').otherwise(F.col('type'))
# )
#md16_3.show()

md16_2.write.parquet('datascience/griffin/audigent/output/temp.parquet', mode= 'overwrite')
md17= spark.read.parquet('datascience/griffin/audigent/output/temp.parquet')
md17.show()

md17.repartition(4).write.csv('datascience/griffin/audigent/output/maids.csv', header= True, mode= 'overwrite')
#check= spark.read.parquet('datascience/griffin/audigent/output/maids.parquet')
#check.show()

os.system(f'hdfs dfs -rm -r datascience/griffin/audigent/output/temp.parquet')

lst= list_files('/user/unity/datascience/griffin/audigent/output/maids.csv', pattern= 'part')
lst

loc= '/user/unity/datascience/griffin/audigent/output/maids.csv'
locl= '/data/griffin/audigent/output'
locf= '/data/data_to_sts/marketplaces/audigent/data'
part1= lst[0].split('/')[-1]
part2= lst[1].split('/')[-1]
part3= lst[2].split('/')[-1]
part4= lst[3].split('/')[-1]
part1
part2
part3
part4
ident= 'maids'

os.system(f'hdfs dfs -get {loc}/{part1} /data/griffin/audigent/output')
os.system(f'hdfs dfs -get {loc}/{part2} /data/griffin/audigent/output')
os.system(f'hdfs dfs -get {loc}/{part3} /data/griffin/audigent/output')
os.system(f'hdfs dfs -get {loc}/{part4} /data/griffin/audigent/output')

# os.system(f'gzip {locl}/{part1}')
# os.system(f'gzip {locl}/{part2}')
# os.system(f'gzip {locl}/{part3}')

# now= datetime.datetime.now()
# nowdate = now.strftime("%Y-%m-%d")
# nowdate

nowdate= '2024-12-06'

os.system(f"mv /data/griffin/audigent/output/{part1} /data/griffin/audigent/output/UK__experianuk_{ident}_UK_{nowdate}_001.csv")
os.system(f"mv /data/griffin/audigent/output/{part2} /data/griffin/audigent/output/UK__experianuk_{ident}_UK_{nowdate}_002.csv")
os.system(f"mv /data/griffin/audigent/output/{part3} /data/griffin/audigent/output/UK__experianuk_{ident}_UK_{nowdate}_003.csv")
os.system(f"mv /data/griffin/audigent/output/{part4} /data/griffin/audigent/output/UK__experianuk_{ident}_UK_{nowdate}_004.csv")

os.system(f'gzip {locl}/UK__experianuk_{ident}_UK_{nowdate}_001.csv')
os.system(f'gzip {locl}/UK__experianuk_{ident}_UK_{nowdate}_002.csv')
os.system(f'gzip {locl}/UK__experianuk_{ident}_UK_{nowdate}_003.csv')
os.system(f'gzip {locl}/UK__experianuk_{ident}_UK_{nowdate}_004.csv')


# os.system(f'mkdir /data/griffin/audigent/output/EXPERIAN_MAIDS')
# os.system(f'mv /data/griffin/audigent/output/experian_maids_* /data/griffin/audigent/output/EXPERIAN_MAIDS')

# cd /data/griffin/audigent/output
# zip -r EXPERIAN_MAIDS.zip EXPERIAN_MAIDS
# rm -r EXPERIAN_MAIDS

# unzip EXPERIAN_MOBILE.zip

os.system(f'cp {locl}/UK__experianuk_maids* {locf}')
os.system(f'chown -R unity:stsgrp {locf}')
os.system(f'chmod -R 774 {locf}')

os.system(f'hdfs dfs -rm -r datascience/griffin/audigent/output/maids.parquet')





# UID with permission -------------------------------------------------------------------------------------------
latest_ud= latest_file('/user/unity/id_graph/graphs/uid', 'uid_')
latest_ud

ud01= spark.read.parquet(latest_ud)
#ud01.show()
#ud01.count()

#pm01= spark.read.parquet('match2/id5/*/id5_with_consent_*.parquet')
#pm01.show()
#pm01.groupby('tcf_consent').count().show()
#pm01.count()
# 68202383
#pm01.printSchema()

# pm02= pm01 \
    # .where(F.col('type_uid')== 'id5UID') \
    # .where(F.col('tcf_consent')== '1')

# pm03= pm02.withColumn('date', F.from_unixtime(F.col("timestamp")))
# pm04= pm03.withColumn('date', F.substring('date', 1, 10))
# #pm04.show()

# window1= Window.partitionBy('uid', 'date') \
    # .orderBy(
        # F.col('consent_string') 
    # )

# pm05= pm04.withColumn('rnum', F.row_number().over(window1))
# pm06= pm05.where(F.col('rnum')<= 1).select('uid','date','consent_string')
# pm07= pm06.where(F.col('date').isNotNull()).cache()
# pm07.count()
# pm07.show()

ud03= ud01.withColumn("source_array", F.split(F.col("source"),","))
#ud03.show()
ud04= ud03.withColumn('source_count', F.size('source_array'))
#ud04.show()

#ud04.groupby('source').count().show()

ud05= ud04.withColumn('chv', F.when(F.array_contains(F.col('source_array'), 'chv'), F.lit(1)).otherwise(F.lit(0)))
ud06= ud05.withColumn('de', F.when(F.array_contains(F.col('source_array'), 'de'), F.lit(1)).otherwise(F.lit(0)))
ud07= ud06.withColumn('uc', F.when(F.array_contains(F.col('source_array'), 'uc'), F.lit(1)).otherwise(F.lit(0)))
#ud07.show()

window1= Window.partitionBy('match_id') \
    .orderBy(
        F.col('diff'), \
        F.col('source_count').desc(), \
        F.col('chv').desc(), \
        F.col('de').desc(), \
        F.col('uc').desc(), \
        F.col('date').desc()    
    )

ud08= ud07.withColumn('rnum', F.row_number().over(window1))
ud09= ud08.where(F.col('rnum')<= 5)
#ud09.show()

window2= Window.partitionBy('uid') \
    .orderBy(
        F.col('diff'), \
        F.col('source_count').desc(), \
        F.col('chv').desc(), \
        F.col('de').desc(), \
        F.col('uc').desc(), \
        F.col('date').desc()    
    )

ud10= ud09.withColumn('rnum2', F.row_number().over(window2))
ud11= ud10.where(F.col('rnum2')<= 3)

ud12.unpersist()
ud12= ud11.where(F.col('week0')> 0).cache()
ud12.count()
ud12.show()
ud12.groupby('match_id').count().count()
ud12.groupby('uid').count().count()
ud12.count()
ud12.groupby('match_id', 'uid').count().count()

#pm07.show()
#ud12_2= ud12.join(pm07, ['uid','date'], 'inner')
#ud12_2.count()
#ud12.count()
#ud12_2.where(F.col('consent_string').isNull()).count()
#ud12_2.show()

#ud14= ud12_2.groupby('match_id', 'uid', 'consent_string').count().drop('count').cache()
ud14= ud12.groupby('match_id', 'uid').count().drop('count').cache()
ud14.count()
ud14.show()

# Join evorra match id ----------------------------------------------------------------------------
id01.show()
ud15= id01.join(ud14, 'match_id', 'inner').drop('match_id')
#ud15.show()
#ud15.count()
#ud15.groupby('match_id_audigent', 'maids').count().count()
#ud15_2= ud15.join(ty03, 'maids', 'inner')
#ud15_2.count()
#ud15_2.show()
#ud15.show()

#tx06.show()
ud16= ud15.join(tx06, 'match_id_audigent', 'inner').withColumnRenamed('match_id_audigent', 'hh_id')
#ud16.show()
#ud16.count()
#ud16.groupby('hh_id', 'maids').count().count()
#ud16.count()
#ud16.select('maids').show(truncate= False)
ud16_2= ud16.select('hh_id', 'uid', 's_code')
#ud16_2.show()

ud16_2.write.parquet('datascience/griffin/audigent/output/temp.parquet', mode= 'overwrite')
ud17= spark.read.parquet('datascience/griffin/audigent/output/temp.parquet')
ud17.show()

ud17.repartition(5).write.csv('datascience/griffin/audigent/output/uid.csv', header= True, mode= 'overwrite')
check= spark.read.csv('datascience/griffin/audigent/output/uid.csv', header= True)
check.show()

os.system(f'hdfs dfs -rm -r datascience/griffin/audigent/output/temp.parquet')

lst= list_files('/user/unity/datascience/griffin/audigent/output/uid.csv', pattern= 'part')
lst

loc= '/user/unity/datascience/griffin/audigent/output/uid.csv'
locl= '/data/griffin/audigent/output'
locf= '/data/data_to_sts/marketplaces/audigent/data'

part01= lst[0].split('/')[-1]
part02= lst[1].split('/')[-1]
part03= lst[2].split('/')[-1]
part04= lst[3].split('/')[-1]
part05= lst[4].split('/')[-1]

ident= 'uid'

os.system(f'hdfs dfs -get {loc}/{part01} /data/griffin/audigent/output')
os.system(f'hdfs dfs -get {loc}/{part02} /data/griffin/audigent/output')
os.system(f'hdfs dfs -get {loc}/{part03} /data/griffin/audigent/output')
os.system(f'hdfs dfs -get {loc}/{part04} /data/griffin/audigent/output')
os.system(f'hdfs dfs -get {loc}/{part05} /data/griffin/audigent/output')

# os.system(f'gzip {locl}/{part1}')
# os.system(f'gzip {locl}/{part2}')
# os.system(f'gzip {locl}/{part3}')

# now= datetime.datetime.now()
# nowdate = now.strftime("%Y-%m-%d")
# nowdate

nowdate= '2024-12-06'

os.system(f'mv {locl}/{part01} {locl}/UK__experianuk_{ident}_UK_{nowdate}_001.csv')
os.system(f'mv {locl}/{part02} {locl}/UK__experianuk_{ident}_UK_{nowdate}_002.csv')
os.system(f'mv {locl}/{part03} {locl}/UK__experianuk_{ident}_UK_{nowdate}_003.csv')
os.system(f'mv {locl}/{part04} {locl}/UK__experianuk_{ident}_UK_{nowdate}_004.csv')
os.system(f'mv {locl}/{part05} {locl}/UK__experianuk_{ident}_UK_{nowdate}_005.csv')

os.system(f'gzip {locl}/UK__experianuk_{ident}_UK_{nowdate}_001.csv')
os.system(f'gzip {locl}/UK__experianuk_{ident}_UK_{nowdate}_002.csv')
os.system(f'gzip {locl}/UK__experianuk_{ident}_UK_{nowdate}_003.csv')
os.system(f'gzip {locl}/UK__experianuk_{ident}_UK_{nowdate}_004.csv')
os.system(f'gzip {locl}/UK__experianuk_{ident}_UK_{nowdate}_005.csv')



# os.system(f'mkdir /data/griffin/audigent/output/EXPERIAN_UID')
# os.system(f'mv /data/griffin/audigent/output/experian_uid_* /data/griffin/audigent/output/EXPERIAN_UID')

# cd /data/griffin/audigent/output
# zip -r EXPERIAN_UID.zip EXPERIAN_UID
# rm -r EXPERIAN_UID

# unzip EXPERIAN_MOBILE.zip


os.system(f'cp {locl}/UK__experianuk_uid* {locf}')
os.system(f'chown -R unity:stsgrp {locf}')
os.system(f'chmod -R 774 {locf}')



os.system(f'hdfs dfs -rm -r datascience/griffin/audigent/output/uid.parquet')




# TTD + consent string -------------------------------------------
latest_ttd= latest_file('/user/unity/id_graph/graphs/ttdids', 'ttdids_')
latest_ttd

ttd01= spark.read.parquet(latest_ttd)
ttd01.show()

# pm01= spark.read.parquet('match2/id5/*/id5_with_consent_*.parquet')
# pm01.show()
# pm01.groupby('tcf_consent').count().show()
# pm01.count()
# # 68202383
# pm01.printSchema()

# pm02= pm01 \
    # .where(F.col('type_uid')== 'TradeDesk') \
    # .where(F.col('tcf_consent')== '1')

# pm03= pm02.withColumn('date', F.from_unixtime(F.col("timestamp")))
# pm04= pm03.withColumn('date', F.substring('date', 1, 10))
# pm04.show()
# pm04_2= pm04.withColumnRenamed('uid', 'ttdids')
# pm04_2.show()

# window1= Window.partitionBy('ttdids', 'date') \
    # .orderBy(
        # F.col('consent_string') 
    # )

# pm05= pm04_2.withColumn('rnum', F.row_number().over(window1))
# pm06= pm05.where(F.col('rnum')<= 1).select('ttdids','date','consent_string')
# pm07= pm06.where(F.col('date').isNotNull()).cache()
# pm07.count()
# pm07.show()


ttd03= ttd01.withColumn("source_array", F.split(F.col("source"),","))
ttd03.show()
ttd04= ttd03.withColumn('source_count', F.size('source_array'))
ttd04.show()

ttd04.groupby('source').count().show()

ttd05= ttd04.withColumn('chv', F.when(F.array_contains(F.col('source_array'), 'chv'), F.lit(1)).otherwise(F.lit(0)))
ttd06= ttd05.withColumn('de', F.when(F.array_contains(F.col('source_array'), 'de'), F.lit(1)).otherwise(F.lit(0)))
ttd07= ttd06.withColumn('uc', F.when(F.array_contains(F.col('source_array'), 'uc'), F.lit(1)).otherwise(F.lit(0)))
ttd07.show()

window1= Window.partitionBy('match_id') \
    .orderBy(
        F.col('diff'), \
        F.col('source_count').desc(), \
        F.col('chv').desc(), \
        F.col('de').desc(), \
        F.col('uc').desc(), \
        F.col('date').desc()    
    )

ttd08= ttd07.withColumn('rnum', F.row_number().over(window1))
ttd09= ttd08.where(F.col('rnum')<= 5)
ttd09.show()

window2= Window.partitionBy('ttdids') \
    .orderBy(
        F.col('diff'), \
        F.col('source_count').desc(), \
        F.col('chv').desc(), \
        F.col('de').desc(), \
        F.col('uc').desc(), \
        F.col('date').desc()    
    )

ttd10= ttd09.withColumn('rnum2', F.row_number().over(window2))
ttd11= ttd10.where(F.col('rnum2')<= 3)

ttd12.unpersist()
ttd12= ttd11.where(F.col('week0')> 0).cache()
ttd12.count()
ttd12.show()
#ttd12.groupby('match_id').count().count()
#ttd12.groupby('uid').count().count()
#ttd12.count()
#ttd12.groupby('match_id', 'uid').count().count()

#pm07.show()
#ttd12_2= ttd12.join(pm07, ['ttdids','date'], 'inner')
#ttd12_2.count()
#ttd12.count()
#ttd12_2.where(F.col('consent_string').isNull()).count()

ttd14= ttd12.groupby('match_id', 'ttdids').count().drop('count').cache()
ttd14.count()


# Join audigent match id ----------------------------------------------------------------------------
id01.show()
ttd15= id01.join(ttd14, 'match_id', 'inner').drop('match_id')
#ttd15.show()
#ttd15.count()
#ttd15.groupby('match_id_audigent', 'maids').count().count()
#ttd15_2= ttd15.join(ty03, 'maids', 'inner')
#ttd15_2.count()
#ttd15_2.show()
ttd15.show()

tx06.show()
ttd16= ttd15.join(tx06, 'match_id_audigent', 'inner').withColumnRenamed('match_id_audigent', 'hh_id')
ttd16.show()
ttd16.count()
#ttd16.groupby('hh_id', 'maids').count().count()
#ttd16.count()
#ttd16.select('maids').show(truncate= False)
ttd16_2= ttd16.select('hh_id', 'ttdids', 's_code')
ttd16_2.show()

ttd16_2.write.parquet('datascience/griffin/audigent/output/temp.parquet', mode= 'overwrite')
ttd17= spark.read.parquet('datascience/griffin/audigent/output/temp.parquet')
ttd17.show()

ttd17.repartition(4).write.csv('datascience/griffin/audigent/output/ttdids.csv', header= True, mode= 'overwrite')
check= spark.read.csv('datascience/griffin/audigent/output/ttdids.csv', header= True)
check.show()

lst= list_files('/user/unity/datascience/griffin/audigent/output/ttdids.csv', pattern= 'part')
lst

loc= '/user/unity/datascience/griffin/audigent/output/ttdids.csv'
locl= '/data/griffin/audigent/output'
locf= '/data/data_to_sts/marketplaces/audigent/data'
part1= lst[0].split('/')[-1]
part2= lst[1].split('/')[-1]
part3= lst[2].split('/')[-1]
part4= lst[3].split('/')[-1]

ident= 'ttdids'

part1
part2
part3
part4

os.system(f'hdfs dfs -get {loc}/{part1} /data/griffin/audigent/output')
os.system(f'hdfs dfs -get {loc}/{part2} /data/griffin/audigent/output')
os.system(f'hdfs dfs -get {loc}/{part3} /data/griffin/audigent/output')
os.system(f'hdfs dfs -get {loc}/{part4} /data/griffin/audigent/output')

# os.system(f'gzip {locl}/{part1}')
# os.system(f'gzip {locl}/{part2}')
# os.system(f'gzip {locl}/{part3}')

# now= datetime.datetime.now()
# nowdate = now.strftime("%Y-%m-%d")
# nowdate

nowdate= '2024-12-06'

os.system(f'mv {locl}/{part1} {locl}/UK__experianuk_{ident}_UK_{nowdate}_001.csv')
os.system(f'mv {locl}/{part2} {locl}/UK__experianuk_{ident}_UK_{nowdate}_002.csv')
os.system(f'mv {locl}/{part3} {locl}/UK__experianuk_{ident}_UK_{nowdate}_003.csv')
os.system(f'mv {locl}/{part4} {locl}/UK__experianuk_{ident}_UK_{nowdate}_004.csv')

os.system(f'gzip {locl}/UK__experianuk_{ident}_UK_{nowdate}_001.csv')
os.system(f'gzip {locl}/UK__experianuk_{ident}_UK_{nowdate}_002.csv')
os.system(f'gzip {locl}/UK__experianuk_{ident}_UK_{nowdate}_003.csv')
os.system(f'gzip {locl}/UK__experianuk_{ident}_UK_{nowdate}_004.csv')


# os.system(f'mkdir /data/griffin/audigent/output/EXPERIAN_TTDIDS')
# os.system(f'mv /data/griffin/audigent/output/experian_ttdids_* /data/griffin/audigent/output/EXPERIAN_TTDIDS')

# cd /data/griffin/audigent/output
# zip -r EXPERIAN_TTDIDS.zip EXPERIAN_TTDIDS
# rm -r EXPERIAN_TTDIDS

# unzip EXPERIAN_MOBILE.zip

os.system(f'cp {locl}/UK__experianuk_ttdids_UK* {locf}')
os.system(f'chown -R unity:stsgrp {locf}')
os.system(f'chmod -R 774 {locf}')

os.system(f'hdfs dfs -rm -r datascience/griffin/audigent/output/ttdids.parquet')


hdfs dfs -get /user/unity/match2/process/2024-11-18/id5_appnexusids.parquet /data/griffin/weekly



# APNIDS + consent string -------------------------------------------
latest_apn= latest_file('/user/unity/id_graph/graphs/apnids', 'apnids_')
latest_apn

apn01= spark.read.parquet(latest_apn)
apn01.show()

# pm01= spark.read.parquet('match2/id5/*/id5_with_consent_*.parquet')
# pm01.show()
# pm01.groupby('tcf_consent').count().show()
# pm01.count()
# # 68202383
# pm01.printSchema()

# pm02= pm01 \
    # .where(F.col('type_uid')== 'TradeDesk') \
    # .where(F.col('tcf_consent')== '1')

# pm03= pm02.withColumn('date', F.from_unixtime(F.col("timestamp")))
# pm04= pm03.withColumn('date', F.substring('date', 1, 10))
# pm04.show()
# pm04_2= pm04.withColumnRenamed('uid', 'apnids')
# pm04_2.show()

# window1= Window.partitionBy('apnids', 'date') \
    # .orderBy(
        # F.col('consent_string') 
    # )

# pm05= pm04_2.withColumn('rnum', F.row_number().over(window1))
# pm06= pm05.where(F.col('rnum')<= 1).select('apnids','date','consent_string')
# pm07= pm06.where(F.col('date').isNotNull()).cache()
# pm07.count()
# pm07.show()


apn03= apn01.withColumn("source_array", F.split(F.col("source"),","))
apn03.show()
apn04= apn03.withColumn('source_count', F.size('source_array'))
apn04.show()

apn04.groupby('source').count().show()

apn05= apn04.withColumn('chv', F.when(F.array_contains(F.col('source_array'), 'chv'), F.lit(1)).otherwise(F.lit(0)))
apn06= apn05.withColumn('de', F.when(F.array_contains(F.col('source_array'), 'de'), F.lit(1)).otherwise(F.lit(0)))
apn07= apn06.withColumn('uc', F.when(F.array_contains(F.col('source_array'), 'uc'), F.lit(1)).otherwise(F.lit(0)))
apn07.show()

window1= Window.partitionBy('match_id') \
    .orderBy(
        F.col('diff'), \
        F.col('source_count').desc(), \
        F.col('chv').desc(), \
        F.col('de').desc(), \
        F.col('uc').desc(), \
        F.col('date').desc()    
    )

apn08= apn07.withColumn('rnum', F.row_number().over(window1))
apn09= apn08.where(F.col('rnum')<= 5)
apn09.show()

window2= Window.partitionBy('apnids') \
    .orderBy(
        F.col('diff'), \
        F.col('source_count').desc(), \
        F.col('chv').desc(), \
        F.col('de').desc(), \
        F.col('uc').desc(), \
        F.col('date').desc()    
    )

apn10= apn09.withColumn('rnum2', F.row_number().over(window2))
apn11= apn10.where(F.col('rnum2')<= 3)

apn12.unpersist()
apn12= apn11.where(F.col('week0')> 0).cache()
apn12.count()
apn12.show()
#apn12.groupby('match_id').count().count()
#apn12.groupby('uid').count().count()
#apn12.count()
#apn12.groupby('match_id', 'uid').count().count()

#pm07.show()
#apn12_2= apn12.join(pm07, ['apnids','date'], 'inner')
#apn12_2.count()
#apn12.count()
#apn12_2.where(F.col('consent_string').isNull()).count()

apn14= apn12.groupby('match_id', 'apnids').count().drop('count').cache()
apn14.count()


# Join audigent match id ----------------------------------------------------------------------------
id01.show()
apn15= id01.join(apn14, 'match_id', 'inner').drop('match_id')
#apn15.show()
#apn15.count()
#apn15.groupby('match_id_audigent', 'maids').count().count()
#apn15_2= apn15.join(ty03, 'maids', 'inner')
#apn15_2.count()
#apn15_2.show()
apn15.show()

tx06.show()
apn16= apn15.join(tx06, 'match_id_audigent', 'inner').withColumnRenamed('match_id_audigent', 'hh_id')
apn16.show()
apn16.count()
#apn16.groupby('hh_id', 'maids').count().count()
#apn16.count()
#apn16.select('maids').show(truncate= False)
apn16_2= apn16.select('hh_id', 'apnids', 's_code')
apn16_2.show()

apn16_2.write.parquet('datascience/griffin/audigent/output/temp.parquet', mode= 'overwrite')
apn17= spark.read.parquet('datascience/griffin/audigent/output/temp.parquet')
apn17.show()

apn17.repartition(4).write.csv('datascience/griffin/audigent/output/apnids.csv', header= True, mode= 'overwrite')
check= spark.read.csv('datascience/griffin/audigent/output/apnids.csv', header= True)
check.show()

lst= list_files('/user/unity/datascience/griffin/audigent/output/apnids.csv', pattern= 'part')
lst

loc= '/user/unity/datascience/griffin/audigent/output/apnids.csv'
locl= '/data/griffin/audigent/output'
locf= '/data/data_to_sts/marketplaces/audigent/data'
part1= lst[0].split('/')[-1]
part2= lst[1].split('/')[-1]
part3= lst[2].split('/')[-1]
part4= lst[3].split('/')[-1]

ident= 'apnids'

part1
part2
part3
part4

os.system(f'hdfs dfs -get {loc}/{part1} /data/griffin/audigent/output')
os.system(f'hdfs dfs -get {loc}/{part2} /data/griffin/audigent/output')
os.system(f'hdfs dfs -get {loc}/{part3} /data/griffin/audigent/output')
os.system(f'hdfs dfs -get {loc}/{part4} /data/griffin/audigent/output')

# os.system(f'gzip {locl}/{part1}')
# os.system(f'gzip {locl}/{part2}')
# os.system(f'gzip {locl}/{part3}')

# now= datetime.datetime.now()
# nowdate = now.strftime("%Y-%m-%d")
# nowdate

nowdate= '2024-12-06'

os.system(f'mv {locl}/{part1} {locl}/UK__experianuk_{ident}_UK_{nowdate}_001.csv')
os.system(f'mv {locl}/{part2} {locl}/UK__experianuk_{ident}_UK_{nowdate}_002.csv')
os.system(f'mv {locl}/{part3} {locl}/UK__experianuk_{ident}_UK_{nowdate}_003.csv')
os.system(f'mv {locl}/{part4} {locl}/UK__experianuk_{ident}_UK_{nowdate}_004.csv')

os.system(f'gzip {locl}/UK__experianuk_{ident}_UK_{nowdate}_001.csv')
os.system(f'gzip {locl}/UK__experianuk_{ident}_UK_{nowdate}_002.csv')
os.system(f'gzip {locl}/UK__experianuk_{ident}_UK_{nowdate}_003.csv')
os.system(f'gzip {locl}/UK__experianuk_{ident}_UK_{nowdate}_004.csv')


# os.system(f'mkdir /data/griffin/audigent/output/EXPERIAN_TTDIDS')
# os.system(f'mv /data/griffin/audigent/output/experian_apnids_* /data/griffin/audigent/output/EXPERIAN_TTDIDS')

# cd /data/griffin/audigent/output
# zip -r EXPERIAN_TTDIDS.zip EXPERIAN_TTDIDS
# rm -r EXPERIAN_TTDIDS

# unzip EXPERIAN_MOBILE.zip

os.system(f'cp {locl}/UK__experianuk_apnids_UK* {locf}')
os.system(f'chown -R unity:stsgrp {locf}')
os.system(f'chmod -R 774 {locf}')

os.system(f'hdfs dfs -rm -r datascience/griffin/audigent/output/apnids.parquet')


hdfs dfs -get /user/unity/match2/process/2024-11-18/id5_appnexusids.parquet /data/griffin/weekly


#- META data --------------------------------------------------------------------------------------
aud_scode= tx02.groupby('S_Code').count().drop('count').cache()
aud_scode.count()
aud_scode.show()
aud_scode02= aud_scode.toPandas()
aud_scode02

desc01= pd.read_excel('/data/griffin/facebook_marketplacefile_2024-07-10-17-26.xlsx')
desc01

desc01['S_Code']= desc01['S_Code'].str.replace(r'^S[0]*', 'S', regex=True)
desc01

desc02= pd.merge(aud_scode02, desc01, on= 'S_Code', how= 'inner')
desc02

desc02['col3']= ''
desc02

nowdate= '2024-12-06'

import time
unix= str(int(round(1000*time.time(),0)))


desc02.to_csv(f'/data/griffin/audigent/output/UK__experianuk_meta_UK_{nowdate}_{unix}.csv', index= False, header= False)

os.system(f'gzip /data/griffin/audigent/output/UK__experianuk_meta_UK_{nowdate}_{unix}.csv')


# os.system(f'mkdir /data/griffin/audigent/output/EXPERIAN_TTDIDS')
# os.system(f'mv /data/griffin/audigent/output/experian_apnids_* /data/griffin/audigent/output/EXPERIAN_TTDIDS')

# cd /data/griffin/audigent/output
# zip -r EXPERIAN_TTDIDS.zip EXPERIAN_TTDIDS
# rm -r EXPERIAN_TTDIDS

# unzip EXPERIAN_MOBILE.zip

locf= '/data/data_to_sts/marketplaces/audigent/taxonomy'

os.system(f'cp /data/griffin/audigent/output/UK__experianuk_meta_UK_{nowdate}_{unix}.csv.gz {locf}')
os.system(f'chown -R unity:stsgrp {locf}')
os.system(f'chmod -R 774 {locf}')

os.system(f'hdfs dfs -rm -r datascience/griffin/audigent/output/apnids.parquet')




1652446672939
1733698006107