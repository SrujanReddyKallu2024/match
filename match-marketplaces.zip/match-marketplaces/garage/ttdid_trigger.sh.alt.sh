


for id in maids ttdids uid; do
    mkdir -p $TTDIDS_TEMP_LOCAL_PATH/$id
    hdfs dfs -copyToLocal $TTDIDS_MKT_HDFS_DIR/$RUNDATE/$id/* $TTDIDS_TEMP_LOCAL_PATH/$id/
    for su in $(ls $TTDIDS_TEMP_LOCAL_PATH/$id | grep -o -P '(?<=S_Code=)[0-9]+' | sort -u); do
        for chunk in $(ls $TTDIDS_TEMP_LOCAL_PATH/$id/S_Code=${su} | grep -o -P '(?<=chunk=)[0-9]+' | sort -u); do
        # add a header at the top of the directory
            echo $id | gzip - > $TTDIDS_TEMP_LOCAL_PATH/${id}/S_Code=${su}/chunk=${chunk}/_.gz
            sup=SU$(printf %07d ${su})
            cat $TTDIDS_TEMP_LOCAL_PATH/${id}/S_Code=${su}/chunk=${chunk}/* > $TTDIDS_TEMP_LOCAL_PATH/Replace.TTDID.${sup}.${chunk}.${id}.${TTDIDS_DATE}.csv.gzip
            rm -r $TTDIDS_TEMP_LOCAL_PATH/${id}/S_Code=${su}/chunk=${chunk}
        done
        rm -r $TTDIDS_TEMP_LOCAL_PATH/${id}/S_Code=${su}
    done
    rm -r $TTDIDS_TEMP_LOCAL_PATH/$id
done


