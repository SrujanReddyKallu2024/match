# This script processes TTDID and DA segments, copying files locally, creating DA copies, and setting permissions.
#1291
. bash_scripts/triggers/ttdid_trigger.sh

RUNDATE=2025-06-01


last_ttdda=$(find_latest_file_in_hdfs $TTDIDS_MKT_HDFS_DIR ttdda_marketplacefile)
last_ttdid=$(find_latest_file_in_hdfs $TTDIDS_MKT_HDFS_DIR ttdid_marketplacefile)

echo "Latest TTDA file: $last_ttdda"
echo "Latest TTDID file: $last_ttdid"

# Get the list of SU segments and DA segments
su_segments=$(hdfs dfs -cat $last_ttdid | tail -n +2 | cut -d',' -f1 | sed 's/^SU//' | sed 's/^0*//')
da_segments=$(hdfs dfs -cat $last_ttdda | tail -n +2 | cut -d',' -f1 | sed 's/^DA//' | sed 's/^0*//')

for id in maids ttdids uid; do
    mkdir -p $TTDIDS_TEMP_LOCAL_PATH/$id && echo "Created directory $TTDIDS_TEMP_LOCAL_PATH/$id"
    for su in $su_segments; do
        echo "Processing SU segment: $su"
        hdfs dfs -copyToLocal $TTDIDS_MKT_HDFS_DIR/$RUNDATE/$id/S_Code=${su} $TTDIDS_TEMP_LOCAL_PATH/$id/ && echo "Copied SU segment $su to local"
        for chunk in $(ls $TTDIDS_TEMP_LOCAL_PATH/$id/S_Code=${su} | grep -o -P '(?<=chunk=)[0-9]+' | sort -u); do
            echo "Processing chunk: $chunk"
            echo $id | gzip - > $TTDIDS_TEMP_LOCAL_PATH/${id}/S_Code=${su}/chunk=${chunk}/_.gz
            sup=SU$(printf %07d ${su})
            cat $TTDIDS_TEMP_LOCAL_PATH/$id/S_Code=${su}/chunk=${chunk}/* > $TTDIDS_TEMP_LOCAL_PATH/Replace.TTDID.${sup}.${chunk}.${id}.${TTDIDS_DATE}.csv.gzip && echo "Created TTDID file for SU $su, chunk $chunk"
            # Check if the SU segment is in the DA list
            if echo "$da_segments" | grep -q "^$su$"; then
                newfile=$TTDIDS_TEMP_LOCAL_PATH/Replace.TTDDA.DA$(printf %07d ${su}).${chunk}.${id}.${TTDIDS_DATE}.csv.gzip
                cp $TTDIDS_TEMP_LOCAL_PATH/Replace.TTDID.${sup}.${chunk}.${id}.${TTDIDS_DATE}.csv.gzip $newfile && echo "Created DA file: $newfile"
            fi
            move_file locals Replace $TTDIDS_TEMP_LOCAL_PATH $TTDIDS_STS_LOCAL_PATH && echo "Moved TTDID/DA file to STS path"
            set_permissions $TTDIDS_STS_LOCAL_PATH && echo "Set permissions for STS path"
            rm -r $TTDIDS_TEMP_LOCAL_PATH/$id/S_Code=${su}/chunk=${chunk}
            remain=`df | grep /data | awk '{print $4}'`
            if [[ $remain -lt 100000000 ]]; then echo "sleep!"; sleep 1h; fi
        done
        rm -r $TTDIDS_TEMP_LOCAL_PATH/$id/S_Code=${su}
    done
    echo "Processing for ID $id complete"
done
