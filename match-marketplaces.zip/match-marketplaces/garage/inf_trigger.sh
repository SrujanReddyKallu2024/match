trigger_postal_address_ingestion() {
    if is_file_ingestible $MKP_SEG_FILE_DIR "postal_address"
    then
        echo "Latest postal address file ready to be ingested"
        all_post_files=($(ls $MKP_SEG_FILE_DIR/*postal_address*))
        for pfile in ${all_post_files[@]}; do
            file_name=$(basename "$pfile")
            hdfs dfs -copyFromLocal $pfile $INF_POSTAL_ADDRESS_DIR && echo "copied postal address file to HDFS: $INF_POSTAL_ADDRESS_DIR"
        done
        move_file locals "postal_address" $MKP_SEG_FILE_DIR $DATA_FROM_STS_BACKUP
    else
        echo "File not found in $MKP_SEG_FILE_DIR, Postal Address process can't be triggered on $RUNDATE at $CURRENT_HOUR"
    fi
}