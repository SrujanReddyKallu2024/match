# docker run --memory="4g" -it --rm -v C:\Users\potterr\ConsumerSync\match-marketplaces:/hello -w /hello -e PYSPARK_SUBMIT_ARGS="--conf spark.driver.memory=6g --conf spark.executor.memory=4g --conf spark.executor.memoryOverhead=1g spark-submit" -e SPARK_DAEMON_JAVA_OPTS="-Xmx4g" pysparktestboto /opt/spark/bin/spark-submit /hello/marketplaces/ttdeugeo/eug01_original.py --input=testing/dk_ttdgeoll_2025-01-07.csv --output=testing/output --output_counts=testing/stats/output_counts --input_counts=testing/stats/input_count
# spark-submit marketplaces/ttdeugeo/eug01_transform_original.py --input=ttd_geo/dk_ttdgeoll_2025-01-07.csv.gz --output=tmp/testing/output --output_counts=tmp/testing/stats/output_counts --input_counts=tmp/testing/stats/input_count

import subprocess
from pathlib import Path
import sys
import os
import pyspark.sql.functions as F
import argparse
from pyspark.sql import SparkSession

sys.path.append(str(Path(__file__).resolve().parents[1]))

import config
import functions as f

name = os.path.basename(__file__)
logger = config.LogConfig(f"{config.LOGPATH}/{name}_{config.DATE_TIME}.log").generate_logger(name)

stats_title = "TTD Geo EU"

argparser = argparse.ArgumentParser()
argparser.add_argument("--input", required=True, help="input file")
argparser.add_argument("--output", required=True, help="output file location")
argparser.add_argument("--output_counts", required=True, help="output counts file location")
argparser.add_argument("--input_counts", required=True, help="where the input counts get written")
# if testing paste this line in shell rather than next
# args, unknown = argparser.parse_known_args(['--input', 'testing/dk_ttdgeoll_2025-01-07.csv', '--output', 'testing/output', '--output_counts', 'testing/stats/output_counts', '--input_counts', 'testing/stats/input_counts'])
# args, unknown = argparser.parse_known_args(['--input', 'ttd_geo/dk_ttdgeoll_2025-01-07.csv.gz', '--output', 'tmp/testing/output', '--output_counts', 'tmp/testing/stats/output_counts', '--input_counts', 'tmp/testing/stats/input_counts'])

# use parse known args to allow for other args which might be in any future config module
args, unknownargs = argparser.parse_known_args()

logger.info(args)

spark = ( SparkSession.builder.appName("ttdeugeo")
    #.config("spark.driver.memory", "10g") 
    #.config("spark.executor.memory", "10g") 
    #.config("spark.executor.memoryOverhead", "1g") 
    .getOrCreate()
)

quick_stats = []

try:

    # read data but keep header, because some don't read properly
    # we will filter out the header and the actual data types don't 
    # really matter
    df = spark.read.csv(args.input, header=False)

    # quick stat
    input_rows = df.count()

    logger.info(f"Count of input {input_rows} (includes header)")
    f.update_stats(quick_stats, stats_title, "Success", f"Found {input_rows} in from Path: {args.input}")

    # these are teh columns we know about and will start the file,
    # the rest of the columns may vary from country to country in name and length
    # the output from Donovan will be a csv with the first 4 columns being
    cols = ["SlNo","Lat","Long","Radius"]

    # rename the columns we care about
    df = df.selectExpr([f'{df.columns[r]} as {cols[r]}' for r in range(len(cols))] + df.columns[len(cols):])

    # use a cast on SlNo to filter out non-numeric values (which is header)
    df = ( df
        .withColumn("test", F.col("SlNo").cast("int"))
        .filter(F.col("test").isNotNull())
        .drop(F.col("test"))
        .cache()
    )
except Exception as e:
    f.update_stats(quick_stats, stats_title, "Failed", str(e))
    raise



try:

    # calculate counts where the audience is not null
    df_counts = ( df
        .selectExpr([f'sum(case when {c} is null then 0 else 1 end) as {c}'
                    for c in df.columns if c.startswith("_c")])
    )

    # transpose results using stack function, list comprehension to get the columns as name, value pairs
    dit="'"
    expr = f"stack({len(df_counts.columns)},{','.join([f'{dit}{c}{dit},{c}' for c in df_counts.columns])}) as (Column, Count)"
    df_counts = df_counts.selectExpr(expr)

    # write out the counts for stats
    df_counts.write.csv(args.input_counts, header=True, mode="overwrite")
except Exception as e:
    f.update_stats(quick_stats, stats_title, "Failed", str(e))
    raise

        # try:
        #     df_counts = (
        #         df_formatted
        #         .selectExpr([f'sum(case when {c} is null then 0 else 1 end) as {c}' for c in df_formatted.columns if c.startswith("_c")])
        #     )
        #     logger.info("calculated counts where the audience is not null")

        #     dit="'"
        #     expr = f"stack({len(df_counts.columns)},{','.join([f'{dit}{c}{dit},{c}' for c in df_counts.columns])}) as (Column, Count)"
        #     df_counts_updated = df_counts.selectExpr(expr)
        #     logger.info("transposed results using stack function, where each column is pivoted into rows with two new columns: Column and Count")

        #     df_counts.write.csv(counts_path, header=True, mode="overwrite")
        #     logger.info(f"written out the counts for stats to {counts_path}")

        #     update_stats(quick_stats, "TTD Input Data Counts", "Success", f"Calculated counts for {df_counts_updated.count()} columns and wrote out to {counts_path}")
        # except Exception as e:
        #     update_stats(quick_stats, "TTD Input Data Counts", "Failed", str(e))
        #     raise


try:

    # bundle up the non-repeating columns into an array called list
    df2 = ( 
        df.withColumn(
        "list", F.array([F.array(F.lit(c), F.col(c)) for c in df.columns[len(cols):]])
        )
        .select(cols + ["list"])
    )

    # a quick stat, and a cache hopefully
    arrayed_rows = df2.count()
    logger.info(f"Count of arrayed input {arrayed_rows}")
    f.update_stats(quick_stats, stats_title, "Success", f"Found {arrayed_rows}")
except Exception as e:
    F.update_stats(quick_stats, stats_title, "Failed", str(e))  
    raise


try:
        
    # explode the array, take only the value, filter on non-null
    exploded = ( df2
        .withColumn("exploded", F.explode(F.col("list")))
        .select(cols+[F.col("exploded")[1].alias("audience")])
        .filter(F.col("audience").isNotNull())
    )

    # repartition by audience and a high count and drop duplicates
    # this results in a drastic reduction in the number of records
    final = exploded.drop("SlNo").repartition(128,F.col("audience")).dropDuplicates().cache()

    # shell check of counts input v output ..
    # df.select(F.col("_c4")).filter(F.col("_c4").isNotNull()).groupby("_c4").count().show()
    # +---+------+
    # |_c4| count|
    # +---+------+
    # |DK1|258772|
    # +---+------+
    # exploded.filter(F.col("audience")=="DK1").count()
    # 258772
    # exploded.filter(F.col("audience")=="DK1").drop("SlNo").dropDuplicates().count()
    # 111554
    # which tallies with the final check

    # hoping this will find the result easier to output
    final.write.partitionBy("audience").csv(args.output, header=False, mode="overwrite")
    f.update_stats(quick_stats, stats_title, "Success", f"Written partitioned output Audiences")
except Exception as e:
    f.update_stats(quick_stats, stats_title, "Failed", str(e))
    raise    


try:
    # check, number of records per audience
    check = ( spark.read.csv(args.output)
        .groupby(F.col("audience"))
        .count()
        .withColumn("audiencen",F.substring("audience",3,10).cast("int"))
        .sort(F.col("audiencen")).select("audience","count")
        .cache()
    )

    check.write.csv(args.output_counts + "/finalcounts" , header=True, mode="overwrite")
    f.update_stats(quick_stats, stats_title, "Success", f"Found {check.count()} Audiences")
except Exception as e:
    f.update_stats(quick_stats, stats_title, "Failed", str(e))
    raise

try:
    # check number of files written per audience
    check2 = ( spark.read.csv(args.output)
        .withColumn("file",F.input_file_name())
        .groupby("audience","file").count().alias("total")
        .groupby("audience").count().alias("files")
        .cache()
    )

    check2.write.csv(args.output_counts + "/filecheck", header=True, mode="overwrite")
    f.update_stats(quick_stats, stats_title, "Success", f"Written {check2.count()} count of partitions by audience check.")
except Exception as e:
    f.update_stats(quick_stats, stats_title, "Failed", str(e))
    raise
