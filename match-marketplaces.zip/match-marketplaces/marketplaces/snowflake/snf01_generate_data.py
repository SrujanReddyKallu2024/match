import pandas as pd
import sys
from pathlib import Path
import argparse
import os
from pyspark.sql import SparkSession, Window
import pyspark.sql.functions as F
from datetime import datetime, timedelta
import time
import math

sys.path.append(str(Path(__file__).resolve().parents[2]))

import config as c
import functions

SNF_CONFIG = [
    {
        "id": snf_id, 
        "datecol": "last_seen" if snf_id == "ip" else "" if (snf_id in ["hems","mobile","pc"]) else "date",
        "id_path": c.IDG_GRAPH_PATH
    }
    for snf_id in c.SNF_IDS
]


def logic_main(ctx, logger, mask, idg_lookup_path, lookup_window, snf_config, out_path, email_to):
    logger.info(f"running inf01_generate_data script for mask: {mask}")
    quick_stats = []
    try:
        startime = datetime.now()
        ## Load lookup file
        try:
            snf_lookup_file = functions.latest_hdfs_file(f"{idg_lookup_path}/snowflake", pattern = 'match_id_lookup_snowflake')
            logger.info(f"snowflake lookup file: {snf_lookup_file}")

            snf_lookup = ctx.read.parquet(snf_lookup_file).cache()            
            logger.info("read snowflake lookup data")

            functions.update_stats(quick_stats, "Loaded Snowflake MatchIds", "Success", f"Latest Snowflake lookup: {snf_lookup_file}, count of Snowflake matchids: {snf_lookup.count():,}")
        except Exception as e:
            functions.update_stats(quick_stats, "Loaded Snowflake MatchIds", "Failed", str(e))
            raise

        ## Read graph data
        snf_ids = [i['id'] for i in snf_config]
        logger.info(f"all ids requested by snowflake: {snf_ids}")

        errors = []

        for snf_id in snf_ids:
            snf_id_cap = snf_id.upper()          
            try:                
                id_path = [i['id_path'] for i in snf_config if i["id"]==snf_id][0]
                logger.info(f"id path for {snf_id}: {id_path}")

                id_file = functions.latest_hdfs_file(f"{id_path}/{snf_id}", pattern=snf_id)                    
                logger.info(f"id graph file for {snf_id}: {id_file}")

                id_df = ctx.read.parquet(id_file)
                logger.info(f"read id graph data for {snf_id}")

                id_datecol = [i['datecol'] for i in snf_config if i["id"]==snf_id][0]
                logger.info(f"date column to be used for {snf_id}: {id_datecol}")

                functions.update_stats(quick_stats, f"{snf_id_cap} Data Load", "Success", f"Latest {snf_id} data: {id_file} loaded with {id_df.count():,} records, datecolumn: {id_datecol}")
            except Exception as e:
                functions.update_stats(quick_stats, f"{snf_id_cap} Data Load", "Failed", str(e))
                errors.append({"id": snf_id, "failed_step": "Data Load"})
                continue

            ## Format Data
            try:
                cutoff = (startime - timedelta(days= lookup_window)).strftime("%Y-%m-%d")
                logger.info(f"cut off date for {snf_id}: {cutoff}")

                if snf_id not in ["hems","mobile","pc"]:
                    idg_fmt = id_df.where(F.col(id_datecol) >= cutoff).cache()
                    idg_count = idg_fmt.count()
                    logger.info(f"filtered id graph data with newer than {cutoff} date, updated count: {idg_count}")                    
                else:
                    idg_fmt = id_df.cache()
                    idg_count = idg_fmt.count()
                    logger.info(f"no formatting required for hems, updated count: {idg_count}")
                
                functions.update_stats(quick_stats, f"{snf_id_cap} Data Filtered", "Success", f"Filtered {snf_id} data, updated count: {idg_count:,}")
            except Exception as e:
                idg_fmt.unpersist()
                functions.update_stats(quick_stats, f"{snf_id_cap} Data Filtered", "Failed", str(e))
                errors.append({"id": snf_id, "failed_step": "Data Filter"})
                continue

            ## Join with lookup file and write out
            try:                
                idg_with_snf_id = (
                    idg_fmt
                    .join(snf_lookup, idg_fmt.match_id == snf_lookup.match_id, "left")
                    .drop("match_id")
                    .withColumnRenamed("match_id_snowflake", "snowflake_id")
                )
                logger.info(f"joined {snf_id} data with lookup file")

                num_partitions = math.ceil(max(1, min(idg_with_snf_id.count() // 5_000_000, 50)))
                logger.info(f"number of partitions to be used for {snf_id}: {num_partitions}")

                idg_with_snf_id.repartition(num_partitions).write.parquet(out_path.format(ident=snf_id), mode="overwrite", compression="gzip")
                logger.info(f"wrote {snf_id} data with snowflake id to {out_path.format(ident=snf_id)}")
                idg_fmt.unpersist()
                
                functions.update_stats(quick_stats, f"{snf_id_cap} Data Prepared", "Success", f"Joined {snf_id} data with lookup file, and wrote to: {out_path}")
            except Exception as e:
                functions.update_stats(quick_stats, f"{snf_id_cap} Data Prepared", "Failed", str(e))
                errors.append({"id": snf_id, "failed_step": "Data Preparation"})
                continue
            
            ## Rename files
            time.sleep(60)

            try:
                ## Rename single part file to i.e. {snf_id}__{mask}__part001.parquet
                all_id_files = functions.get_all_files(out_path.format(ident=snf_id))
                logger.info(f"all {snf_id} files: {all_id_files}")

                if len(all_id_files) == 0:
                    raise Exception("No files found to rename")

                functions.rename_files(logger, mask, all_id_files, snf_id, new_name_template = f"{{graph_type}}__{{mask}}__part{{partname}}.gz.parquet")

                new_files = functions.get_all_files(out_path.format(ident=snf_id))
                logger.info(f"new_files : {','.join(new_files)}")

                functions.update_stats(quick_stats, f"{snf_id_cap} Graph Rename", "Success", f"Renamed {len(all_id_files)} {snf_id} graph files as per Snowflake Format i.e. {new_files[0]}")
            except Exception as e:
                functions.update_stats(quick_stats, f"{snf_id_cap} Graph Rename", "Failed", str(e))
                errors.append({"id": snf_id, "failed_step": "Data Preparation"})
                continue

        if len(errors) > 0:
            logger.error(f"some ids failed during processing: {errors}")
            success_flag = False
        else:
            success_flag = True        
    except Exception as e:
        logger.error(e)
        success_flag = False
        functions.send_status_email("Error: snf01_generate_data script failed", e, email_to)
        raise
    finally:
        alerts_df = pd.DataFrame(quick_stats)    
        email_sub = f"***SNFO01 - Generate Snowflake Data - {c.STATUS_EMOJIS['green']}***" if success_flag else f"***SNFO01 - Generate Snowflake Data - {c.STATUS_EMOJIS['red']}***"
        functions.send_teams_email(mask, email_sub, alerts_df.to_html(index=False))
        endtime = datetime.now()
        logger.info(f"process completed in {str(endtime - startime).split('.')[0]}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-m", "--mask", help="date on which process is run in format YYYY-MM-DD", default=c.TODAY_DATE)
    parser.add_argument("-ilp", "--idg_lookup_path", help="idgraph parent lookup file path", default=c.LOOKUP_FILE_PATH)    
    parser.add_argument("-lw", "--lookup_window", help="lookup window for insofum", default=c.SNF_LOOKUP_WINDOW)    
    parser.add_argument("-sc", "--snf_config", help="ids requested by snowflake", default=SNF_CONFIG)    
    parser.add_argument("-op", "--out_path", help="final snowflake data written out to this hdfs file path")
    parser.add_argument("-et", "--email_to", help="recipients of email alerts", default=c.EMAIL_TO)
    
    args = parser.parse_args()

    if args.out_path is None:
        args.out_path = f"{c.SNF_PATH_HDFS}/{args.mask}/snowflake_{{ident}}_graph.parquet"

    name = os.path.basename(__file__)
    logger = c.LogConfig(f"{c.LOGPATH}/{name}_{args.mask}.log").generate_logger(name)
    spark = SparkSession.builder.appName(f"{name}_{args.mask}").getOrCreate()

    logic_main(spark, logger, args.mask, args.idg_lookup_path, args.lookup_window, args.snf_config, args.out_path, args.email_to)