import pandas as pd
import sys
from pathlib import Path
import argparse
import os
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from datetime import datetime

sys.path.append(str(Path(__file__).resolve().parents[2]))

from config import LogConfig, LOGPATH, TODAY_DATE, METADATA_PATH, P39_PATH_HDFS, EMAIL_TO, STATUS_EMOJIS
from functions import latest_local_file, send_status_email, update_stats, send_teams_email


def logic_main(ctx, logger, mask, scodes_path, out_path, email_to):
    logger.info(f"running p3900_generate_metadata script for mask: {mask}")
    quick_stats = []

    try:
        startime = datetime.now()
        try:
            latest_scodes_path = latest_local_file(scodes_path, pattern='peer39_scodes')
            logger.info(f"latest scodes file: {latest_scodes_path}")
            
            scodes_df = pd.read_csv(latest_scodes_path)
            logger.info("read scodes data from local path")

            update_stats(quick_stats, "Peer39 SCodes", "Success", f"Found {scodes_df.size:,} Peer39 SCodes from Path: {latest_scodes_path}")
        except Exception as e:
            update_stats(quick_stats, "Peer39 SCodes", "Failed", str(e))
            raise
        
        try:
            latest_ccode_lookup_path = latest_local_file(scodes_path, pattern='scode_ccode_lookup')
            logger.info(f"latest scode to ccode lookup file: {latest_ccode_lookup_path}")
            
            scode_ccode_lookup = pd.read_csv(latest_ccode_lookup_path)
            logger.info("read scode to ccode lookup data from local path")

            update_stats(quick_stats, "SCode-CCode Lookup", "Success", f"Found {scode_ccode_lookup.size:,} SCodes-CCode lookup from Path: {latest_ccode_lookup_path}")
        except Exception as e:
            update_stats(quick_stats, "SCode-CCode Lookup", "Failed", str(e))
            raise

        try:
            p39_scodes_ccodes_pd = scodes_df.merge(scode_ccode_lookup, on='S_Code2', how='inner')
            logger.info("joined peer39 scodes with ccode lookup")

            p39_scodes_ccodes = ctx.createDataFrame(p39_scodes_ccodes_pd)
            logger.info("converted pandas df to spark df")

            p39_scodes_ccodes.write.csv(out_path, header=True, mode='overwrite')
            logger.info(f"written out joined peer39 scodes with ccode lookup to {out_path}")

            update_stats(quick_stats, "Peer39 SCodes with CCode", "Success", f"Wrote Peer39 SCodes with CCodes with count: ({p39_scodes_ccodes.count():,}) to {out_path}")
        except Exception as e:
            update_stats(quick_stats, "Peer39 SCodes with CCode", "Failed", str(e))
            raise

        success_flag = True        
    except Exception as e:
        logger.error(e)
        success_flag = False
        send_status_email("Error: p3900_generate_metadata script failed", e, email_to)
        raise
    finally:
        alerts_df = pd.DataFrame(quick_stats)    
        email_sub = f"***P3900 - Generate Peer39 Metadata - {STATUS_EMOJIS['green']}***" if success_flag else f"***P3900 - Generate Peer39 Metadata - {STATUS_EMOJIS['red']}***"
        send_teams_email(mask, email_sub, alerts_df.to_html(index=False))
        endtime = datetime.now()
        logger.info(f"process completed in {str(endtime - startime).split('.')[0]}")


if __name__ == "__main__":
    ## Setup Args
    parser = argparse.ArgumentParser()

    parser.add_argument("-m", "--mask", help="date on which process is run in format YYYY-MM-DD", default=TODAY_DATE)
    parser.add_argument("-sp", "--scodes_path", help="local parent file path containing scodes for all marketplaces", default=METADATA_PATH)            
    parser.add_argument("-op", "--out_path", help="cleaned peer39 scodes are written out to this hdfs file path")
    parser.add_argument("-et", "--email_to", help="recipients of email alerts", default=EMAIL_TO)

    args = parser.parse_args()
    if args.out_path is None:
        args.out_path = f"{P39_PATH_HDFS}/{args.mask}/metadata__{datetime.now().strftime('%H-%M-%S')}.csv"


    ## Setup Spark and logging
    name = os.path.basename(__file__)
    logger = LogConfig(f"{LOGPATH}/{name}_{args.mask}.log").generate_logger(name)
    spark = SparkSession.builder.appName(f"{name}_{args.mask}").getOrCreate()

    ## Process starts here
    logic_main(spark, logger, args.mask, args.scodes_path, args.out_path, args.email_to)
