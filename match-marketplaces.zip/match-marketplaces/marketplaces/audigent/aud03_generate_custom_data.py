from pathlib import Path
import sys
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
import argparse
from datetime import datetime
import pandas as pd

sys.path.append(str(Path(__file__).resolve().parents[2]))

from config import *
from functions import *


def logic_main(ctx, logger, mask, idg_lookup_path, cbk_in_dir, out_path, email_to):
    logger.info(f"running aud02 generate data script for mask: {mask}")
    quick_stats = []
    try:
        startime = datetime.now()
        try:
            aud_lookup_file = latest_hdfs_file(f"{idg_lookup_path}/audigent", pattern = 'cbk_hh_lookup_audigent')
            logger.info(f"audigent lookup file: {aud_lookup_file}")

            aud_cbk_lookup = ctx.read.parquet(aud_lookup_file).sort("cb_key_household").cache()
            logger.info(f"read audigent lookup data, count: {aud_cbk_lookup.count()}")

            latest_custom_cbkey_file = latest_local_file(cbk_in_dir, pattern='audigent_hhkeys', dateformat=r"%Y-%m-%d")
            logger.info(f"latest custom data file: {latest_custom_cbkey_file}")

            custom_cbkeys_pd = pd.read_csv(latest_custom_cbkey_file)            
            logger.info(f"read custom data file, count: {custom_cbkeys_pd.shape[0]}")
                        
            custom_cbkeys_spark = ctx.createDataFrame(custom_cbkeys_pd)
            logger.info("converted custom data to spark dataframe")

            aud_custom_matchids = aud_cbk_lookup.join(F.broadcast(custom_cbkeys_spark), on="cb_key_household", how="inner").select("match_id_audigent").dropDuplicates()
            logger.info(f"joined audigent lookup with custom data to get matchids")

            aud_custom_matchids.toPandas().to_csv(out_path, index=False)
            logger.info(f"written custom matchids to {out_path}")

            update_stats(
                quick_stats, "Audigent Custom Audience Load", "Success", 
                f"""
                Latest Audigent Lookup: {aud_lookup_file} with {aud_cbk_lookup.count():,} records; 
                Latest Custom CBKeys read from : {latest_custom_cbkey_file} with {aud_custom_matchids.count():,} Records
                Wrote output csv to {out_path}
                """
            )
        except Exception as e:
            update_stats(quick_stats, "Audigent Custom Audience Load", "Failed", str(e))
            raise
        
        success_flag = True
    except Exception as e:
        logger.error(e)
        success_flag = False
        send_status_email("Error: aud03_generate_custom_data script failed", e, email_to)
        raise
    finally:
        alerts_df = pd.DataFrame(quick_stats)    
        email_sub = f"***AUD03 - Generate Audigent Custom Data - {STATUS_EMOJIS['green']}***" if success_flag else f"***AUD03 - Generate Audigent Custom Data - {STATUS_EMOJIS['red']}***"
        send_teams_email(mask, email_sub, alerts_df.to_html(index=False))
        endtime = datetime.now()
        logger.info(f"process completed in {str(endtime - startime).split('.')[0]}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-m", "--mask", help="date on which process is run in format YYYY-MM-DD", default=TODAY_DATE)
    parser.add_argument("-ilp", "--idg_lookup_path", help="idgraph parent lookup file path", default=LOOKUP_FILE_PATH)
    parser.add_argument("-cbd", "--cbk_in_dir", help="local path where custom hhkey file will land", default=AUD_CUSTOM_INDIR)
    parser.add_argument("-op", "--out_path", help="cleaned audigent matchids based on loaded cbkeys are written out to this local file path")
    parser.add_argument("-et", "--email_to", help="recipients of email alerts", default=EMAIL_TO)
    
    args = parser.parse_args()

    if args.out_path is None:
        args.out_path = f"{AUD_CUSTOM_OUTDIR}/audigent_custom_audience_{args.mask}.csv"

    name = os.path.basename(__file__)
    logger = LogConfig(f"{LOGPATH}/{name}_{args.mask}.log").generate_logger(name)
    spark = SparkSession.builder.appName(f"{name}_{args.mask}").getOrCreate()
    logic_main(
        spark, logger, args.mask, args.idg_lookup_path, args.cbk_in_dir, args.out_path, args.email_to
    )