from pathlib import Path
import sys
from pyspark.sql import SparkSession, Window
import pyspark.sql.functions as F
import argparse
import time
from datetime import datetime, timedelta
import pandas as pd

sys.path.append(str(Path(__file__).resolve().parents[2]))

from config import *
from functions import *


GRAPH_CONFIG = [
    {"id": aud_id, "datecol": "last_seen" if aud_id == "ip" else "" if aud_id == "hems" else "date"}
    for aud_id in AUD_IDS
]


def format_graph(idgdf, idg, idg_datecol, cutoff):
    """
    format the given graph
    """
    if idg == "ip":
        idgdf = idgdf.where(F.col(idg_datecol)> cutoff)
    
    return (
        idgdf        
        .withColumn("source_array", F.split(F.col("source"),","))
        .withColumn('source_count', F.size('source_array'))
        .withColumn('chv', F.when(F.array_contains(F.col('source_array'), 'chv'), F.lit(1)).otherwise(F.lit(0)))
        .withColumn('de', F.when(F.array_contains(F.col('source_array'), 'de'), F.lit(1)).otherwise(F.lit(0)))
        .withColumn('uc', F.when(F.array_contains(F.col('source_array'), 'uc'), F.lit(1)).otherwise(F.lit(0)))        
    )


def format_hems_graph(df, idg_mids_with_scodes):
    """
    format the hems graph
    """
    df_temp = (
        df.join(idg_mids_with_scodes, 'match_id', 'inner')
        .drop('match_id')
    )
    ranked_df = (
        df_temp
        .groupby('match_id_audigent')   
        .count()
        .where(F.col('count')<= 50)
    )
    return (
        ranked_df
        .select('match_id_audigent')
        .join(df_temp, 'match_id_audigent', 'inner')
        .withColumn('last_seen', F.lit(''))
        .select("match_id_audigent", "hems", "s_code", "last_seen")
    )


def apply_rank(idgdf, idg, idg_datecol):
    """
    apply rank to the graph based on the given identifier
    """
    if idg == "ip":
        order_by_columns = [
            F.col(idg_datecol).desc(),
            F.col('source_count').desc(),
            F.col('chv').desc(),
            F.col('de').desc(),
            F.col('uc').desc()
        ]
    else:
        order_by_columns = [
            F.col('diff'),
            F.col('source_count').desc(),
            F.col('chv').desc(),
            F.col('de').desc(),
            F.col('uc').desc(),
            F.col(idg_datecol).desc()
        ]

    winSpec1= Window.partitionBy('match_id').orderBy(*order_by_columns)
    winSpec2= Window.partitionBy(idg).orderBy(*order_by_columns)
    return (
        idgdf
        .withColumn('rnum', F.row_number().over(winSpec1))
        .where(F.col('rnum')<= 5)
        .withColumn('rnum2', F.row_number().over(winSpec2))
        .where(F.col('rnum2')<= 3)
    )


def agg_graph(df, idg, datecol):
    """
    aggregate the graph based on matchid and the identifier and calculate the max last_seen
    """    
    return (
        df
        .groupby('match_id', idg)
        .agg(F.max(datecol).alias('last_seen'))
    )    
        

def logic_main(ctx, logger, mask, graphs, idg_config, idg_lookup_path, idg_graph_path, mid_with_scodes_path, out_path, email_to):
    logger.info(f"running aud02 generate data script for mask: {mask}")
    quick_stats = []
    try:
        startime = datetime.now()            
        date180= (startime - timedelta(days= 180)).strftime("%Y-%m-%d")
        ## Experian matchid with scodes
        try:
            aud_lookup_file = latest_hdfs_file(f"{idg_lookup_path}/audigent", pattern = 'match_id_lookup_audigent')
            logger.info(f"audigent lookup file: {aud_lookup_file}")

            aud_lookup = ctx.read.parquet(aud_lookup_file)        
            logger.info("read audigent lookup data")

            mid_with_scodes_file = latest_hdfs_file(mid_with_scodes_path, pattern='matchid_with_scodes')
            logger.info(f"latest matchid with scodes file: {mid_with_scodes_file}")

            mid_with_scodes = ctx.read.parquet(mid_with_scodes_file)
            mid_with_scodes.cache().count()
            logger.info("read matchid with scodes data")

            cbk_file = latest_hdfs_file(f"{idg_lookup_path}/audigent", pattern = 'cbk_hh_lookup_audigent')
            logger.info(f"CBK lookup file: {cbk_file}")

            cbk = ctx.read.parquet(cbk_file)
            logger.info("read CBK lookup data")


            idg_mids_with_scodes = (
                mid_with_scodes
                .join(aud_lookup, 'match_id_audigent', 'inner')
            )
            logger.info("joined matchid with scodes with audigent lookup data to get both mids and scodes")

            update_stats(
                quick_stats, "Audigent MatchIds with SCodes", "Success", 
                f"Latest Audigent Lookup: {aud_lookup_file}; Latest MatchId with Scodes: {mid_with_scodes_file}; Found {idg_mids_with_scodes.count():,} MatchId-SCode Records"
            )
        except Exception as e:
            update_stats(quick_stats, "Audigent MatchIds with SCodes", "Failed", str(e))
            raise
                  
        ##Graphs
        for idg in graphs:
            try:
                idg_file = latest_hdfs_file(f"{idg_graph_path}/{idg}", pattern=idg)
                logger.info(f"latest {idg} graph file: {idg_file}")

                idg_df = ctx.read.parquet(idg_file)           
                logger.info(f"read latest {idg} graph")

                idg_datecol = [i["datecol"] for i in idg_config if i["id"] == idg][0]
                logger.info(f"date column to be used for {idg}: {idg_datecol}")

                update_stats(quick_stats, f"{idg.upper()} Graph Load", "Success", f"Latest {idg} Graph: {idg_file} loaded with {idg_df.count():,} records, datecolumn: {idg_datecol}")
            except Exception as e:
                update_stats(quick_stats, f"{idg.upper()} Graph Load", "Failed", str(e))
                raise
            
            try:
                if idg != "hems":
                    idg_fmt = format_graph(idg_df, idg, idg_datecol, date180)
                    logger.info(f"formatted {idg} graph")

                    idg_ranked = apply_rank(idg_fmt, idg, idg_datecol)
                    logger.info(f"ranked {idg} graph")

                    if idg in ["maids", "uid", "apnids", "ttdids"]:
                        idg_ranked = idg_ranked.where(F.col('week0')> 0)

                    idg_agg = agg_graph(idg_ranked, idg, idg_datecol)            
                    idg_agg.cache().count()
                    logger.info(f"grouped {idg} graph by match_id and {idg} and aggregated max {idg_datecol}")

                    idg_agg_with_scodes =  (
                        idg_agg
                        .join(idg_mids_with_scodes, 'match_id', 'inner')
                        .drop('match_id')
                    )
                    logger.info(f"joined aggregated {idg} graph with matchid with scodes")
                else:
                    idg_agg_with_scodes = format_hems_graph(idg_df, idg_mids_with_scodes)
                    logger.info("formatted hems graph")
                
                update_stats(quick_stats, f"{idg.upper()} Graph Formatting", "Success", f"Formatted and ranked {idg} Graph with Audigent MatchId-SCodes: {idg_agg_with_scodes.count():,} records")
            except Exception as e:
                update_stats(quick_stats, f"{idg.upper()} Graph Formatting", "Failed", str(e))
                raise
            
            try:
                final_idg = (
                    idg_agg_with_scodes
                    .join(cbk, 'match_id_audigent', 'inner')
                    .withColumnRenamed('cb_key_household', 'hh_id')
                    .select('hh_id', idg, 'last_seen', 's_code')
                )

                final_idg.cache()
                logger.info(f"joined formatted {idg} graph with matchid with scodes to get final audigent {idg} graph")

                final_idg.repartition(10).write.csv(out_path.format(ident=idg), header=True, mode='overwrite', compression='gzip')
                logger.info(f"written output to path: {out_path.format(ident=idg)}")

                file_stats = {
                    'record_count': f"{final_idg.count():,}",
                    'matchid_count': f"{final_idg.select('hh_id').distinct().count():,}",
                    'id_count': f"{final_idg.select(idg).distinct().count():,}",
                    'all_columns': final_idg.columns
                }

                update_stats(quick_stats, f"{idg.upper()} Graph Write", "Success", f"Written {idg} Graph to Path: {out_path.format(ident=idg)}, Final Stats: {file_stats}")
            except Exception as e:
                update_stats(quick_stats, f"{idg.upper()} Graph Write", "Failed", str(e))
                raise

            time.sleep(60)

            try:
                ## Rename it based on Audigent format i.e. UK__experianuk_{ident}_UK_{mask}_001.csv.gz
                all_idg_files = get_all_files(out_path.format(ident=idg))
                logger.info(f"all {idg} files: {all_idg_files}")

                if len(all_idg_files) == 0:
                    raise Exception("No files found to rename")

                rename_files(logger, mask, all_idg_files, idg)

                new_files = get_all_files(out_path.format(ident=idg))
                logger.info(f"new_files : {','.join(new_files)}")

                update_stats(quick_stats, f"{idg.upper()} Graph Rename", "Success", f"Renamed {len(all_idg_files)} {idg} Graph Files as per Audigent Format i.e. {new_files[0]}")
            except Exception as e:
                update_stats(quick_stats, f"{idg.upper()} Graph Rename", "Failed", str(e))
                raise
            
            success_flag = True
    except Exception as e:
        logger.error(e)
        success_flag = False
        send_status_email("Error: aud02_generate_data script failed", e, email_to)
        raise
    finally:
        alerts_df = pd.DataFrame(quick_stats)    
        email_sub = f"***AUD02 - Generate Audigent Data - {STATUS_EMOJIS['green']}***" if success_flag else f"***AUD02 - Generate Audigent Data - {STATUS_EMOJIS['red']}***"
        send_teams_email(mask, email_sub, alerts_df.to_html(index=False))
        endtime = datetime.now()
        logger.info(f"process completed in {str(endtime - startime).split('.')[0]}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-m", "--mask", help="date on which process is run in format YYYY-MM-DD", default=TODAY_DATE)
    parser.add_argument("-g", "--graphs", help="the identifiers which will be sent to audigent", default=AUD_IDS)
    parser.add_argument("-ic", "--idg_config", help="the config specific to identifiers", default=GRAPH_CONFIG)
    parser.add_argument("-ilp", "--idg_lookup_path", help="idgraph parent lookup file path", default=LOOKUP_FILE_PATH)
    parser.add_argument("-igp", "--idg_graph_path", help="idgraph parent path", default=IDG_GRAPH_PATH)    
    parser.add_argument("-mwsp", "--mid_with_scodes_path", help="parent matchid to scodes file path", default=f"{AUD_PATH_HDFS}/*/")
    parser.add_argument("-op", "--out_path", help="cleaned audigent scodes are written out to this hdfs csv file path")
    parser.add_argument("-et", "--email_to", help="recipients of email alerts", default=EMAIL_TO)
    
    args = parser.parse_args()

    if args.out_path is None:
        args.out_path = f"{AUD_PATH_HDFS}/{args.mask}/audigent_{{ident}}_graph.csv"

    name = os.path.basename(__file__)
    logger = LogConfig(f"{LOGPATH}/{name}_{args.mask}.log").generate_logger(name)
    spark = SparkSession.builder.appName(f"{name}_{args.mask}").getOrCreate()
    logic_main(
        spark, logger, args.mask, args.graphs, args.idg_config, args.idg_lookup_path,
        args.idg_graph_path, args.mid_with_scodes_path, args.out_path, args.email_to
    )