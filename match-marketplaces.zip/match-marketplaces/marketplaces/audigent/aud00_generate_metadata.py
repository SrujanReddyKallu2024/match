import pandas as pd
import sys
from pathlib import Path
import argparse
import os
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from datetime import datetime

sys.path.append(str(Path(__file__).resolve().parents[2]))

from config import LogConfig, LOGPATH, TODAY_DATE, MKP_SCODES_PATH_LOCAL, METADATA_PATH, TAX_PATH, AUD_PATH_HDFS, EMAIL_TO, STATUS_EMOJIS
from functions import latest_hdfs_file, latest_local_file, get_all_files, rename_files, send_status_email, update_stats, send_teams_email


def logic_main(ctx, logger, mask, scodes_path, scodes_desc_path, tax_path, out_path, email_to):
    logger.info(f"running aud00 generate metadata script for mask: {mask}")
    quick_stats = []

    try:
        startime = datetime.now()
        try:
            latest_scodes_path = latest_local_file(scodes_path, pattern='audigent_marketplacefile', dateformat=r"%Y-%m-%d")
            logger.info(f"latest scodes file: {latest_scodes_path}")
            
            pd_scodes_df = pd.read_excel(latest_scodes_path).rename({
                'UK Taxonomy S codes': 'S_Code',
            }, axis=1)
            logger.info("read scodes data from local path")

            update_stats(quick_stats, "Audigent SCodes", "Success", f"Found {pd_scodes_df.size:,} Audigent SCodes from Path: {latest_scodes_path}")
        except Exception as e:
            update_stats(quick_stats, "Audigent SCodes", "Failed", str(e))
            raise
            
        try:
            latest_scodes_desc_path = latest_local_file(scodes_desc_path, pattern='scode_descriptions')
            logger.info(f"latest scodes file with descriptions: {latest_scodes_desc_path}")

            pd_scodes_desc_df = pd.read_csv(latest_scodes_desc_path)
            logger.info("read scodes data with descriptions from local path")

            update_stats(quick_stats, "Available SCode Descriptions", "Success", f"Available {pd_scodes_desc_df.size:,} SCodes with Descriptions from Path: {latest_scodes_desc_path}")
        except Exception as e:
            update_stats(quick_stats, "Available SCode Descriptions", "Failed", str(e))
            raise
        
        try:
            pd_scodes_with_desc = pd_scodes_df.merge(pd_scodes_desc_df, on='S_Code', how='inner')
            logger.info("merged audigent scodes data with descriptions")

            sp_scodes_df = ctx.createDataFrame(pd_scodes_with_desc)
            logger.info("converted pandas df to pyspark")

            aud_scodes_with_desc = (
                sp_scodes_df
                .withColumn('S_Code', F.regexp_replace('S_Code', r'^S[0]*', 'S'))            
            )
            logger.info("cleaned scodes data")

            update_stats(quick_stats, "SCodes with Descriptions", "Success", f"Attached Descriptions to ({aud_scodes_with_desc.count():,}) Audigent SCodes")
        except Exception as e:
            update_stats(quick_stats, "SCodes with Descriptions", "Failed", str(e))
            raise

        try:
            latest_tax_path = latest_hdfs_file(tax_path, pattern='2')
            latest_tax_file = os.path.join(latest_tax_path, "process", "dt_long_cb_key_hh_s.parquet")
            logger.info(f"latest taxonomy file: {latest_tax_file}")

            tax_df = ctx.read.parquet(latest_tax_file).select('S_Code').distinct()
            tax_df.cache().count()
            logger.info("read taxonomy data")

            result = (
                tax_df            
                .join(aud_scodes_with_desc, 'S_Code', 'inner')
                .select("S_Code", "Segment_Description")
            )
            logger.info("joined tax data with audigent scodes such that we only send available scodes")

            result.repartition(1).write.csv(out_path, mode='overwrite', header=True, compression='gzip')
            logger.info(f"written cleaned scodes data to hdfs: {out_path}")

            update_stats(quick_stats, "Taxonomy Scodes", "Success", f"Retrieved Available SCodes ({tax_df.count():,}) from Latest Taxonomy file: {latest_tax_file} and wrote out output to {out_path}")
        except Exception as e:
            update_stats(quick_stats, "Taxonomy Scodes", "Failed", str(e))
            raise
        
        try:
            ## Rename metadata file based on Audigent format i.e. UK__experianuk_meta_UK_{nowdate}_{unix}.csv.gz            
            all_files = get_all_files(out_path)
            logger.info(f"all files: {all_files}")

            if len(all_files) == 0:
                raise Exception("No files found to rename")
            
            rename_files(logger, mask, all_files, 'meta')

            new_files = get_all_files(out_path)
            logger.info(f"new_files : {','.join(new_files)}")
            update_stats(quick_stats, "Rename Metadata", "Success", f"Renamed {len(all_files)} Metadata Files to Audigent Format i.e. {','.join(new_files)}")
        except Exception as e:
            update_stats(quick_stats, "Rename Metadata", "Failed", str(e))
            raise

        success_flag = True
    except Exception as e:
        logger.error(e)
        success_flag = False
        send_status_email("Error: aud00_get_scodes script failed", e, email_to)
        raise
    finally:
        alerts_df = pd.DataFrame(quick_stats)    
        email_sub = f"***AUD00 - Generate Audigent Metadata - {STATUS_EMOJIS['green']}***" if success_flag else f"***AUD00 - Generate Audigent Metadata - {STATUS_EMOJIS['red']}***"
        send_teams_email(mask, email_sub, alerts_df.to_html(index=False))
        endtime = datetime.now()
        logger.info(f"process completed in {str(endtime - startime).split('.')[0]}")


if __name__ == "__main__":
    ## Setup Args
    parser = argparse.ArgumentParser()

    parser.add_argument("-m", "--mask", help="date on which process is run in format YYYY-MM-DD", default=TODAY_DATE)
    parser.add_argument("-sp", "--scodes_path", help="local parent file path containing scodes for all marketplaces", default=MKP_SCODES_PATH_LOCAL)
    parser.add_argument("-sdp", "--scodes_desc_path", help="local parent file path containing scodes with descriptions", default=METADATA_PATH)
    parser.add_argument("-tp", "--tax_path", help="parent hdfs file path for taxonomy file", default=TAX_PATH)
    parser.add_argument("-et", "--email_to", help="recipients of email alerts", default=EMAIL_TO)
    parser.add_argument("-op", "--out_path", help="cleaned audigent scodes are written out to this hdfs file path")

    args = parser.parse_args()
    if args.out_path is None:
        args.out_path = f"{AUD_PATH_HDFS}/{args.mask}/metadata__{datetime.now().strftime('%H-%M-%S')}.csv"


    ## Setup Spark and logging
    name = os.path.basename(__file__)
    logger = LogConfig(f"{LOGPATH}/{name}_{args.mask}.log").generate_logger(name)
    spark = SparkSession.builder.appName(f"{name}_{args.mask}").getOrCreate()

    ## Process starts here
    logic_main(spark, logger, args.mask, args.scodes_path, args.scodes_desc_path, args.tax_path, args.out_path, args.email_to)