from pyspark.sql import SparkSession
import pyspark.sql.functions as F
import sys
from pathlib import Path
import pandas as pd
from datetime import datetime
import argparse
import os

sys.path.append(str(Path(__file__).resolve().parents[2]))

import config as c
import functions

def logic_main(ctx, logger, mask, input_file_path, output_file_path, email_to):
    logger.info(f"running inf00_convert_lookup script for mask: {mask}")
    quick_stats=[]
    try:
        startime = datetime.now()
        in_ext = input_file_path.split(".")[-1]
        logger.info(f"input file extension: {in_ext}")
        
        # Read the input file
        if in_ext == "csv":
            df = ctx.read.csv(input_file_path, header=True)
        elif in_ext == "parquet":
            df = ctx.read.parquet(input_file_path)
        else:
            raise ValueError(f"file extension {in_ext} not supported")
        logger.info(f"data read successfully, count: {df.count()}")
        
        # Convert the data
        df.toPandas().to_csv(output_file_path, index=False)
        logger.info(f"data converted to single csv file: {output_file_path}")
                    
        functions.update_stats(quick_stats, "Converted Infosum CBK-MatchID Lookup", "Success", f"Latest Infosum lookup: {input_file_path}, Converted to: {output_file_path}")
        success_flag = True
    except Exception as e:        
        functions.update_stats(quick_stats, "Converted Infosum CBK-MatchID Lookup", "Failed", str(e))
        functions.send_status_email("Error: inf00_convert_lookup script failed", e, email_to)
        success_flag = False
        raise
    finally:
        alerts_df = pd.DataFrame(quick_stats)    
        email_sub = f"***INFO00 - Convert Infosum CBK Lookup - {c.STATUS_EMOJIS['green']}***" if success_flag else f"***INFO00 - Convert Infosum CBK Lookup - {c.STATUS_EMOJIS['red']}***"
        functions.send_teams_email(mask, email_sub, alerts_df.to_html(index=False))
        endtime = datetime.now()
        logger.info(f"process completed in {str(endtime - startime).split('.')[0]}")




if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-m", "--mask", help="date on which process is run in format YYYY-MM-DD", default=c.TODAY_DATE)
    parser.add_argument("-ifp", "--input_file_path", help="input cbk-matchid lookup parquet file")      
    parser.add_argument("-ofp", "--output_file_path", help="output cbk-matchid lookup csv file")
    parser.add_argument("-et", "--email_to", help="recipients of email alerts", default=c.EMAIL_TO)
    
    args = parser.parse_args()

    name = os.path.basename(__file__)
    logger = c.LogConfig(f"{c.LOGPATH}/{name}_{args.mask}.log").generate_logger(name)
    spark = SparkSession.builder.appName(f"{name}_{args.mask}").getOrCreate()

    logic_main(spark, logger, args.mask, args.input_file_path, args.output_file_path, args.email_to)
