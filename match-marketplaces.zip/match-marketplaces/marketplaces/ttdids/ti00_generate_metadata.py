import pandas as pd
import sys
from pathlib import Path
import argparse
import os
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from datetime import datetime
import time

sys.path.append(str(Path(__file__).resolve().parents[2])) # should be setting PYTHONPATH

import config 
import functions
import logging

def check_weird_codes(df, column_name, logger):
    weird_codes = df[column_name].where(df[column_name].str.contains("xa", regex=False)).dropna().to_list()
    weird_codes = [code for code in weird_codes if "\\" in code]
    logger.info(f"checking for weird codes in {column_name}")
    if len(weird_codes) > 0:
        logger.error(f"found weird codes in {column_name}: {weird_codes}")
        raise ValueError(f"found weird codes in {column_name}: {weird_codes}")


def replace_characters(df, column_name, char_replacements, trim_edges=True):
    for char, replacement in char_replacements.items():
        df[column_name] = df[column_name].str.replace(char, replacement, regex=False)
        if trim_edges: df[column_name] = df[column_name].str.strip()


def format_metadata(df, segment_prefix):
    """
    Format the marketplace file based on desired format
    """
    df1 = (
        df[["SEGMENT ID","Parent  ID","Full Path","SEGMENT DESCRIPTION","Depth","PRICING ($)","Buyable 1(YES) or 0(NO)"]].rename({
            "SEGMENT ID":"ElementId",
            "Parent  ID":"ParentId",
            "Full Path":"DisplayName",
            "SEGMENT DESCRIPTION":"Segment_Description",
            "Depth":"Depth",
            "PRICING ($)":"CPMRate",
            "Buyable 1(YES) or 0(NO)":"Buyable",
        },axis=1)
    )

    # Replace long dashes with hyphens in Segment_Name and Description    
    char_replacements = {
        "\\xa3": "£",
        "\\xa0": " "
    }

    replace_characters(df1, "DisplayName", char_replacements)
    replace_characters(df1, "Segment_Description", char_replacements)

    check_weird_codes(df1, "DisplayName", logger)
    check_weird_codes(df1, "Segment_Description", logger)


    df1.replace(r"N/A","",inplace=True)

    df2 = df1[df1.ElementId.str.match(f"{segment_prefix}\d+")].copy()
    df2['num'] = df2.ElementId.str.replace(segment_prefix,"").astype("int")
    df2.sort_values("num",inplace=True)
    df2['ElementId'] = segment_prefix + df2['num'].astype(str).str.zfill(7)
    df2.drop(columns=["num"],inplace=True)
    return df2

def create_local_parent_dir(output_folder):
    if not os.path.exists(output_folder):
        if args.make_local_dir:
            try:
                os.makedirs(output_folder)
            except:
                raise Exception(f"failed to create output folder: {output_folder}")
        else:
            raise Exception(f"output folder does not exist: {output_folder}")


def logic_main(mask, email_to, output_folder, make_local_dir, previous_tax_location, client_id, metadata_path, taxonomy_filter, segment_prefix, skiprows):

    # import functions after logger is created
    import functions
    logger.info(f"running {__file__} script for mask: {mask}")
    quick_stats = []

    try:
        startime = datetime.now()

        try:
            marketplace_taxonomy = functions.latest_local_file(metadata_path, taxonomy_filter, dateformat="%Y-%m-%d")
            logger.info(f"latest ttdids file: {marketplace_taxonomy}")            

            if marketplace_taxonomy.endswith(".xlsx"):
                input_df = pd.read_excel(marketplace_taxonomy, sheet_name="Experian Taxonomy", skiprows=skiprows)
            elif marketplace_taxonomy.endswith(".csv"):
                input_df = pd.read_csv(marketplace_taxonomy, skiprows=skiprows, encoding="utf-8", encoding_errors="backslashreplace")

            logger.info("read data from marketplace file")

            functions.update_stats(quick_stats, "Trade Desk IDs Metadata Input", "Success", f"Found total of {input_df.shape[0]:,} rows in from Path: {marketplace_taxonomy}")
        except Exception as e:
            functions.update_stats(quick_stats, "Trade Desk IDs Metadata Input", "Failed", str(e))
            raise
            
        try:
            df_formatted = format_metadata(input_df, segment_prefix)
            logger.info(f"formatted input data and filtered out non-country segments, current count: {df_formatted.shape[0]:,} rows")            

            # got the new tanomy file need to compare to previous before write out
            # otherwise it will pick up the one wer're writing out now

            # try:
            #     if functions.platform.is_local:
            #         last_taxonomy = functions.latest_local_file(previous_tax_location, pattern="20", dateformat="%Y-%m-%d", isdir=True)
            #     else:
            #         last_taxonomy = os.path.join( functions.latest_hdfs_file(previous_tax_location, "20"),
            #                                     f"{client_id}__replace__fw_taxonomy.csv"
            #         )
            #         if len(functions.list_files(last_taxonomy)) == 0: last_taxonomy = None
            # except Exception as e:
            #     last_taxonomy = None
            #     logger.warning(f"failed to find previous taxonomy file: {e}")

                
            # if last_taxonomy:                    
            #     logger.info(f"last taxonomy file: {last_taxonomy}")
            #     df_last_taxonomy = spark.read.csv(last_taxonomy, header=True).toPandas()
            #     logger.info(f"read last taxonomy file with {df_last_taxonomy.shape[0]:,} rows")
            #     df_remove = df_last_taxonomy[~df_last_taxonomy["Segment ID"].isin(df_formatted["Segment ID"])]
            #     df_remove = df_remove[["Segment ID"]]
            #     removals = int(f"{df_remove.shape[0]:,}")
            #     logger.info(f"filtered out segments that are not in the current file, current count: {removals} rows")
# 
            #     if removals > 0:                        
            #         output_file_remove = f"{output_folder}/{config.FW_TAX_FILENAME.format(clientid=client_id, logic='remove', filename=f'fw_taxonomy')}"
            #         df_remove.to_csv(output_file_remove, index=False)
            #         logger.info(f"saved formatted remove data to local path: {output_file_remove}")
            #         functions.update_stats(quick_stats, "Trade Desk IDs Metadata Output", "Success", 
            #             f"Formatted and saved {removals:,} rows to local path: {output_file_remove}")
            #         
            #     else:
            #         functions.update_stats(quick_stats, "Trade Desk IDs Metadata Output", "Success", 
            #             f"Segment IDs in previous file match current file, no removals needed")
            # else:
            #     logger.warning("no previous taxonomy file found, skipping remove file creation")
                
    
            if make_local_dir: create_local_parent_dir(output_folder)

            if taxonomy_filter == "ttdid_marketplacefile":
                output_file = f"{output_folder}/{config.TTD_TTDIDS_TAXONOMY_FILENAME}"
            elif taxonomy_filter == "ttdda_marketplacefile":
                output_file = f"{output_folder}/{config.TTD_TTDDA_TAXONOMY_FILENAME}"
            else:
                raise ValueError(f"unknown taxonomy filter: {taxonomy_filter}")

            df_formatted.to_csv(output_file, index=False)
            # logger.info(f"saved formatted replace data to local path: {output_file_replace}")            
            # functions.update_stats(quick_stats, "Trade Desk IDs Metadata Output", "Success", 
            #                        f"Formatted and saved {df_formatted.shape[0]:,} rows to local path: {output_file_replace}")
                                   
            # need to get the removes as well as the replace
            # previous is here: $FW_HDFS_DIR/$RUNDATE


        except Exception as e:
            functions.update_stats(quick_stats, "Trade Desk IDs Metadata Output", "Failed", str(e))
            raise
        
        success_flag = True

    except Exception as e:
        logger.error(e)
        success_flag = False
        functions.send_status_email(f"Error: {__file__} script failed",  e, email_to=email_to)
        raise
    finally:
        alerts_df = pd.DataFrame(quick_stats)    
        title = "FW00 - Generate Trade Desk IDs metadata"
        email_sub = f"***{title} - {config.STATUS_EMOJIS['green']}***" if success_flag else f"***{title} - {config.STATUS_EMOJIS['red']}***"
        functions.send_teams_email(mask, email_sub, alerts_df.to_html(index=False), email_to=email_to)
        endtime = datetime.now()
        logger.info(f"process completed in {str(endtime - startime).split('.')[0]}")

def setup_parser():
    ## Setup Args
    parser = argparse.ArgumentParser()
    parser.add_argument("-m", "--mask", help="date on which process is run in format YYYY-MM-DD", default=config.TODAY_DATE)
    parser.add_argument("-of", "--output_folder", required=True, help="formatted marketplace file sent to this local file path")    
    parser.add_argument("-mld", "--make_local_dir", help="optionally make local directory if it doesn't exist", action="store_true")
    parser.add_argument("-pt", "--previous_tax_location", help="location of previous taxonomy file has a folder with rundate and a name containing fw_taxonomy", default=None)
    parser.add_argument("-cid", "--client_id", help="client id for the output file", default=config.FW_DEFAULT_CLIENT_ID)
    parser.add_argument("-md", "--metadata_path", help="local path to the ttdids marketplace file", default=config.MKP_SCODES_PATH_LOCAL)
    parser.add_argument("-tf", "--taxonomy_filter", help="filter for marketplace file discovery", default="ttdid_marketplacefile")
    parser.add_argument("-sk", "--skiprows", help="number of rows to skip", default=0, type=int)
    parser.add_argument("-sp", "--segment_prefix", help="prefix for segment ids", required=True)
    return parser

if __name__ == "__main__":
    
    parser = setup_parser()
    config_parser = config.setup_parser()
    
    # Manually add each argument from config.py to the main parser
    for action in config_parser._actions:
        parser._add_action(action)  # This adds the arguments from config.py
    
    args, unknown = parser.parse_known_args()    

    ## Setup Spark and logging
    name = os.path.basename(__file__)
    
    logger = config.LogConfig(f"{config.LOGPATH}/{name}_{args.mask}.log").generate_logger(name)
    spark = SparkSession.builder.appName(f"{name}_{args.mask}").getOrCreate()

    logger.info(f"args are {args}")  
    logger.info("setup complete")
    logger.info(f"output path: {args.output_folder}")

    if functions.platform.is_local:
        logger.info(f"running windows or docker, email is {config.EMAIL_TO}")
        if "alerts" in config.EMAIL_TO:
            logger.error(f"Email address {config.EMAIL_TO} is not valid in local environment")
            sys.exit(1)

    ## Process starts here
    logic_main(args.mask, config.EMAIL_TO, args.output_folder, args.make_local_dir, args.previous_tax_location, args.client_id, args.metadata_path, taxonomy_filter=args.taxonomy_filter, segment_prefix=args.segment_prefix, skiprows=args.skiprows)

# Testing command
# docker run -it --rm -v %cd%:/hello -e PYTHONPATH=/hello/marketplaces -w /hello pysparktestboto /opt/spark/bin/spark-submit /hello/marketplaces/ttdids/ti00_generate_metadata.py --mask 2022-02-22 --output_folder /hello/testing/metadata/plop2 --make_local_dir --email robin.potter@experian.com --segment_prefix SU -md metadata
# spark-submit marketplaces/freewheel/fw00_generate_metadata.py --mask 2022-02-22 --output_folder testing/metadata --email_to robin.potter@experian.com 



# docker run -it --rm -v %cd%:/hello -e PYTHONPATH=/hello/marketplaces -w /hello pysparktestboto /opt/spark/bin/
# 
# spark-submit /hello/marketplaces/ttdids/ti00_generate_metadata.py  --email robin.potter@experian.com --segment_prefix SU 