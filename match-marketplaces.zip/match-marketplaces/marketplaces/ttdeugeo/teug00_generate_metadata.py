import pandas as pd
import sys
from pathlib import Path
import argparse
import os
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from datetime import datetime
import time

sys.path.append(str(Path(__file__).resolve().parents[2]))

import config
import functions

def format_metadata(df, country):
    """
    Format the marketplace file based on desired format
    """
    df1 = (
        df[["SEGMENT ID","Parent  ID","Segment Name","Full Path","PRICING ($)","Buyable 1(YES) or 0(NO)", "MediaCostRate"]].rename({
            "SEGMENT ID":"ElementId",
            "Parent  ID":"ParentId",
            "Segment Name":"Name",
            "Full Path":"Segment_Description",
            "PRICING ($)":"CPMRate",
            "Buyable 1(YES) or 0(NO)":"Buyable",
            "MediaCostRate": "MediaCostRate",
        },axis=1)
    )
    df1.replace(r"N/A","",inplace=True)
    logger.info(f"replaced N/A with empty string in input data")
    logger.info(f"input data shape: {df1.shape}")
    df1['Segment_Description'] = df1['Segment_Description'].str.replace('\u00A0', ' ', regex=False)
    df2 = df1[df1.ElementId.str.match(f"{country}\d+") | df1.ParentId.str.match("ROOT")].copy()
    logger.info(f"filtered out non-country segments, current count: {df2.shape[0]:,} rows")
    df2.loc[df2.ParentId == "ROOT", "Segment_Description"] = f"{country} > " + df2.loc[df2.ParentId == "ROOT", "Segment_Description"]
    df2["num"] = df2[df2.ParentId!="ROOT"].ElementId.str.replace(country,"").astype("int")
    df2.num = df2.num.fillna(0)
    df2.num = df2.num * 1000000 + df2.index
    df2.sort_values("num",inplace=True)
    df2.drop(columns=["num"],inplace=True)

    # raise exception if the columns CPMRate,Buyable, or MediaCostRate contain no data where the ELementId column, matches country and number
    if df2[df2.ElementId.str.match(f"{country}\d+")][["CPMRate","Buyable","MediaCostRate"]].isnull().all().any():
        raise ValueError(f"Columns CPMRate, Buyable, or MediaCostRate contain no data for country {country} in ElementId column")

    return df2


def logic_main(ctx, logger, mask, in_local_path, out_local_path, email_to, country):
    logger.info(f"running teug00_generate_metadata script for mask: {mask}")
    quick_stats = []

    try:
        startime = datetime.now()
        try:
            #latest_mkp_file = functions.latest_local_file(in_local_path, pattern='ttdeu_marketplacefile', dateformat=r"%Y-%m-%d")
            
            if in_local_path.endswith("xlsx"):
                latest_mkp_file = in_local_path
            else:
                raise ValueError("Input file is not an excel file")
            
            logger.info(f"latest ttd file: {latest_mkp_file}")            

            input_df = pd.read_excel(latest_mkp_file, sheet_name="Experian Taxonomy", skiprows=1)
            logger.info("read data from marketplace file")

            functions.update_stats(quick_stats, "TTD Metadata Input", "Success", f"Found total of {input_df.shape[0]:,} rows in from Path: {latest_mkp_file}")
          
        except Exception as e:
            functions.update_stats(quick_stats, "TTD Metadata Input", "Failed", str(e))
            raise
            
        try:
            df_formatted = format_metadata(input_df, country)
            logger.info(f"formatted input data and filtered out non-country segments, current count: {df_formatted.shape[0]:,} rows")            
            
            df_formatted.to_csv(out_local_path, index=False)
            logger.info(f"saved formatted data to local path: {out_local_path}")            

            functions.update_stats(quick_stats, "TTD Metadata Output", "Success", f"Formatted and saved {df_formatted.shape[0]:,} rows and {df_formatted.shape[1]:,} columns to local path: {out_local_path}")
            logger.info(f"Formatted and saved {df_formatted.shape[0]:,} rows and {df_formatted.shape[1]:,} columns to local path: {out_local_path}")

            # input data shape: (319, 7)
            if df_formatted.shape[0] != 278 or df_formatted.shape[1] != 7:
                raise ValueError(f"Input data shape is not as expected, found {df_formatted.shape}, expected (278, 7)")
            

        except Exception as e:
            functions.update_stats(quick_stats, "TTD Metadata Output", "Failed", str(e))
            raise
        success_flag = True
    except Exception as e:
        logger.error(e)
        success_flag = False
        functions.send_status_email("Error: teug00_generate_metadata script failed", e, email_to)
        raise
    finally:
        alerts_df = pd.DataFrame(quick_stats)    
        email_sub = f"***TEUG00 - Generate TTD metadata - {config.STATUS_EMOJIS['green']}***" if success_flag else f"***TEUG00 - Generate TTD metadata - {config.STATUS_EMOJIS['red']}***"
        functions.send_teams_email(mask, email_sub, alerts_df.to_html(index=False), email_to=email_to)
        endtime = datetime.now()
        logger.info(f"process completed in {str(endtime - startime).split('.')[0]}")

def setup_parser():
    parser = argparse.ArgumentParser()
    parser.add_argument("-m", "--mask", help="date on which process is run in format YYYY-MM-DD", default=config.TODAY_DATE)    
    parser.add_argument("-ilp", "--in_local_path", help="file path of the actual file", required=True)                
    parser.add_argument("-olp", "--out_local_path", help="formatted marketplace file sent to local file path")
    parser.add_argument("-et", "--email_to", help="recipients of email alerts", default=config.EMAIL_TO)
    parser.add_argument("-c", "--country", help="country code to filter out segments", required=True)
    return parser

if __name__ == "__main__":
    ## Setup Args
   
    parser = setup_parser()
    config_parser = config.setup_parser()
    
    # Manually add each argument from config.py to the main parser
    for action in config_parser._actions:
        parser._add_action(action)  # This adds the arguments from config.py
    
    args, unknown = parser.parse_known_args()

    if args.out_local_path is None:        
        args.out_local_path = f"{config.TTD_GEO_TEMP_LOCAL_PATH}/Update.TTDGEO.Taxonomy.{args.country}.{datetime.now().strftime(r'%Y%m%d%H%M%S')}.csv"

    ## Setup Spark and logging
    name = os.path.basename(__file__)
    logger = config.LogConfig(f"{config.LOGPATH}/{name}_{args.mask}.log").generate_logger(name)
    spark = SparkSession.builder.appName(f"{name}_{args.mask}").getOrCreate()

    # needs to be uppercase
    args.country = args.country.upper()

    ## Process starts here
    logic_main(spark, logger, args.mask, args.in_local_path, args.out_local_path, args.email_to, args.country)

# testing command
# it will want testing/data/local/data_from_sts/temp/ttd/geo creating
# docker run -it --rm -v %cd%:/hello -e PYTHONPATH=/hello/marketplaces -w /hello pysparktestboto /opt/spark/bin/spark-submit /hello/marketplaces/ttdeugeo/teug00_generate_metadata.py -et robin.potter@experian.com -ilp metadata --sts_path /hello/testing/data/local/data_to_sts -c se
