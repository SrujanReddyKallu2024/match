# TTD Geo EMR Serverless Job Documentation

## TTD Geo Job File Mapping

### Metadata Job

| File(s)              | Entrypoint Argument | Current Path Example                                              | S3 Path Example                                                                 | Source Job      |
|----------------------|--------------------|-------------------------------------------------------------------|---------------------------------------------------------------------------------|-----------------|
| Metadata Input       | --input_path       | /marketplaces/ttdgeo/metadata/<date>/ttdgeo_taxonomy_<cc>.xlsx    | s3a://<source_bucket>/marketplaces/ttdgeo/metadata/<date>/ttdgeo_taxonomy_<cc>.xlsx | Raw Excel       |
| Metadata Output      | --output_path      | /marketplaces/ttdgeo/metadata/<date>/Update.TTDGEO.Taxonomy.<cc>.<datetime>.csv | s3a://<output_bucket>/marketplaces/ttdgeo/metadata/<date>/Update.TTDGEO.Taxonomy.<cc>.<datetime>.csv | Formatted CSV   |
| Email Subject/Body   | --email_data_key   | /marketplaces/ttdgeo/metadata/<cc>/<date>/subject.txt, body.txt   | s3a://<temp_bucket>/marketplaces/ttdgeo/metadata/<cc>/<date>/subject.txt, body.txt | Notification    |
| Quick Stats OUT      | (internal)         | /ttdgeo/metadata_stats_<datetime>_formatted.txt                   | s3a://<stats_bucket>/ttdgeo/metadata_stats_<datetime>_formatted.txt              | Stats           |

### Data Job

| File(s)              | Entrypoint Argument | Current Path Example                                              | S3 Path Example                                                                 | Source Job      |
|----------------------|--------------------|-------------------------------------------------------------------|---------------------------------------------------------------------------------|-----------------|
| Geo Data Input       | --input_path       | /marketplaces/ttdgeo/data/<date>/ttdgeo_data.csv                  | s3a://<source_bucket>/marketplaces/ttdgeo/data/<date>/ttdgeo_data.csv            | Raw CSV         |
| Partitioned Output   | --output_path      | /marketplaces/ttdgeo/data/<date>/partitioned/ttd_<cc>.csv         | s3a://<temp_bucket>/marketplaces/ttdgeo/data/<date>/partitioned/ttd_<cc>.csv     | Partitioned     |
| Final Audience Output| --final_output_path| /marketplaces/ttdgeo/data/<date>/final/Replace.TTDGEO.<audience>.<datetime>.csv | s3a://<temp_bucket>/marketplaces/ttdgeo/data/<date>/final/Replace.TTDGEO.<audience>.<datetime>.csv | Audience CSV    |
| Email Subject/Body   | --email_data_key   | /marketplaces/ttdgeo/data/<cc>/<date>/subject.txt, body.txt       | s3a://<temp_bucket>/marketplaces/ttdgeo/data/<cc>/<date>/subject.txt, body.txt   | Notification    |
| Quick Stats OUT      | (internal)         | /ttdgeo/data_stats_<datetime>_formatted.txt                       | s3a://<stats_bucket>/ttdgeo/data_stats_<datetime>_formatted.txt                  | Stats           |

---
applyTo: '**'
---

## Overview
This document describes the end-to-end EMR Serverless workflow for TTD Geo data and metadata processing, including job orchestration, arguments, file paths, and output structure. It is designed for AWS EMR Serverless and Airflow (MWAA) environments.
- **JOB_NAME:** ttdgeo_metadata_emr
- **JOB_ID:** TTDGEO_META
- **JOB_TITLE:** "TTD GEO METADATA PROCESSING"
- **Description:** Processes TTD Geo metadata Excel files, formats, validates, and outputs CSVs partitioned by country.

### Data Job
- **JOB_NAME:** ttdgeo_data_emr
- **JOB_ID:** TTDGEO_DATA
- **JOB_TITLE:** "TTD GEO DATA PROCESSING"
- **Description:** Processes TTD Geo geo-coordinate CSV files, partitions by audience, and outputs individual audience CSVs.

## EMR Serverless Job Arguments

| Argument                | Type   | Default | Description |
|-------------------------|--------|---------|-------------|
| --input_path            | str    | None    | S3 path to input file (Excel for metadata, CSV for geo data) |
| --output_path           | str    | None    | S3 path for partitioned output (metadata or geo data) |
| --final_output_path     | str    | None    | S3 path for final audience CSVs (geo data only) |
| --execution_date        | str    | None    | Execution date in YYYY-MM-DD format |
| --country_code          | str    | None    | Country code for metadata processing |
| --email_data_bucket     | str    | None    | S3 bucket for email data |
| --email_data_key        | str    | None    | S3 key prefix for email data |

## Airflow DAG Orchestration

1. **Check for New Files:**
   - Lists metadata and geo data files in S3 source bucket.
   - Pushes file lists to XCom.
2. **Create Script Arguments:**
   - Calculates all S3 paths, bucket names, and workflow parameters.
   - Validates file existence.
3. **Initialise EMR Application:**
   - Creates EMR Serverless application for job execution.
4. **Process Metadata Files:**
   - Submits EMR job for each metadata file.
   - Sends email notification with status and stats.
5. **Process Data Files:**
   - Submits EMR job for each geo data file.
   - Sends email notification with status and stats.
6. **Move Output Files:**
   - Moves and renames output files from temp to final S3 location.
   - Sends email notification with status and stats.
7. **Finalise:**
   - Deletes EMR application and logs workflow completion.

## S3 File Paths

| File Type         | S3 Path Example |
|-------------------|-----------------|
| Metadata Input    | s3a://<source_bucket>/marketplaces/ttdgeo/metadata/<date>/ttdgeo_taxonomy_<cc>.xlsx |
| Metadata Output   | s3a://<output_bucket>/marketplaces/ttdgeo/metadata/<date>/Update.TTDGEO.Taxonomy.<cc>.<datetime>.csv |
| Geo Data Input    | s3a://<source_bucket>/marketplaces/ttdgeo/data/<date>/ttdgeo_data.csv |
| Geo Data Partitioned Output | s3a://<temp_bucket>/marketplaces/ttdgeo/data/<date>/partitioned/ttd_<cc>.csv |
| Geo Data Final Output | s3a://<temp_bucket>/marketplaces/ttdgeo/data/<date>/final/Replace.TTDGEO.<audience>.<datetime>.csv |
| Email Data        | s3a://<temp_bucket>/marketplaces/ttdgeo/metadata/<cc>/<date>/subject.txt, body.txt |
| Stats             | s3a://<stats_bucket>/ttdgeo/metadata_stats_<datetime>_formatted.txt |

## EMR Serverless SparkSubmit Parameters

```
--conf spark.submit.pyFiles=<shared_code_zip> \
--conf spark.driver.cores=<driver_cores> \
--conf spark.driver.memory=<driver_memory> \
--conf spark.executor.cores=<executor_cores> \
--conf spark.executor.memory=<executor_memory> \
--conf spark.archives=<python_env_file>#environment \
--conf spark.emr-serverless.driverEnv.PYSPARK_DRIVER_PYTHON=./environment/bin/python \
--conf spark.emr-serverless.driverEnv.PYSPARK_PYTHON=./environment/bin/python \
--conf spark.executorEnv.PYSPARK_PYTHON=./environment/bin/python
```
## Error Handling & Notifications
--input_path s3a://source_bucket/marketplaces/ttdgeo/data/2025-08-03/ttdgeo_data.csv \
--output_path s3a://temp_bucket/marketplaces/ttdgeo/data/2025-08-03/partitioned/ttd_{cc}.csv \
--final_output_path s3a://temp_bucket/marketplaces/ttdgeo/data/2025-08-03/final \
--execution_date 2025-08-03 \
--email_data_bucket temp_bucket \
--email_data_key marketplaces/ttdgeo/data/2025-08-03
```

## Example Job Arguments (Metadata)
```
--input_path s3a://source_bucket/marketplaces/ttdgeo/metadata/2025-08-03/ttdgeo_taxonomy_DK.xlsx \
--output_path s3a://output_bucket/marketplaces/ttdgeo/metadata/2025-08-03/Update.TTDGEO.Taxonomy.DK.20250803123456.csv \
--execution_date 2025-08-03 \
--country_code DK \
--email_data_bucket temp_bucket \
--email_data_key marketplaces/ttdgeo/metadata/DK/2025-08-03
```

## References
- [EMR Serverless Documentation](https://docs.aws.amazon.com/emr/latest/EMR-Serverless-UserGuide/)
- [Airflow MWAA Documentation](https://docs.aws.amazon.com/mwaa/latest/userguide/)
- [TTD Geo Project Source Code]

---

This documentation is designed to be copied into a `.md` file and kept up to date with any changes to the TTD Geo workflow or AWS infrastructure.
