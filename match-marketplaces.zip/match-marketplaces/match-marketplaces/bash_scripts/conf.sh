#!/bin/bash


## Base Configs
DATA_FROM_STS="/data/data_from_sts"
DATA_FROM_STS_BACKUP="/data/data_from_sts_backup"
DATA_TO_STS="/data/data_to_sts"
DATA_TO_STS_TEMP="/data/data_to_sts/temp"
FROM_EMAIL="activate_process_monitor@experian.com"
IDGRAPH_REPO="/home/unity/match-id-graph"
BASE_HDFS_DIR="/user/unity"
LOOKUP_HDFS_DIR="${BASE_HDFS_DIR}/id_graph/lookup"
IDG_SCRIPTDIR="/home/unity/match-id-graph/process"
CD_TEAM_PATH="${DATA_TO_STS}/client_services"

## Marketplace Paths
MKT_REPO="/home/unity/match-marketplaces"
MKP_LOCK_FILE_DIR="/tmp"
MKT_HDFS_DIR="${BASE_HDFS_DIR}/match2/marketplaces"
MKP_LOCAL_DIR="${DATA_TO_STS}/marketplaces"
MKP_SEG_FILE_DIR="${DATA_FROM_STS}/marketplace_input_files"
CURRENT_DIR="${MKT_REPO}/bash_scripts"
LOGS_DIR="${MKT_REPO}/logs"

## Queue names for Spark job execution
QUEUE1="andy"
QUEUE2="adam"
QUEUE3="unity"

## Date Variables
if [ $# -eq 0 ]; then
    #echo "No arguments provided"
    RUNDATE=$(date +%Y-%m-%d)
else
    RUNDATE=$1
fi

RUNTIME=$(date +%s)

SUN_DATE=$(date -d "$RUNDATE $(( $(date -d $RUNDATE +%u) - 7 )) days ago" +%Y-%m-%d)
SAT_DATE=$(date -d "$RUNDATE $(( $(date -d $RUNDATE +%u) - 6 )) days ago" +%Y-%m-%d)
LOOKUP_DATE_FORMAT=$(date -d "$RUNDATE" +%Y%m)
IDG_RUNDATE=$(date -d "$RUNDATE" +%Y%m%d)
DATEPART=$(date -d "$RUNDATE" +%d)

## Server
if [ "$(hostname)" == "ukfhpapmtc02" ]; then
    SERVERNAME="live"
    MAILLIST="emsactivatealerts@experian.com"
elif [ "$(hostname)" == "ukbldapmtc02" ]; then
    SERVERNAME="stage"
    MAILLIST="sujit.nair@experian.com,robin.potter@experian.com"
else #if [ "$(hostname)" == "ukbltapmtc01" ]; then
    SERVERNAME="dev"
    MAILLIST="robin.potter@experian.com"
fi

DEVSMAIL="robin.potter@experian.com,sujit.nair@experian.com"

if [ $(hostname | grep -Eo "uk.*mtc.*") ]; then
    SCHEDULER="--master yarn --queue $QUEUE1"
else
    SCHEDULER="--master local"
fi

## Audigent
AUD_LOOKUP_DIR="$LOOKUP_HDFS_DIR/audigent"
AUD_SCRIPT_DIR="$MKT_REPO/marketplaces/audigent"
AUD_MKT_HDFS_DIR="$MKT_HDFS_DIR/audigent"
AUD_IDS=( "ip" "hems" "maids" "uid" "ttdids" "apnids" )
AUD_LOCAL_TEMP_DIR="$DATA_TO_STS_TEMP/audigent"
AUD_LOCAL_DATA_DIR="$MKP_LOCAL_DIR/audigent/data"
AUD_LOCAL_METADATA_DIR="$MKP_LOCAL_DIR/audigent/taxonomy"
AUD_LOCAL_CUSTOM_INDIR="${DATA_FROM_STS}/internal/data"
AUD_LOCAL_CUSTOM_OUTDIR="${MKP_LOCAL_DIR}/audigent/custom"

##Peer39
P39_SCRIPT_DIR="$MKT_REPO/marketplaces/peer39"
P39_MKT_HDFS_DIR="$MKT_HDFS_DIR/peer39"
P39_LOCAL_TEMP_DIR="$DATA_TO_STS_TEMP/peer39"
P39_LOCAL_DIR="$MKP_LOCAL_DIR/peer39"
P39_DATE_FORMAT=$(date -d "$RUNDATE" +%m_%d_%Y)
P39_TAX_FLAG_PATH="/user/unity/id_graph/flags"
P39_MONTH=$(date -d "$RUNDATE" +%Y-%m)

##TTDGEO
TTDGEO_SCRIPT_DIR="$MKT_REPO/marketplaces/ttdeugeo"
TTDGEO_DATA_LOCAL_PATH="${DATA_FROM_STS}/internal/data"
TTDGEO_MKT_HDFS_DIR="$MKT_HDFS_DIR/ttd/geo"
TTDGEO_TEMP_LOCAL_PATH="$DATA_TO_STS_TEMP/ttd/geo"
if [ "$SERVERNAME" == "stage" ] || [ "$SERVERNAME" == "dev" ]; then
    TTDGEO_STS_LOCAL_PATH="$DATA_TO_STS/client_outputs/ttd/geo/uat"
else
    TTDGEO_STS_LOCAL_PATH="$DATA_TO_STS/client_outputs/ttd/geo/live"
fi


##Freewheel
FW_SCRIPT_DIR="$MKT_REPO/marketplaces/freewheel"
if [ "$SERVERNAME" == "stage" ] || [ "$SERVERNAME" == "dev" ]; then
    FW_STS_LOCAL_PATH="$DATA_TO_STS/client_outputs/freewheel/uat"
    FW_LOCAL_RESP_DIR="$DATA_FROM_STS/client_inputs/freewheel/uat"
    FW_FINAL_BUCKET="s3://aim-incoming-data-stg-eu-west-2"
else
    FW_STS_LOCAL_PATH="$DATA_TO_STS/client_outputs/freewheel/prod"
    FW_LOCAL_RESP_DIR="$DATA_FROM_STS/client_inputs/freewheel/prod"
    FW_FINAL_BUCKET="s3://aim-incoming-data-prd-eu-west-2"
fi
FW_CLIENT_DEFAULT_ID="-1"
FW_TAX_DEFAULT_LOGIC="replace"
FW_AUD_DEFAULT_LOGIC="segment_replace" #page 4/12 Audience Manager Direct Ingestion S3 Specification - MRM User Guide (TV Platform) - Site global (1).pdf
FW_DEFAULT_IDTYPE="ip"
FW_HDFS_DIR="$MKT_HDFS_DIR/freewheel"
FW_LOCAL_TMP_DIR="$DATA_TO_STS_TEMP/freewheel"
FW_LOCAL_TAX_DIR="$FW_STS_LOCAL_PATH/taxonomy"
FW_LOCAL_SEG_DIR="$FW_STS_LOCAL_PATH/segments"
FW_FINAL_LOCATION="${FW_FINAL_BUCKET}/audience_partner=experian/data_type=segment/client={clientid}/parsing_logic={logic}/delivery_date={date}/id_type={idtype}/{filename}"
FW_AUDIENCE_TRIGGER_FILENAME="{clientid}__{logic}__{idtype}__experian.trigger"

##Beeswax
BW_SCRIPT_DIR="$MKT_REPO/marketplaces/beeswax"
BW_LOCAL_TMP_DIR="$DATA_TO_STS_TEMP/beeswax"
BW_HDFS_DIR="$MKT_HDFS_DIR/beeswax"
BW_LOCAL_TAX_DIR="$MKP_LOCAL_DIR/beeswax/taxonomy"
BW_LOCAL_SEG_DIR="$MKP_LOCAL_DIR/beeswax/segments"
BW_LOCAL_RESP_DIR="$DATA_FROM_STS/client_inputs/beeswax"

##TTDIDS
TTDIDS_SCRIPT_DIR="$MKT_REPO/marketplaces/ttdids"
TTDIDS_MKT_HDFS_DIR="$MKT_HDFS_DIR/ttd/ttdids"
TTDIDS_TEMP_LOCAL_PATH="$DATA_TO_STS_TEMP/ttd/ttdids"
if [ "$SERVERNAME" == "stage" ] || [ "$SERVERNAME" == "dev" ]; then
    TTDIDS_STS_LOCAL_PATH="$DATA_TO_STS/client_outputs/ttd/geo/uat"
else
    TTDIDS_STS_LOCAL_PATH="$DATA_TO_STS/client_outputs/ttd/geo/live"
fi
TTDIDS_DATE=$(date +%Y%m%d%H%M%S)
TTD_TTDDA_TAXONOMY_FILENAME=ttdda_marketplacefile_${TTDIDS_DATE}.csv
TTD_TTDDA_TAXONOMY_FILENAME_OUTPUT=UPDATE.TTDDA.Taxonomy.${TTDIDS_DATE}.csv

##FW GEO
FWGEO_SCRIPT_DIR="$MKT_REPO/marketplaces/freewheelgeo"
FWGEO_TEMP_LOCAL_PATH="$DATA_TO_STS_TEMP/freewheelgeo"
FWGEO_STS_LOCAL_PATH="$DATA_TO_STS/client_outputs/freewheelgeo"
FWGEO_MKT_HDFS_DIR="$MKT_HDFS_DIR/freewheelgeo"
FWGEO_INPUT_DATA_DIR="$DATA_FROM_STS/internal/fwgeo"

##Infosum
INF_SCRIPT_DIR="$MKT_REPO/marketplaces/infosum"
INF_TEMP_LOCAL_PATH="$DATA_TO_STS_TEMP/infosum"
INF_MKT_HDFS_DIR="$MKT_HDFS_DIR/infosum"
INF_STS_LOCAL_PATH="$MKP_LOCAL_DIR/infosum"
INF_POSTAL_ADDRESS_DIR="${BASE_HDFS_DIR}/id_graph/pc/postal_address"

##Snowflake
SNF_LOOKUP_DIR="$LOOKUP_HDFS_DIR/snowflake"
SNF_SCRIPT_DIR="$MKT_REPO/marketplaces/snowflake"
SNF_MKT_HDFS_DIR="$MKT_HDFS_DIR/snowflake"
SNF_TEMP_LOCAL_PATH="$DATA_TO_STS_TEMP/snowflake"
SNF_STS_LOCAL_PATH="$MKP_LOCAL_DIR/snowflake"
