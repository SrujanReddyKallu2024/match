#!/bin/bash

dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
source $dir/../conf.sh
source $dir/../functions.sh

CURRENT_HOUR=$(date +%H)
TTDGEO_LOCK_FILE="${MKP_LOCK_FILE_DIR}/ttdgeo_${RUNDATE}.lock"


trigger_ttdgeo_metadata_generation() {    
    if is_file_ingestible $MKP_SEG_FILE_DIR "ttdeu_marketplacefile"
    then
        echo "Triggering TTD EU GEO Metadata Process"
        all_mkp_files=$(ls $MKP_SEG_FILE_DIR/ttdeu_marketplacefile*.xlsx)
        for mfile in ${all_mkp_files[@]}; do
            echo "Running metadata ingestion for : $mfile"
            mfile_name=$(basename "$mfile" | sed 's/\.[^.]*$//')
            country_code=$(echo "$mfile_name" | cut -d'_' -f3)
            echo "Country detected : $country_code"
            spark-submit $SCHEDULER "${TTDGEO_SCRIPT_DIR}/teug00_generate_metadata.py" --in_local_path $mfile -m $RUNDATE -c $country_code -et $MAILLIST            
            # move if the above command runs fine
            if [ $? -eq 0 ]; then
                move_file locals $mfile_name $MKP_SEG_FILE_DIR $DATA_FROM_STS_BACKUP
                hdfs dfs -mkdir -p $TTDGEO_MKT_HDFS_DIR/$RUNDATE && echo "created HDFS directory: $TTDGEO_MKT_HDFS_DIR/$RUNDATE"
                hdfs dfs -copyFromLocal ${TTDGEO_TEMP_LOCAL_PATH}/Update*.csv $TTDGEO_MKT_HDFS_DIR/$RUNDATE && echo "copied file to HDFS: $TTDGEO_MKT_HDFS_DIR/$RUNDATE/Update*.csv"
                move_file locals "Update" $TTDGEO_TEMP_LOCAL_PATH $TTDGEO_STS_LOCAL_PATH
                set_permissions $TTDGEO_STS_LOCAL_PATH
                move_file locals $mfile_name $MKP_SEG_FILE_DIR $DATA_FROM_STS_BACKUP
                echo "Completed TTDGEO metadata generation process"
            else
                echo "Metadata process failed for $mfile, will not move the file to data path"
            fi
        done
    else
        echo "File not found in $MKP_SEG_FILE_DIR, TTD EU GEO Metadata process can't be triggered on $RUNDATE at $CURRENT_HOUR"
    fi
}


trigger_ttdgeo_data_generation() {
    if is_file_ingestible $TTDGEO_DATA_LOCAL_PATH "ttd_marketplacefile"
    then
        echo "Triggering TTD EU GEO Data Process"
        all_data_files=$(ls $TTDGEO_DATA_LOCAL_PATH/ttd_marketplacefile_*csv)
        for dfile in ${all_data_files[@]}; do
            echo "Running data ingestion for : $dfile"
            file_name=$(basename $dfile)
            hdfs dfs -mkdir -p $TTDGEO_MKT_HDFS_DIR/$RUNDATE && echo "created HDFS directory: $TTDGEO_DATA_HDFS_PATH/$RUNDATE"
            hdfs dfs -copyFromLocal $TTDGEO_DATA_LOCAL_PATH/$file_name $TTDGEO_MKT_HDFS_DIR/$RUNDATE && echo "copied $file_name to $TTDGEO_MKT_HDFS_DIR/$RUNDATE"
            sleep 5 #delay to allow file copying
            mkdir -p ${TTDGEO_TEMP_LOCAL_PATH}/tmp
            spark-submit $SCHEDULER "${TTDGEO_SCRIPT_DIR}/teug01_generate_data.py" -m $RUNDATE -ip $TTDGEO_MKT_HDFS_DIR/$RUNDATE/$file_name -et $MAILLIST
            # move if the above command runs fine
            if [ $? -eq 0 ]; then
                rm "${TTDGEO_TEMP_LOCAL_PATH}/tmp/Replace*" && echo "removed temp files"
                move_file locals $file_name $TTDGEO_DATA_LOCAL_PATH $DATA_FROM_STS_BACKUP
                move_file locals "Replace" $TTDGEO_TEMP_LOCAL_PATH $TTDGEO_STS_LOCAL_PATH
                set_permissions $TTDGEO_STS_LOCAL_PATH
                echo "Completed TTD EU GEO Data Process"
            else
                echo "Data process failed for $dfile, will not move the file to data path"
            fi
        done
    else        
        echo "File cannot be ingested from $TTDGEO_DATA_LOCAL_PATH, TTD EU GEO Data process can't be triggered on $RUNDATE at $CURRENT_HOUR"
    fi
}


trigger_ttdgeo_process() {
    echo "Triggering TTD EU GEO process"
    trigger_ttdgeo_metadata_generation
    trigger_ttdgeo_data_generation
    echo "TTD EU GEO process completed"
}


run_ttdgeo_trigger(){
    if can_mkp_process_run $TTDGEO_LOCK_FILE 
    then
        touch $TTDGEO_LOCK_FILE && echo "created ttdgeo mkp lock file"
        trigger_ttdgeo_process
        if [ $? -ne 0 ]; then
            echo "Alert: TTDGEO process failed with exit status 1, please check logs at ${LOGS_DIR}/mkp-${RUNDATE}.log"
            return 1
        fi
        rm $TTDGEO_LOCK_FILE && echo "removed ttdgeo mkp lock file"
    else
        echo "TTDGEO process is already running on $RUNDATE"
    fi
}
