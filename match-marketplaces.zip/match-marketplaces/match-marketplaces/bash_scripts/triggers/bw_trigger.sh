#!/bin/bash

dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
source $dir/../conf.sh
source $dir/../functions.sh

CURRENT_HOUR=$(date +%H)
BW_LOCK_FILE="${MKP_LOCK_FILE_DIR}/bw_${RUNDATE}.lock"


trigger_beeswax_metadata_generation(){
    if is_file_ingestible $MKP_SEG_FILE_DIR "bw_marketplacefile"
    then
        echo "Triggering Beeswax metadata generation process"
        mkdir -p $BW_LOCAL_TMP_DIR && echo "created local directory: $BW_LOCAL_TMP_DIR"
        spark-submit $SCHEDULER "${BW_SCRIPT_DIR}/bw00_generate_metadata.py" -m $RUNDATE -of $BW_LOCAL_TMP_DIR -et $MAILLIST
        if [ $? -eq 0 ]; then
            hdfs dfs -mkdir -p $BW_HDFS_DIR/$RUNDATE && echo "created HDFS directory: $BW_HDFS_DIR/$RUNDATE"
            metafiles=($(ls $BW_LOCAL_TMP_DIR/*experian_taxonomy*))
            for mfile in ${metafiles[@]}; do
                file_name=$(basename "$mfile")
                hdfs dfs -copyFromLocal "${BW_LOCAL_TMP_DIR}/${file_name}" "$BW_HDFS_DIR/$RUNDATE" && echo "copied metadata files to HDFS: $BW_HDFS_DIR/$RUNDATE"
            done
            move_file locals "experian_taxonomy" $BW_LOCAL_TMP_DIR $BW_LOCAL_TAX_DIR
            set_permissions $BW_LOCAL_TAX_DIR
            move_file locals "bw_marketplacefile" $MKP_SEG_FILE_DIR $DATA_FROM_STS_BACKUP
            echo "Completed Beeswax metadata generation process"
        else
            echo "Metadata process failed, will not move the output metadata file tosfc/scannnsg sts data path"
            return 1
        fi
    else
        echo "File not found in $MKP_SEG_FILE_DIR, Beeswax metadata process can't be triggered on $RUNDATE at $CURRENT_HOUR"
    fi
}


trigger_beeswax_data_generation() {
    echo "Triggering Beeswax data generation process"
    hdfs dfs -mkdir -p $BW_HDFS_DIR/$RUNDATE && echo "created HDFS directory: $BW_HDFS_DIR/$RUNDATE"
    spark-submit $SCHEDULER "${BW_SCRIPT_DIR}/bw01_generate_data.py" -m $RUNDATE -md $BW_HDFS_DIR -of $BW_HDFS_DIR -et $MAILLIST
    if [ $? -eq 0 ]; then
        all_data_files=$(hdfs dfs -ls "${BW_HDFS_DIR}/${RUNDATE}/*_exp_*.csv" | awk '{print $8}')
        for dfile in $all_data_files; do
            hdfs dfs -copyToLocal $dfile "$BW_LOCAL_TMP_DIR" && echo "copied $dfile data files to local: $BW_LOCAL_TMP_DIR"
            file_name=$(basename "$dfile")
            move_file locals "_exp_" "$BW_LOCAL_TMP_DIR" $BW_LOCAL_SEG_DIR && echo "moved contents $file_name to $BW_LOCAL_SEG_DIR"
        done
        #move_file locals "exp_" $BW_LOCAL_TMP_DIR $BW_LOCAL_SEG_DIR
        set_permissions $BW_LOCAL_SEG_DIR
        hdfs dfs -touchz $BW_HDFS_DIR/bw_flag_${RUNDATE} && echo "created flag file in HDFS: $BW_HDFS_DIR/bw_flag_${RUNDATE}"
        echo "Completed Beeswax data generation process"
    else
        echo "Beeswax Data generation process failed, will not move the file to sts data path"
    fi
}


trigger_beeswax_process() {
    echo "Triggering Beeswax process"

    trigger_beeswax_metadata_generation
    if [ $? -ne 0 ]; then
        echo "Alert: Beeswax metadata process failed with exit status 1, please check logs at ${LOGS_DIR}/mkp-${RUNDATE}.log"
        return 1
    fi

    ## check if metadata files are sent and received to/from client
    mkdir -p $BW_LOCAL_TMP_DIR && echo "created local directory: $BW_LOCAL_TMP_DIR"

    if hdfs dfs -test -e $BW_HDFS_DIR/$RUNDATE; then
        sent_metafiles=($(hdfs dfs -ls $BW_HDFS_DIR/$RUNDATE | grep experian_taxonomy | awk '{print $8}'))
    else
        sent_metafiles=()
    fi
    if [ -d "$BW_LOCAL_RESP_DIR" ]; then
        received_metafiles=($(ls $BW_LOCAL_RESP_DIR/*experian_taxonomy*))
    else
        received_metafiles=()
    fi

    ## check if sent_metafiles count is same as received metafiles
    if  [ ${#sent_metafiles[@]} -ne 0 ] && [ ${#received_metafiles[@]} -ne 0 ] && [ ${#sent_metafiles[@]} -eq ${#received_metafiles[@]} ]
    then
        data_flag=0
        echo "Metadata files count match, Beeswax data process can be triggered on $RUNDATE at $CURRENT_HOUR"
    elif [ ${#sent_metafiles[@]} -eq 0 ]
    then
        data_flag=0
        echo "No metadata files sent to client, other conditions can be checked"
    else
        echo "Metadata files count mismatch, Beeswax data process can't be triggered on $RUNDATE at $CURRENT_HOUR"
        for metafile in "${sent_metafiles[@]}"; do
            if [[ ! -f "${BW_LOCAL_RESP_DIR}/$(basename ${sent_metafiles})" ]]; then
                echo "Missing file: ${BW_LOCAL_RESP_DIR}/$(basename ${sent_metafiles})"
            fi
        done
        data_flag=1
    fi

    ## check if flag file exists in hdfs path
    rundate_ts=$(date -d "$RUNDATE" +%s)
    if hdfs dfs -ls "$BW_HDFS_DIR" | grep -q "bw_flag"
    then
        echo "Flag file found in HDFS directory: $BW_HDFS_DIR"
        flag_date=$(hdfs dfs -ls $BW_HDFS_DIR | grep bw_flag | awk -F'_' '{print $3}')
        flag_date_ts=$(date -d "$flag_date" +%s)
    else
        echo "Flag file not found in HDFS directory: $BW_HDFS_DIR"
        if [ $data_flag -eq 0 ]
        then
            flag_date_ts=0
            echo "Metafiles exist but flag file doesn't, we can run for first time"
        else
            flag_date_ts=$rundate_ts
            echo "No metadata files found in local directory and no flag file, no need to run data process"
        fi
    fi

    ## check if the date in the flag filename present in the hdfs directory is more than 14 days from today and data_flag is 0
    time_diff=$(( ($rundate_ts - $flag_date_ts) / 86400 ))
    if [ $time_diff -ge 14 ] && [ $data_flag -eq 0 ]
    then
        trigger_beeswax_data_generation
        if [ $? -eq 0 ]; then
            hdfs dfs -rm "$BW_HDFS_DIR/bw_flag_${flag_date}" && echo "removed previous flag file in HDFS: $BW_HDFS_DIR/bw_flag_${flag_date}"
            move_file locals "experian_taxonomy" $BW_LOCAL_RESP_DIR $DATA_FROM_STS_BACKUP
            echo "Beeswax process completed"
        fi

    else
        echo "Data process can't be triggered on $RUNDATE at $CURRENT_HOUR as previous file is less than 14 days old"
    fi
}


run_beeswax_trigger(){
    if can_mkp_process_run $BW_LOCK_FILE
    then
        touch $BW_LOCK_FILE && echo "created beeswax mkp lock file"
        trigger_beeswax_process
        if [ $? -ne 0 ]; then
            echo "Alert: Beeswax process failed with exit status 1, please check logs at ${LOGS_DIR}/mkp-${RUNDATE}.log"
            return 1
        fi
        rm $BW_LOCK_FILE && echo "removed beeswax mkp lock file"
    else
        echo "Beeswax process is already running on $RUNDATE"
    fi
}