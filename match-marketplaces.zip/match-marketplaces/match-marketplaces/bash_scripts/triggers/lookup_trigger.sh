#!/bin/bash

source conf.sh
source functions.sh


CURRENT_HOUR=$(date +%H)


trigger_client_lookup_generation(){
    echo "Running Client Lookup file creation for $RUNDATE"    
    spark-submit --master yarn --queue $QUEUE2 $IDG_SCRIPTDIR/idg_lookup_p40_client_update.py --client_name $1
    latest_experian_lookup=$(find_latest_file_in_hdfs "${LOOKUP_HDFS_DIR}/experian" "match_id_lookup_experian")
    experian_file_name=$(basename "${latest_experian_lookup}")
    experian_file_date=$(echo "${experian_file_name}" | awk -F'_' '{print substr($NF, 1, 12)}')
    check_file_exists "${LOOKUP_HDFS_DIR}/${1}" "match_id_lookup_${1}_${experian_file_date}*.parquet" "$1 Lookup Data"
    check_file_exists "${LOOKUP_HDFS_DIR}/${1}" "cbk_hh_lookup_${1}_${experian_file_date}*.parquet" "$1 Lookup Data"
    echo "Completed Client Lookup creation for $RUNDATE"
}