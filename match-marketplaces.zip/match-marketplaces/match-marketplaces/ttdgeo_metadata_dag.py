"""
Airflow DAG for TTD Geo metadata ingestion with automated triggering and archiving.
This workflow processes TTD metadata files using S3 sensors, executes EMR jobs, and archives processed files.
"""

import json
import logging
import time
from datetime import datetime, timedelta

from airflow import DAG
from airflow.models.param import Param
from airflow.operators.python import PythonOperator, BranchPythonOperator, get_current_context
from airflow.operators.dummy import DummyOperator
from airflow.operators.email import EmailOperator
from airflow.models import Variable
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.sensors.s3_key_sensor import S3KeySensor

import pendulum
import re
import sys
import os
import tempfile
from pathlib import Path

# Set up paths
sys.path.append(str(Path(__file__).resolve().parents[1]))
sys.path.append(str(Path(__file__).resolve().parents[1]) + "/shared")

# Standard logging configuration
logging.getLogger(__name__).setLevel(logging.INFO)

# Import shared functions
import shared.functions
import shared.utils
import shared.utils.utils
import shared.bucket_list

logging.info(f"sys.path {sys.path}")

from shared.functions import platform, get_env, parse_s3_path

logging.info(f"Platform is {platform}")

# Import EMR application factory utilities
from shared.utils.emr_application_factory import create_emr_application, delete_emr_application, start_emr_job
import boto3

# Define DAG with parameters
with DAG(
    "ttdgeo_metadata_processing",
    description="Process TTD Geo metadata ingestion with automatic triggering and archiving",
    catchup=False,
    start_date=pendulum.datetime(2023, 1, 1, tz="UTC"),
    schedule_interval=None,  # Sensor-driven, no schedule
    tags=["ttdgeo", "metadata", "ingestion", "sensor"],
    default_args={
        'owner': 'airflow',
        'depends_on_past': False,
        'email_on_failure': True,
        'email_on_retry': False,
        'retries': 1,
        'retry_delay': timedelta(minutes=5),
    },
    params={
        "mask": Param(
            default=datetime.now().strftime("%Y-%m-%d"),
            type="string",
            format="date",
            description="Date on which process is run in format YYYY-MM-DD",
        ),
    },
) as dag:

    def create_script_arguments(**context):
        """
        Prepare all required paths and configuration for the metadata workflow.
        This includes S3 bucket names, workflow timing, and EMR job arguments.
        """
        from shared.bucket_list import get_bucket_name
        from shared.functions import get_env, parse_s3_path, file_exists
        
        logging.info("Creating script arguments for metadata processing")
        
        # Initialize workflow timing
        workflow_start_time = time.time()
        logging.info("Workflow started %s", datetime.fromtimestamp(workflow_start_time))
        
        # Get environment
        env = get_env()
        
        # Store workflow timing info
        context["task_instance"].xcom_push(key="workflow_start_time", value=workflow_start_time)
        context["task_instance"].xcom_push(key="env", value=env)
        
        # Use execution date directly
        execution_date = context["execution_date"]
        mask = context["params"]["mask"]
        
        # Calculate date formats for file paths
        date_str = execution_date.strftime("%Y-%m-%d")
        now_str = datetime.now().strftime("%Y%m%d%H%M%S")
        
        # Store dates
        context["task_instance"].xcom_push(key="execution_date", value=date_str)
        context["task_instance"].xcom_push(key="mask", value=mask)
        context["task_instance"].xcom_push(key="stats_timestamp", value=now_str)
        
        # Define protocol
        PROTOCOL = "s3a"
        
        # Get bucket names
        source_bucket = get_bucket_name("client_delivery")
        interim_bucket = get_bucket_name("interim") 
        output_bucket = get_bucket_name("output")
        temp_bucket = get_bucket_name("temp")
        code_bucket = get_bucket_name("code")
        log_bucket = get_bucket_name("logs")
        stats_bucket = get_bucket_name("stats")
        
        # Store bucket names
        context["task_instance"].xcom_push(key="source_bucket", value=source_bucket)
        context["task_instance"].xcom_push(key="interim_bucket", value=interim_bucket)
        context["task_instance"].xcom_push(key="output_bucket", value=output_bucket)
        context["task_instance"].xcom_push(key="temp_bucket", value=temp_bucket)
        context["task_instance"].xcom_push(key="code_bucket", value=code_bucket)
        context["task_instance"].xcom_push(key="log_bucket", value=log_bucket)
        context["task_instance"].xcom_push(key="stats_bucket", value=stats_bucket)
        
        # Push EMR common configuration
        execution_role_arn = shared.utils.utils.get_emr_serverless_role(env)
        log_uri_prefix = f"s3://{log_bucket}/spark-logs"
        shared_code = [
            f"s3://{code_bucket}/zipped/ems-code-shared.zip,s3://{code_bucket}/zipped/openpyxl.zip,s3://{code_bucket}/zipped/fsspec.zip,s3://{code_bucket}/zipped/s3fs.zip"
        ]
        ttdgeo_code_prefix = f"s3://{code_bucket}/repos/ems-code-marketplaces-tradedesk-geo"
        
        # Push common args
        context["task_instance"].xcom_push(key="EXECUTION_ROLE_ARN", value=execution_role_arn)
        context["task_instance"].xcom_push(key="LOG_URI_PREFIX", value=log_uri_prefix)
        context["task_instance"].xcom_push(key="SHARED_CODE", value=shared_code)
        context["task_instance"].xcom_push(key="TTDGEO_CODE_PREFIX", value=ttdgeo_code_prefix)
        
        return True

    def find_latest_metadata_file(**context):
        """
        Locate all metadata files in the source bucket for processing.
        """
        import shared.functions as sf
        from shared.bucket_list import get_bucket_name
        
        # Get bucket name
        source_bucket = context["task_instance"].xcom_pull(key="source_bucket", task_ids="create_script_arguments")
        
        # Find metadata files
        metadata_files = sf.list_files(
            source_bucket,
            prefix="taxonomy/",
            pattern="ttdeu_marketplacefile",
            ends_with=".xlsx",
            is_pattern_parent_directory_name=False,
        )
        
        if not metadata_files:
            logging.warning("No metadata files found")
            context["task_instance"].xcom_push(key="metadata_files", value=[])
            return "No metadata files found"
        
        # Process all files found (no sorting, take all files)
        full_paths = []
        for file_key in metadata_files:
            if file_key.startswith('s3://'):
                full_path = file_key
            else:
                full_path = f"s3://{source_bucket}/{file_key}"
            full_paths.append(full_path)
        
        logging.info(f"Found {len(full_paths)} metadata files to process: {full_paths}")
        context["task_instance"].xcom_push(key="metadata_files", value=full_paths)
        
        return f"Found {len(full_paths)} files to process"

    def check_input_exists(**context):
        """
        Verify existence of input files prior to processing.
        """
        metadata_files = context["task_instance"].xcom_pull(key="metadata_files", task_ids="find_latest_metadata_file")
        
        if metadata_files and len(metadata_files) > 0:
            logging.info(f"Found {len(metadata_files)} input files to process")
            return "process_metadata_files"
        else:
            logging.warning("No input files found")
            return "input_missing"
        
    def send_metadata_email(**context):
        """
        Send email notifications for metadata processing results.
        This task runs regardless of EMR job success or failure.
        """
        import shared.functions as sf
        from airflow.operators.email import EmailOperator
        
        # Get all processed files info
        processed_files = context["task_instance"].xcom_pull(key="processed_files", task_ids="process_metadata_files")
        temp_bucket = context["task_instance"].xcom_pull(key="temp_bucket", task_ids="create_script_arguments")
        mask = context["task_instance"].xcom_pull(key="mask", task_ids="create_script_arguments")
        
        if not processed_files:
            logging.warning("No processed files found for email notification")
            return "No files to send email for"
        
        s3 = sf.get_s3_client()
        
        # Send email for each processed file
        for file_info in processed_files:
            country = file_info.get('country', 'UNKNOWN')
            
            try:
                # Email data path
                email_data_key = f"marketplaces/ttdgeo/metadata/{country}/{mask}"
                
                # Get email content from S3
                subject = s3.get_object(
                    Bucket=temp_bucket,
                    Key=f"{email_data_key}/subject.txt"
                )["Body"].read().decode('utf-8')
                
                html_content = s3.get_object(
                    Bucket=temp_bucket,
                    Key=f"{email_data_key}/body.txt"
                )["Body"].read().decode('utf-8')
                
                # Send email
                email_op = EmailOperator(
                    task_id=f"send_ttdgeo_metadata_email_{country}",
                    to=['kallusrujan.reddy@experian.com'],
                    subject=subject,
                    html_content=html_content,
                    dag=dag
                )
                
                email_op.execute(get_current_context())
                logging.info(f"Sent metadata email for {country}: {subject}")
                
            except Exception as e:
                logging.error(f"Failed to send metadata email for {country}: {e}")
                # Continue with other files even if one email fails
                continue
    
        return f"Sent emails for {len(processed_files)} processed files"

    def initialise(**context):
        """
        Initialize the EMR Serverless application for metadata processing.
        """
        logging.info("Initializing EMR Serverless application")
        
        # Create application name with timestamp
        date = datetime.now().strftime("%Y%m%d%H%M%S")
        emr_application_name = f"ttdgeo-metadata-processing-{date}"
        
        logging.info(f"Creating EMR application with name {emr_application_name}")
        
        # Create EMR application
        app_id = create_emr_application(
            context, emr_application_name, None, None
        )
        
        # Store in XCom
        context["task_instance"].xcom_push(key="application_id", value=app_id)
        context["task_instance"].xcom_push(key="emr_application_name", value=emr_application_name)
        context["task_instance"].xcom_push(key="emr_start_time", value=time.time())
        
        logging.info(f"Created EMR application {app_id}")
        
        return "Executed initialise..."

    def process_metadata_files(**context):
        """
        Execute EMR jobs to process all metadata files found in the source bucket.
        Collects processed file information for downstream tasks.
        """
        from shared.utils.emr_application_factory import start_emr_job
        import shared.functions as sf
        from shared.bucket_list import get_bucket_name
        
        # Get all metadata files
        metadata_files = context["task_instance"].xcom_pull(key="metadata_files", task_ids="find_latest_metadata_file")
        
        if not metadata_files or len(metadata_files) == 0:
            logging.error("No metadata files to process")
            return "No files to process"
        
        logging.info(f"Processing {len(metadata_files)} metadata files")
        
        # Get EMR configuration
        app_id = context["task_instance"].xcom_pull(key="application_id", task_ids="initialise")
        mask = context["task_instance"].xcom_pull(key="mask", task_ids="create_script_arguments")
        output_bucket = context["task_instance"].xcom_pull(key="output_bucket", task_ids="create_script_arguments")
        temp_bucket = context["task_instance"].xcom_pull(key="temp_bucket", task_ids="create_script_arguments")
        
        EXECUTION_ROLE_ARN = context["task_instance"].xcom_pull(key="EXECUTION_ROLE_ARN", task_ids="create_script_arguments")
        LOG_URI_PREFIX = context["task_instance"].xcom_pull(key="LOG_URI_PREFIX", task_ids="create_script_arguments")
        SHARED_CODE = context["task_instance"].xcom_pull(key="SHARED_CODE", task_ids="create_script_arguments")
        TTDGEO_CODE_PREFIX = context["task_instance"].xcom_pull(key="TTDGEO_CODE_PREFIX", task_ids="create_script_arguments")
        
        execution_date = context["task_instance"].xcom_pull(key="execution_date", task_ids="create_script_arguments")
        
        processed_files = []
        
        # Process each metadata file
        for metadata_file in metadata_files:
            logging.info(f"Processing metadata file: {metadata_file}")
            
            # Extract country from filename
            filename = metadata_file.split('/')[-1]
            filename_parts = filename.split('_')
            if len(filename_parts) >= 3:
                country = filename_parts[2].upper()
            else:
                country = "wrong"
            
            logging.info(f"Country detected: {country}")
            
            # Email data path
            email_data_key = f"marketplaces/ttdgeo/metadata/{country}/{datetime.now().strftime('%Y-%m-%d')}"
            
            # Define output file path
            output_file_path = f"s3://{output_bucket}/marketplaces/ttdgeo/metadata/{mask}/Update.TTDGEO.Taxonomy.{country}.{datetime.now().strftime('%Y%m%d%H%M%S')}.csv"
            
            # Job arguments
            job_args = [
                "--input_path", metadata_file,
                "--output_path", output_file_path,
                "--execution_date", execution_date,
                "--country_code", country,
                "--email_data_bucket", temp_bucket,
                "--email_data_key", email_data_key
            ]
                
            main = f"{TTDGEO_CODE_PREFIX}/spark/ttdgeo_metadata_emr.py"
            
            # Add to processed files list BEFORE running EMR job
            # This ensures email can be sent even if EMR fails
            processed_files.append({
                'source_file': metadata_file,
                'output_file': output_file_path,
                'country': country,
                'processed_time': datetime.now().isoformat()
            })
            
            try:
                job = start_emr_job(
                    task_id="process_metadata",
                    application_id=app_id,
                    execution_role_arn=EXECUTION_ROLE_ARN,
                    job_driver={
                        "sparkSubmit": {
                            "entryPoint": main,
                            "entryPointArguments": job_args,
                            "sparkSubmitParameters": f"--conf spark.submit.pyFiles={','.join(SHARED_CODE) if isinstance(SHARED_CODE, list) else SHARED_CODE}",
                        },
                    },
                    configuration_overrides={
                        "monitoringConfiguration": {
                            "s3MonitoringConfiguration": {
                                "logUri": f"{LOG_URI_PREFIX}/ttdgeo_metadata_{country}",
                            },
                        }
                    },
                )
                
                job_id = job.execute(get_current_context())
                logging.info(f"Executed metadata processing for {country}: {job_id}")
                
            except Exception as e:
                logging.error(f"EMR job failed for {country}: {e}")
                # Don't re-raise - let the email task handle notification
                # The processed_files list already contains this file info for email
                continue
        
        # Store all processed files info for email task
        context["task_instance"].xcom_push(key="processed_files", value=processed_files)
        
        return f"Processed {len(metadata_files)} metadata files"

    def archive_processed_files(**context):
        """
        Archive both input and output metadata files to the designated archive bucket.
        """
        import shared.functions as sf
        from shared.bucket_list import get_bucket_name
        from shared.functions import parse_s3_path
        
        processed_files = context["task_instance"].xcom_pull(key="processed_files", task_ids="process_metadata_files")
        
        if not processed_files:
            logging.info("No files to archive")
            return "No files to archive"
        
        # Get archive bucket name (using same pattern as other buckets)
        env = context["task_instance"].xcom_pull(key="env", task_ids="create_script_arguments")
        archive_bucket = f"eec-aws-uk-ms-consumersync-{env}-archive-bucket"
        
        # Get execution date for folder structure
        mask = context["task_instance"].xcom_pull(key="mask", task_ids="create_script_arguments")
        
        s3_client = sf.get_s3_client()
        archived_count = 0
        logging.info(f"we have {processed_files} here ")
        logging.info(f"Archiving {len(processed_files)} processed files to {archive_bucket}")
        
        for file_info in processed_files:
            source_file = file_info['source_file']
            output_file = file_info.get('output_file')
            logging.info(f"we have {output_file} here ")

            
            # Archive input file
            try:
                # Parse source S3 path
                source_bucket, source_key = parse_s3_path(source_file)
                
                # Get original filename without any modifications
                filename = source_key.split('/')[-1]
                
                # Create archive path: marketplaces/ttdgeo/{date}/metadata/input/{filename}
                archive_key = f"marketplaces/ttdgeo/{mask}/metadata/input/{filename}"
                
                logging.info(f"Archiving input file {source_file} to s3://{archive_bucket}/{archive_key}")
                
                # Copy file to archive bucket
                copy_source = {'Bucket': source_bucket, 'Key': source_key}
                s3_client.copy_object(
                    CopySource=copy_source,
                    Bucket=archive_bucket,
                    Key=archive_key
                )
                
                # Delete original file after successful copy
                s3_client.delete_object(Bucket=source_bucket, Key=source_key)
                
                archived_count += 1
                logging.info(f"Successfully archived input file {filename}")
                
            except Exception as e:
                logging.error(f"Failed to archive input file {source_file}: {str(e)}")
                # Continue with other files even if one fails
                continue
            
            # Archive output file
            if output_file:
                try:
                    # Parse output S3 path
                    output_bucket, output_key = parse_s3_path(output_file)
                    
                    # Get original output filename without any modifications
                    output_filename = output_key.split('/')[-1]
                    
                    # Create archive path: marketplaces/ttdgeo/{date}/metadata/output/{filename}
                    output_archive_key = f"marketplaces/ttdgeo/{mask}/metadata/output/{output_filename}"
                    
                    logging.info(f"Archiving output file {output_file} to s3://{archive_bucket}/{output_archive_key}")
                    
                    # Copy output file to archive bucket
                    copy_source = {'Bucket': output_bucket, 'Key': output_key}
                    s3_client.copy_object(
                        CopySource=copy_source,
                        Bucket=archive_bucket,
                        Key=output_archive_key
                    )
                    
                    archived_count += 1
                    logging.info(f"Successfully archived output file {output_filename}")
                    
                except Exception as e:
                    logging.error(f"Failed to archive output file {output_file}: {str(e)}")
                    # Continue with other files even if one fails
                    continue
        
        return f"Archived {archived_count} files (input and output)"

    def finalise(**context):
        """
        Finalize workflow by deleting the EMR Serverless application and logging completion.
        """
        from shared.utils.emr_application_factory import delete_emr_application
        
        logging.info("Finalizing EMR application")
        
        app_id = context["task_instance"].xcom_pull(key="application_id", task_ids="initialise")
        emr_application_name = context["task_instance"].xcom_pull(key="emr_application_name", task_ids="initialise")
        workflow_start_time = context["task_instance"].xcom_pull(key="workflow_start_time", task_ids="create_script_arguments")
        
        logging.info(f"Finalization started, deleting application {app_id}")
        
        # Delete EMR application
        delete_emr_application(context, emr_application_name, app_id)
        
        end_time = time.time()
        logging.info(f"Workflow finished, time taken: {timedelta(seconds=end_time - workflow_start_time)}")
        
        return "Finalized EMR application"

    # Define tasks
    start = DummyOperator(task_id="start")
    
    task_create_arguments = PythonOperator(
        task_id="create_script_arguments",
        python_callable=create_script_arguments,
        trigger_rule="none_failed",
        dag=dag,
    )
    
    # S3 Sensor to detect new metadata files
    metadata_sensor = S3KeySensor(
        task_id="wait_for_metadata_file",
        bucket_name="{{ ti.xcom_pull(task_ids='create_script_arguments', key='source_bucket') or 'eec-aws-uk-ms-consumersync-dev-client-delivery-bucket' }}",
        bucket_key="taxonomy/ttdeu_marketplacefile*.xlsx",
        wildcard_match=True,
        timeout=60 * 60 * 24,  # 24 hours timeout
        poke_interval=1,  # Check every 1 second
        dag=dag,
    )
    
    task_find_latest_metadata_file = PythonOperator(
        task_id="find_latest_metadata_file",
        python_callable=find_latest_metadata_file,
        dag=dag,
    )
    
    task_initialise = PythonOperator(
        task_id="initialise",
        python_callable=initialise,
        trigger_rule="one_success",
        dag=dag,
    )
    
    check_input = BranchPythonOperator(
        task_id="check_input",
        python_callable=check_input_exists,
        dag=dag,
    )
    
    input_missing = DummyOperator(task_id="input_missing", dag=dag)
    
    task_process_metadata_files = PythonOperator(
        task_id="process_metadata_files",
        python_callable=process_metadata_files,
        trigger_rule="none_failed",
        dag=dag,
    )
    
    task_archive_files = PythonOperator(
        task_id="archive_processed_files",
        python_callable=archive_processed_files,
        trigger_rule="none_failed",
        dag=dag,
    )
    
    task_finalise = PythonOperator(
        task_id="finalise",
        python_callable=finalise,
        trigger_rule="none_failed_min_one_success",
        dag=dag,
    )

    task_send_emails = PythonOperator(
    task_id="send_metadata_emails",
    python_callable=send_metadata_email,
    trigger_rule="none_failed_min_one_success",  # Runs even if EMR fails
    dag=dag,
    )
    
    # Task dependencies - Sensor-driven workflow with archiving
    start >> task_create_arguments >> metadata_sensor >> task_find_latest_metadata_file >> task_initialise >> check_input
    check_input >> task_process_metadata_files >> task_send_emails >> task_archive_files >> task_finalise

    check_input >> input_missing >> task_finalise
