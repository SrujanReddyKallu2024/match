# python helper_scripts\convert_ttd_geo_tax_desc.py --EXCEL_PATH="metadata/standard(syndicated)_taxonomy_skeleton - Experian_Worldview_DK_Jan25_v2.xlsx" --TAX_OUTPUT="ttd_marketplacefile_DK"

import pandas as pd
from datetime import datetime
import argparse
import sys

today_date = datetime.now().strftime("%Y%m%d")

parser = argparse.ArgumentParser(description='Convert TTD Geo Taxonomy Description')
parser.add_argument('--EXCEL_PATH', type=str, required=True, help='Path to the input Excel file')
parser.add_argument('--TAX_OUTPUT', type=str, required=True, help='Path and partial filename to the output CSV file')

print(parser)
print(sys.argv)

# add this line in shell to create args to test
# args, unknown = parser.parse_known_args(['--TAX_OUTPUT', 'ttd_marketplacefile_DK', '--EXCEL_PATH','metadata/standard(syndicated)_taxonomy_skeleton - Experian_Worldview_DK_Jan25_v2.xlsx'])
args = parser.parse_args()

# load the xlsx file from client delivery team
df = pd.read_excel(args.EXCEL_PATH, sheet_name="Experian Taxonomy", skiprows=1)

# print(df)

# columns renaming for finale output
df1 = df[["SEGMENT ID","SEGMENT DESCRIPTION"]].rename({
    "SEGMENT ID":"S_Code",
    "SEGMENT DESCRIPTION":"Segment_Description"
},axis=1)

# print(df1)

# only use the DK audience segments
df2 = df1[df1.S_Code.str.startswith("DK")].copy()

# add numeric audience column for sorting
df2['num'] = df2.S_Code.str.replace("DK","").astype("int")
df2.sort_values("num",inplace=True)
df2.drop(columns=["num"],inplace=True)

# print(df1)

# output to csv, using the partial path and name from args.TAX_OUTPUT add the date and extension
df2.to_csv(f"{args.TAX_OUTPUT}_{today_date}.csv", index=False)

