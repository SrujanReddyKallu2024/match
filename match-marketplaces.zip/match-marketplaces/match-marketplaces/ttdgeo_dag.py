"""
DAG to process TTD Geo metadata ingestion only.
Processes metadata files for TTD.
"""

import json
import logging
import time
from datetime import datetime, timedelta

from airflow import DAG
from airflow.models.param import Param
from airflow.operators.python import PythonOperator, BranchPythonOperator, get_current_context
from airflow.operators.dummy import DummyOperator
from airflow.operators.email import EmailOperator
from airflow.models import Variable
from airflow.operators.trigger_dagrun import TriggerDagRunOperator

import pendulum
import re
import sys
import os
import tempfile
from pathlib import Path

# Set up paths
sys.path.append(str(Path(__file__).resolve().parents[1]))
sys.path.append(str(Path(__file__).resolve().parents[1]) + "/shared")

# Standard logging configuration
logging.getLogger(__name__).setLevel(logging.INFO)

# Import shared functions
import shared.functions
import shared.utils
import shared.utils.utils
import shared.bucket_list

logging.info(f"sys.path {sys.path}")

from shared.functions import platform, get_env, parse_s3_path

logging.info(f"Platform is {platform}")

# Import EMR application factory utilities
from shared.utils.emr_application_factory import create_emr_application, delete_emr_application, start_emr_job
import boto3

# Define DAG with parameters
with DAG(
    "ttdgeo_metadata_processing",
    description="Process TTD Geo metadata ingestion only",
    catchup=False,
    start_date=pendulum.datetime(2023, 1, 1, tz="UTC"),
    schedule_interval="0 10 * * *",  # Daily at 10 AM
    tags=["ttdgeo", "metadata", "ingestion"],
    default_args={
        'owner': 'airflow',
        'depends_on_past': False,
        'email_on_failure': True,
        'email_on_retry': False,
        'retries': 1,
        'retry_delay': timedelta(minutes=5),
    },
    params={
        "mask": Param(
            default=datetime.now().strftime("%Y-%m-%d"),
            type="string",
            format="date",
            description="Date on which process is run in format YYYY-MM-DD",
        ),
    },
) as dag:

    def check_for_new_ttdgeo_metadata_files(**context):
        """
        Check for new TTD Geo metadata files only
        """
        from shared.bucket_list import get_bucket_name
        import shared.functions as sf

        bucket_name = get_bucket_name("client_delivery")
        path = "taxonomy/"

        # Only search directly in taxonomy/ (no subfolders), match ttdeu_marketplacefile*.xlsx
        try:
            # List all objects directly under taxonomy/ with pattern and ends_with
            metadata_files = sf.list_files(
                bucket_name,
                prefix=path,
                pattern="ttdeu_marketplacefile",
                ends_with=".xlsx",
                is_pattern_parent_directory_name=False,
            )
            # Filter out any files that are in subfolders (only direct children)
            logging.info(f"Found {len(metadata_files)} metadata files directly in {path}: {metadata_files}")
        except Exception as e:
            logging.warning(f"No metadata files found: {e}")
            metadata_files = []

        # Store files in XCom
        context["ti"].xcom_push(key="metadata_files", value=metadata_files)

        has_files = len(metadata_files) > 0
        logging.info(f"Found metadata files to process: {has_files}")
        return has_files

    def create_script_arguments(**context):
        """
        Calculate all paths and configuration needed for the metadata workflow
        """
        from shared.bucket_list import get_bucket_name
        from shared.functions import get_env, parse_s3_path, file_exists
        
        logging.info("Creating script arguments for metadata processing")
        
        # Initialize workflow timing
        workflow_start_time = time.time()
        logging.info("Workflow started %s", datetime.fromtimestamp(workflow_start_time))
        
        # Get environment
        env = get_env()
        
        # Store workflow timing info
        context["task_instance"].xcom_push(key="workflow_start_time", value=workflow_start_time)
        context["task_instance"].xcom_push(key="env", value=env)
        
        # Use execution date directly
        execution_date = context["execution_date"]
        mask = context["params"]["mask"]
        
        # Calculate date formats for file paths
        date_str = execution_date.strftime("%Y-%m-%d")
        now_str = datetime.now().strftime("%Y%m%d%H%M%S")
        
        # Store dates
        context["task_instance"].xcom_push(key="execution_date", value=date_str)
        context["task_instance"].xcom_push(key="mask", value=mask)
        context["task_instance"].xcom_push(key="stats_timestamp", value=now_str)
        
        # Define protocol
        PROTOCOL = "s3a"
        
        # Get bucket names
        source_bucket = get_bucket_name("client_delivery")
        interim_bucket = get_bucket_name("interim") 
        output_bucket = get_bucket_name("output")
        temp_bucket = get_bucket_name("temp")
        code_bucket = get_bucket_name("code")
        log_bucket = get_bucket_name("logs")
        stats_bucket = get_bucket_name("stats")
        
        # Store bucket names
        context["task_instance"].xcom_push(key="source_bucket", value=source_bucket)
        context["task_instance"].xcom_push(key="interim_bucket", value=interim_bucket)
        context["task_instance"].xcom_push(key="output_bucket", value=output_bucket)
        context["task_instance"].xcom_push(key="temp_bucket", value=temp_bucket)
        context["task_instance"].xcom_push(key="code_bucket", value=code_bucket)
        context["task_instance"].xcom_push(key="log_bucket", value=log_bucket)
        context["task_instance"].xcom_push(key="stats_bucket", value=stats_bucket)
        
        # Get files from previous task
        metadata_files = context["ti"].xcom_pull(key="metadata_files", task_ids="check_for_new_ttdgeo_metadata_files")
        
        # Define paths for metadata only
        ttdgeo_filepaths = {
            "metadata_input": metadata_files[0] if metadata_files else None,
            "metadata_output": f"{PROTOCOL}://{output_bucket}/marketplaces/ttdgeo/metadata/{mask}/ttdgeo_taxonomy_{{cc}}.csv",
            "metadata_formatted_stats": f"{PROTOCOL}://{stats_bucket}/ttdgeo/metadata_stats_{now_str}_formatted.txt",
        }
        
        logging.info(f"Using TTD Geo metadata filepaths {ttdgeo_filepaths}")
        
        # Store all paths
        context["task_instance"].xcom_push(key="TTDGEO_FILEPATHS", value=ttdgeo_filepaths)
        
        # Check if input files exist
        metadata_exists = False
        
        if ttdgeo_filepaths["metadata_input"]:
            try:
                bucket_name, key = parse_s3_path(ttdgeo_filepaths["metadata_input"])
                metadata_exists = file_exists(bucket_name, key, is_pattern_parent_directory_name=False)
            except Exception as e:
                logging.error(f"Error checking metadata file: {str(e)}")
        
        context["task_instance"].xcom_push(key="metadata_exists", value=metadata_exists)
        
        # Push EMR common configuration
        execution_role_arn = shared.utils.utils.get_emr_serverless_role(env)
        log_uri_prefix = f"s3://{log_bucket}/spark-logs"
        shared_code = [
            f"s3://{code_bucket}/zipped/ems-code-shared.zip,s3://{code_bucket}/zipped/openpyxl.zip,s3://{code_bucket}/zipped/fsspec.zip,s3://{code_bucket}/zipped/s3fs.zip"
        ]
        ttdgeo_code_prefix = f"s3://{code_bucket}/repos/ems-code-marketplaces-tradedesk-geo"
        
        # Push common args
        context["task_instance"].xcom_push(key="EXECUTION_ROLE_ARN", value=execution_role_arn)
        context["task_instance"].xcom_push(key="LOG_URI_PREFIX", value=log_uri_prefix)
        context["task_instance"].xcom_push(key="SHARED_CODE", value=shared_code)
        context["task_instance"].xcom_push(key="TTDGEO_CODE_PREFIX", value=ttdgeo_code_prefix)
        
        return True

    def initialise(**context):
        """
        Initialize EMR Serverless application
        """
        logging.info("Initializing EMR Serverless application")
        
        # Create application name with timestamp
        date = datetime.now().strftime("%Y%m%d%H%M%S")
        emr_application_name = f"ttdgeo-metadata-processing-{date}"
        
        logging.info(f"Creating EMR application with name {emr_application_name}")
        
        # Create EMR application
        app_id = create_emr_application(
            context, emr_application_name, None, None
        )
        
        # Store in XCom
        context["task_instance"].xcom_push(key="application_id", value=app_id)
        context["task_instance"].xcom_push(key="emr_application_name", value=emr_application_name)
        context["task_instance"].xcom_push(key="emr_start_time", value=time.time())
        
        logging.info(f"Created EMR application {app_id}")
        
        return "Executed initialise..."

    def check_input_exists(**context):
        """
        Check if the metadata input files exist in S3
        """
        metadata_files = context["ti"].xcom_pull(key="metadata_files", task_ids="check_for_new_ttdgeo_metadata_files")
        
        has_files = metadata_files and len(metadata_files) > 0
        
        if has_files:
            logging.info("Metadata input files exist, proceeding with processing")
            return "process_metadata_files"
        else:
            logging.warning("Metadata input files do not exist, skipping processing")
            return "input_missing"

    def process_metadata_files(**context):
        """
        Process TTD Geo metadata files
        """
        from shared.utils.emr_application_factory import start_emr_job
        import shared.functions as sf
        
        metadata_files = context["ti"].xcom_pull(key="metadata_files", task_ids="check_for_new_ttdgeo_metadata_files")
        
        if not metadata_files or len(metadata_files) == 0:
            logging.info("No metadata files to process.")
            return "No metadata files to process"
        
        app_id = context["task_instance"].xcom_pull(key="application_id", task_ids="initialise")
        mask = context["task_instance"].xcom_pull(key="mask", task_ids="create_script_arguments")
        output_bucket = context["task_instance"].xcom_pull(key="output_bucket", task_ids="create_script_arguments")
        temp_bucket = context["task_instance"].xcom_pull(key="temp_bucket", task_ids="create_script_arguments")
        
        EXECUTION_ROLE_ARN = context["task_instance"].xcom_pull(key="EXECUTION_ROLE_ARN", task_ids="create_script_arguments")
        LOG_URI_PREFIX = context["task_instance"].xcom_pull(key="LOG_URI_PREFIX", task_ids="create_script_arguments")
        SHARED_CODE = context["task_instance"].xcom_pull(key="SHARED_CODE", task_ids="create_script_arguments")
        TTDGEO_CODE_PREFIX = context["task_instance"].xcom_pull(key="TTDGEO_CODE_PREFIX", task_ids="create_script_arguments")
        
        execution_date = context["task_instance"].xcom_pull(key="execution_date", task_ids="create_script_arguments")
        
        # Process each metadata file
        for metadata_file in metadata_files:
            logging.info(f"Processing metadata file: {metadata_file}")
            
            # Extract country from filename
            filename = metadata_file.split('/')[-1]
            filename_parts = filename.split('_')
            if len(filename_parts) >= 3:
                country = filename_parts[2].upper()
            else:
                country = "DK"
            
            logging.info(f"Country detected: {country}")
            
            # Email data path
            email_data_key = f"marketplaces/ttdgeo/metadata/{country}/{datetime.now().strftime('%Y-%m-%d')}"
            
            # Job arguments
            job_args = [
                "--input_path", metadata_file,
                "--output_path", f"s3://{output_bucket}/marketplaces/ttdgeo/metadata/{mask}/Update.TTDGEO.Taxonomy.{country}.{datetime.now().strftime('%Y%m%d%H%M%S')}.csv",
                "--execution_date", execution_date,
                "--country_code", country,
                "--email_data_bucket", temp_bucket,
                "--email_data_key", email_data_key
            ]
                
            main = f"{TTDGEO_CODE_PREFIX}/spark/ttdgeo_metadata_emr.py"
            
            job = start_emr_job(
                task_id="process_metadata",
                application_id=app_id,
                execution_role_arn=EXECUTION_ROLE_ARN,
                job_driver={
                    "sparkSubmit": {
                        "entryPoint": main,
                        "entryPointArguments": job_args,
                        "sparkSubmitParameters": f"--conf spark.submit.pyFiles={','.join(SHARED_CODE) if isinstance(SHARED_CODE, list) else SHARED_CODE}",
                    },
                },
                configuration_overrides={
                    "monitoringConfiguration": {
                        "s3MonitoringConfiguration": {
                            "logUri": f"{LOG_URI_PREFIX}/ttdgeo_metadata_{country}",
                        },
                    }
                },
            )
            
            job_id = job.execute(get_current_context())
            logging.info(f"Executed metadata processing for {country}: {job_id}")
            
            # Send email immediately after EMR job
            try:
                s3 = sf.get_s3_client()
                
                subject = s3.get_object(
                    Bucket=temp_bucket,
                    Key=f"{email_data_key}/subject.txt"
                )["Body"].read().decode('utf-8')
                
                html_content = s3.get_object(
                    Bucket=temp_bucket,
                    Key=f"{email_data_key}/body.txt"
                )["Body"].read().decode('utf-8')
                
                email_op = EmailOperator(
                    task_id="send_ttdgeo_metadata_email_report",
                    to=['kallusrujan.reddy@experian.com'],
                    subject=subject,
                    html_content=html_content,
                    dag=dag
                )
                
                email_op.execute(get_current_context())
                logging.info(f"Sent metadata email for {country}")
                
            except Exception as e:
                logging.warning(f"Failed to send metadata email for {country}: {e}")
        
        return f"Processed {len(metadata_files)} metadata files"

    def finalise(**context):
        """
        Delete EMR Serverless application and log workflow completion
        """
        from shared.utils.emr_application_factory import delete_emr_application
        
        logging.info("Finalizing EMR application")
        
        app_id = context["task_instance"].xcom_pull(key="application_id", task_ids="initialise")
        emr_application_name = context["task_instance"].xcom_pull(key="emr_application_name", task_ids="initialise")
        workflow_start_time = context["task_instance"].xcom_pull(key="workflow_start_time", task_ids="create_script_arguments")
        
        logging.info(f"Finalization started, deleting application {app_id}")
        
        # Delete EMR application
        delete_emr_application(context, emr_application_name, app_id)
        
        end_time = time.time()
        logging.info(f"Workflow finished, time taken: {timedelta(seconds=end_time - workflow_start_time)}")
        
        return "Finalized EMR application"

    # Define tasks
    start = DummyOperator(task_id="start")
    
    task_check_for_new_ttdgeo_metadata_files = PythonOperator(
        task_id="check_for_new_ttdgeo_metadata_files",
        python_callable=check_for_new_ttdgeo_metadata_files,
        dag=dag,
    )
    
    task_create_arguments = PythonOperator(
        task_id="create_script_arguments",
        python_callable=create_script_arguments,
        trigger_rule="none_failed",
        dag=dag,
    )
    
    task_initialise = PythonOperator(
        task_id="initialise",
        python_callable=initialise,
        trigger_rule="one_success",
        dag=dag,
    )
    
    check_input = BranchPythonOperator(
        task_id="check_input",
        python_callable=check_input_exists,
        dag=dag,
    )
    
    input_missing = DummyOperator(task_id="input_missing", dag=dag)
    
    task_process_metadata_files = PythonOperator(
        task_id="process_metadata_files",
        python_callable=process_metadata_files,
        trigger_rule="none_failed",
        dag=dag,
    )
    
    task_finalise = PythonOperator(
        task_id="finalise",
        python_callable=finalise,
        trigger_rule="none_failed_min_one_success",
        dag=dag,
    )
    
    # Task dependencies - Simple metadata-only workflow
    start >> task_check_for_new_ttdgeo_metadata_files >> task_create_arguments >> task_initialise >> check_input
    check_input >> task_process_metadata_files >> task_finalise
    check_input >> input_missing >> task_finalise
