from datetime import datetime, timedelta
import logging
import logging.handlers
import os
from pathlib import Path
import argparse
import socket

HOST = socket.gethostname().lower()

def setup_parser():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--base_path_hdfs", default=None, help="Base path for hdfs data")
    parser.add_argument("--sts_from_path", default=None, help="Base path for sts input")
    parser.add_argument("--sts_to_path", default=None, help="Base path for sts output")
    parser.add_argument("-em", "--email", default=None, help="Email list")
    return parser

overide, unk = setup_parser().parse_known_args()

DEVS_EMAIL = "robin.potter@experian.com"

if  overide.email is None:
    if not "pap" in HOST:
        overide.email = DEVS_EMAIL

script_dir = str(Path(os.path.dirname(__file__)).resolve())

TODAY_DATE = datetime.now().strftime('%Y-%m-%d')
TODAY_YEAR = datetime.now().strftime("%Y")
EMAIL_TO = overide.email or "emsactivatealerts@experian.com"
LOGPATH = f"{script_dir}/logs"
BASE_PATH = overide.base_path_hdfs or "/user/unity"
IDG_PATH = f"{BASE_PATH}/id_graph"
IDG_GRAPH_PATH = f"{IDG_PATH}/graphs"
LOOKUP_FILE_PATH = f"{IDG_PATH}/lookup"
MATCH2_PATH = f"{BASE_PATH}/match2"
LOCAL_STS = overide.sts_from_path or "/data/data_from_sts"
LOCAL_TO_STS = overide.sts_to_path or "/data/data_to_sts"
MKP_SCODES_PATH_LOCAL = f'{LOCAL_STS}/marketplace_input_files'
TAX_PATH = f"{MATCH2_PATH}/taxonomy"
METADATA_PATH = f"{script_dir}/metadata"
DATA_TO_STS_TEMP = f"{LOCAL_TO_STS}/temp"
STATUS_EMOJIS = {
    'green': '\U00002705',  # ✅
    'amber': '\U000026A0',  # ⚠️
    'red': '\U0000274C'     # ❌
}

## Audigent
AUD_PATH_HDFS = f"{MATCH2_PATH}/marketplaces/audigent"
AUD_IDS = ["ip", "hems", "maids", "uid", "ttdids", "apnids"]
AUD_CUSTOM_INDIR = f"{LOCAL_STS}/internal/data"
AUD_CUSTOM_OUTDIR = f"{DATA_TO_STS_TEMP}/audigent"

## Peer39
P39_PATH_HDFS = f"{MATCH2_PATH}/marketplaces/peer39"

## TTD EU Geo
TTD_GEO_PATH_HDFS = f"{MATCH2_PATH}/marketplaces/ttd/geo"
TTD_GEO_DATE_TIME = datetime.now().strftime("%Y%m%d%H%M%S")
TTD_GEO_TEMP_LOCAL_PATH = f"{DATA_TO_STS_TEMP}/ttd/geo"

## Freewheel
FW_DEFAULT_CLIENT_ID="-1"
FW_MATCH_ID = f"{LOOKUP_FILE_PATH}/experian"
FW_TAX_FILENAME = "{clientid}__{logic}__{filename}.csv"
FW_AUDIENCE_FILENAME = "{clientid}__{logic}__{idtype}__{filename}.csv"

## Beeswax
BW_DEFAULT_CLIENT_ID="-1"
BW_MATCH_ID = f"{LOOKUP_FILE_PATH}/experian"
BW_TAX_FILENAME = "experian_taxonomy_{YYYYMMddHHmmss}.csv"
BW_FINAL_AUDIENCE_FILENAME = "{{graph_type}}__exp_{{graph_type}}_{YYYYMMddHHmmss}_{{partname}}.csv"
BW_TEMP_AUDIENCE_FILENAME = "{graph_type}__exp_{graph_type}_{YYYYMMddHHmmss}.csv"
BW_DATE_TIME = datetime.now().strftime("%Y%m%d%H%M%S")

# TTD IDS
TTD_TTDIDS_PATH_HDFS = f"{MATCH2_PATH}/marketplaces/ttd/ttdids"
TTD_TTDIDS_DATE_TIME = datetime.now().strftime("%Y%m%d%H%M%S")
TTD_TTDIDS_TEMP_LOCAL_PATH = f"{DATA_TO_STS_TEMP}/ttd/ttdids"
TTD_TTDIDS_TAXONOMY_FILENAME = f"ttdid_marketplacefile_{TTD_TTDIDS_DATE_TIME}.csv"
TTD_TTDDA_TAXONOMY_FILENAME = f"ttdda_marketplacefile_{TTD_TTDIDS_DATE_TIME}.csv"
TTD_TTDIDS_DAYS_FILTER = 30

#FWGEO
FWG_METADATA_FILENAME = "fwgeo_taxonomy_{country_code}_{YYYYMMddHHmmss}.csv"

## Infosum
INF_PATH_HDFS = f"{MATCH2_PATH}/marketplaces/infosum"
INF_LOOKUP_WINDOW = 30
INF_IDS = ["ip", "hems", "maids"]#, "postal_address"]
INF_POST_PATH = f"{IDG_PATH}/pc/postal_address"

## Snowflake
SNF_IDS = ["ip", "uid", "maids", "hems", "mobile", "pc", "ttdids", "apnids", "fpid"]
SNF_PATH_HDFS = f"{MATCH2_PATH}/marketplaces/snowflake"
SNF_LOOKUP_WINDOW = 90





## Setup logging configuration
class LogConfig(object):
    LOGLEVEL = logging.DEBUG
    FORMAT = '%(asctime)s - %(name)s - %(filename)s - %(levelname)s - %(message)s'
    LOGFILE = 'output.log'
    LOGSIZE = 10000000
    LOGLEVEL_FILE = logging.DEBUG

    # easy overwrite logfile name
    def __init__(self, altfilename='output.log'):
        self.LOGFILE = altfilename

    # generate the logging object
    def generate_logger(self, name):
        # initializing logger properties
        formatter = logging.Formatter(self.FORMAT)
        logger = logging.getLogger(name)
        logger.setLevel(logging.DEBUG)
        handler = logging.StreamHandler()
        handler.setLevel(self.LOGLEVEL)
        handler.setFormatter(formatter)
        # Add the log message handler to the logger
        file_handler = logging.handlers.RotatingFileHandler(self.LOGFILE,
                                                            maxBytes=self.LOGSIZE,
                                                            backupCount=5,
                                                            )
        file_handler.setFormatter(formatter)
        file_handler.setLevel(self.LOGLEVEL_FILE)
        logger.addHandler(file_handler)
        logger.addHandler(handler)
        return logger