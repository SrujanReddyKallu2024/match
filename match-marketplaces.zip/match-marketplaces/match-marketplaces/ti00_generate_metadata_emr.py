import pandas as pd
import sys
from pathlib import Path
import argparse
import os
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from datetime import datetime
import time
import io

sys.path.append(str(Path(__file__).resolve().parents[2])) # should be setting PYTHONPATH

import sys

print("Python executable:", sys.executable)
print("Python path:", sys.path)

import logging

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(funcName)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)

import process.config as config
import shared.functions as functions
from shared.functions import emoji


logging.info(f"running {__file__} script")

def check_weird_codes(df, column_name):
    weird_codes = df[column_name].where(df[column_name].str.contains("xa", regex=False)).dropna().to_list()
    weird_codes = [code for code in weird_codes if "\\" in code]
    logging.info(f"checking for weird codes in {column_name}")
    if len(weird_codes) > 0:
        logging.error(f"found weird codes in {column_name}: {weird_codes}")
        raise ValueError(f"found weird codes in {column_name}: {weird_codes}")


def replace_characters(df, column_name, char_replacements, trim_edges=True):
    for char, replacement in char_replacements.items():
        df[column_name] = df[column_name].str.replace(char, replacement, regex=False)
        if trim_edges: df[column_name] = df[column_name].str.strip()


def format_metadata(df, segment_prefix):
    """
    Format the marketplace file based on desired format
    """
    df1 = (
        df[["SEGMENT ID","Parent  ID","Full Path","SEGMENT DESCRIPTION","Depth","PRICING ($)","Buyable 1(YES) or 0(NO)"]].rename({
            "SEGMENT ID":"ElementId",
            "Parent  ID":"ParentId",
            "Full Path":"DisplayName",
            "SEGMENT DESCRIPTION":"Segment_Description",
            "Depth":"Depth",
            "PRICING ($)":"CPMRate",
            "Buyable 1(YES) or 0(NO)":"Buyable",
        },axis=1)
    )

    # Replace long dashes with hyphens in Segment_Name and Description    
    char_replacements = {
        "\\xa3": "£",
        "\\xa0": " "
    }

    replace_characters(df1, "DisplayName", char_replacements)
    replace_characters(df1, "Segment_Description", char_replacements)

    check_weird_codes(df1, "DisplayName")
    check_weird_codes(df1, "Segment_Description")


    df1.replace(r"N/A","",inplace=True)

    df2 = df1[df1.ElementId.str.match(f"{segment_prefix}\d+")].copy()
    df2['num'] = df2.ElementId.str.replace(segment_prefix,"").astype("int")
    df2.sort_values("num",inplace=True)
    df2['ElementId'] = segment_prefix + df2['num'].astype(str).str.zfill(7)
    df2.drop(columns=["num"],inplace=True)
    return df2


def logic_main(mask, email_data_bucket, email_data_key, output_folder, marketplace_taxonomy, taxonomy_filter, segment_prefix, skiprows):

    # import functions after logger is created
    # import functions
    logging.info(f"running {__file__} script for mask: {mask}")
    quick_stats = []

    s3 = functions.get_s3_client()


    try:
        startime = datetime.now()

        try:
            logging.info(f"reading marketplace file: {marketplace_taxonomy}")
            
            bucket = marketplace_taxonomy.split("/")[2]
            key = "/".join(marketplace_taxonomy.split("/")[3:])
            object = s3.get_object(Bucket=bucket, Key=key)["Body"]
        
            if marketplace_taxonomy.endswith(".xlsx"):
                # Read the entire stream into memory and wrap with BytesIO
                excel_bytes = object.read()
                input_df = pd.read_excel(io.BytesIO(excel_bytes), sheet_name="Experian Taxonomy", skiprows=skiprows)
            elif marketplace_taxonomy.endswith(".csv"):
                input_df = pd.read_csv(object, skiprows=skiprows, encoding="utf-8", encoding_errors="backslashreplace")

            logging.info("read data from marketplace file")

            functions.update_stats(quick_stats, "Trade Desk IDs Metadata Input", "Success", f"Found total of {input_df.shape[0]:,} rows in from Path: {marketplace_taxonomy}")
        except Exception as e:
            functions.update_stats(quick_stats, "Trade Desk IDs Metadata Input", "Failed", str(e))
            raise
            
        try:
            df_formatted = format_metadata(input_df, segment_prefix)
            logging.info(f"formatted input data and filtered out non-country segments, current count: {df_formatted.shape[0]:,} rows")            

            if taxonomy_filter == "ttdid_marketplacefile":
                output_file = f"{output_folder}/{config.TTD_TTDIDS_TAXONOMY_FILENAME}"
            elif taxonomy_filter == "ttdda_marketplacefile":
                output_file = f"{output_folder}/{config.TTD_TTDDA_TAXONOMY_FILENAME}"
            else:
                raise ValueError(f"unknown taxonomy filter: {taxonomy_filter}")

            logging.info(f"saving formatted data to local path: {output_file}")
            # Save the formatted data to a buffer
            csv_buffer = io.StringIO()
            df_formatted.to_csv(csv_buffer, index=False)

            bucket = output_file.split("/")[2]
            key = "/".join(output_file.split("/")[3:])
            logging.info(f"uploading formatted data to S3 bucket: {bucket}, key: {key}")       
            # Upload the buffer content to S3 using put_object
            s3.put_object(Bucket=bucket, Key=key, Body=csv_buffer.getvalue())

            # logging.info(f"saved formatted replace data to local path: {output_file_replace}")            
            # functions.update_stats(quick_stats, "Trade Desk IDs Metadata Output", "Success", 
            #                        f"Formatted and saved {df_formatted.shape[0]:,} rows to local path: {output_file_replace}")
                                   
            # need to get the removes as well as the replace
            # previous is here: $FW_HDFS_DIR/$RUNDATE


        except Exception as e:
            functions.update_stats(quick_stats, "Trade Desk IDs Metadata Output", "Failed", str(e))
            raise
        
        success_flag = True

    except Exception as e:
        logging.error(e)
        success_flag = False
        #functions.send_status_email(f"Error: {__file__} script failed",  e, email_to=email_to)
        raise
    finally:
        alerts_df = pd.DataFrame(quick_stats)    
        title = f"TI00 - Generate Trade Desk IDs metadata for {taxonomy_filter}"
        email_sub = f"***{title} - {emoji['green']}***" if success_flag else f"***{title} - {emoji['red']}***"
        email_body = alerts_df.to_html(index=False)
        #functions.send_teams_email(mask, email_sub, alerts_df.to_html(index=False), email_to=email_to)

        s3.put_object(Bucket=email_data_bucket, Key=email_data_key+"/subject.txt", Body=email_sub)
        s3.put_object(Bucket=email_data_bucket, Key=email_data_key+"/body.txt", Body=email_body)
        endtime = datetime.now()
        logging.info(f"process completed in {str(endtime - startime).split('.')[0]}")

def setup_parser():
    ## Setup Args
    parser = argparse.ArgumentParser()
    parser.add_argument("-m", "--mask", help="date on which process is run in format YYYY-MM-DD", required=True)
    parser.add_argument("-of", "--output_file", required=True, help="formatted marketplace file sent to this local file path")    
    parser.add_argument("-md", "--metadata_file", help="local path to the ttdids marketplace file", required=True)
    parser.add_argument("-tf", "--taxonomy_filter", help="filter for marketplace file discovery", required=True, default="ttdid_marketplacefile")
    parser.add_argument("-sk", "--skiprows", help="number of rows to skip", default=0, type=int)
    parser.add_argument("-sp", "--segment_prefix", help="prefix for segment ids", required=True)
    parser.add_argument("-edb", "--email_data_bucket", required=True)
    parser.add_argument("-edk", "--email_data_key", required=True)
    return parser

if __name__ == "__main__":
    
    parser = setup_parser()
    args, unknown = parser.parse_known_args()    

    ## Setup Spark and logging
    name = os.path.basename(__file__)
    
    spark = SparkSession.builder.appName(f"{name}_{args.mask}").getOrCreate()

    logging.info(f"args are {args}")  
    logging.info("setup complete")
    logging.info(f"output path: {args.output_file}")


    ## Process starts here
    logic_main(args.mask, args.email_data_bucket, args.email_data_key, args.output_file, args.metadata_file, taxonomy_filter=args.taxonomy_filter, segment_prefix=args.segment_prefix, skiprows=args.skiprows)
    logging.info(f"process completed for {name} script")