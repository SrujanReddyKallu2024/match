"""
DAG to process TTD Geo data ingestion.
Processes metadata and geo coordinate data for TTD.
"""

import json
import logging
import time
from datetime import datetime, timedelta

from airflow import DAG
from airflow.models.param import Param
from airflow.operators.python import PythonOperator, BranchPythonOperator, get_current_context
from airflow.operators.dummy import DummyOperator
from airflow.operators.email import EmailOperator
from airflow.models import Variable
from airflow.operators.trigger_dagrun import TriggerDagRunOperator

import pendulum
import re
import sys
import os
import tempfile
from pathlib import Path

# Set up paths
sys.path.append(str(Path(__file__).resolve().parents[1]))
sys.path.append(str(Path(__file__).resolve().parents[1]) + "/shared")

# Standard logging configuration
logging.getLogger(__name__).setLevel(logging.INFO)

# Import shared functions
import shared.functions
import shared.utils
import shared.utils.utils
import shared.bucket_list

logging.info(f"sys.path {sys.path}")

from shared.functions import platform, get_env, parse_s3_path

logging.info(f"Platform is {platform}")

# Import EMR application factory utilities
from shared.utils.emr_application_factory import create_emr_application, delete_emr_application, start_emr_job
import boto3

# Define DAG with parameters
with DAG(
    "ttdgeo_processing",
    description="Process TTD Geo data ingestion",
    catchup=False,
    start_date=pendulum.datetime(2023, 1, 1, tz="UTC"),
    schedule_interval="0 10 * * *",  # Daily at 10 AM
    tags=["ttdgeo", "ingestion"],
    default_args={
        'owner': 'airflow',
        'depends_on_past': False,
        'email_on_failure': True,
        'email_on_retry': False,
        'retries': 1,
        'retry_delay': timedelta(minutes=5),
    },
    params={
        "mask": Param(
            default=datetime.now().strftime("%Y-%m-%d"),
            type="string",
            format="date",
            description="Date on which process is run in format YYYY-MM-DD",
        ),
    },
) as dag:

    def check_for_new_ttdgeo_files(**context):
        """
        Check for new TTD Geo files
        """
        from shared.bucket_list import get_bucket_name
        import shared.functions as sf
        
        bucket_name = get_bucket_name("client_delivery")
        path = "ttdgeo/"
        
        # Check for metadata files
        metadata_files = []
        try:
            all_metadata = sf.list_files(bucket_name, f"{path}", "ttdeu_marketplacefile", is_pattern_parent_directory_name=False)
            metadata_files = [f for f in all_metadata if f.endswith('.xlsx')]
            logging.info(f"Found {len(metadata_files)} metadata files: {metadata_files}")
        except Exception as e:
            logging.warning(f"No metadata files found: {e}")
        
        # Check for data files
        data_files = []
        try:
            all_data = sf.list_files(bucket_name, f"{path}", "ttd_marketplacefile", is_pattern_parent_directory_name=False)
            data_files = [f for f in all_data if f.endswith('.csv')]
            logging.info(f"Found {len(data_files)} data files: {data_files}")
        except Exception as e:
            logging.warning(f"No data files found: {e}")
        
        # Store files in XCom
        context["ti"].xcom_push(key="metadata_files", value=metadata_files)
        context["ti"].xcom_push(key="data_files", value=data_files)
        
        has_files = len(metadata_files) > 0 or len(data_files) > 0
        logging.info(f"Found files to process: {has_files}")
        return has_files

    def create_script_arguments(**context):
        """
        Calculate all paths and configuration needed for the workflow
        """
        from shared.bucket_list import get_bucket_name
        from shared.functions import get_env, parse_s3_path, file_exists
        
        logging.info("Creating script arguments")
        
        # Initialize workflow timing
        workflow_start_time = time.time()
        logging.info("Workflow started %s", datetime.fromtimestamp(workflow_start_time))
        
        # Get environment
        env = get_env()
        
        # Store workflow timing info
        context["task_instance"].xcom_push(key="workflow_start_time", value=workflow_start_time)
        context["task_instance"].xcom_push(key="env", value=env)
        
        # Use execution date directly
        execution_date = context["execution_date"]
        mask = context["params"]["mask"]
        
        # Calculate date formats for file paths
        date_str = execution_date.strftime("%Y-%m-%d")
        now_str = datetime.now().strftime("%Y%m%d%H%M%S")
        
        # Store dates
        context["task_instance"].xcom_push(key="execution_date", value=date_str)
        context["task_instance"].xcom_push(key="mask", value=mask)
        context["task_instance"].xcom_push(key="stats_timestamp", value=now_str)
        
        # Define protocol
        PROTOCOL = "s3a"
        
        # Get bucket names
        source_bucket = get_bucket_name("client_delivery")
        interim_bucket = get_bucket_name("interim") 
        output_bucket = get_bucket_name("output")
        temp_bucket = get_bucket_name("temp")
        code_bucket = get_bucket_name("code")
        log_bucket = get_bucket_name("logs")
        stats_bucket = get_bucket_name("stats")
        
        # Store bucket names
        context["task_instance"].xcom_push(key="source_bucket", value=source_bucket)
        context["task_instance"].xcom_push(key="interim_bucket", value=interim_bucket)
        context["task_instance"].xcom_push(key="output_bucket", value=output_bucket)
        context["task_instance"].xcom_push(key="temp_bucket", value=temp_bucket)
        context["task_instance"].xcom_push(key="code_bucket", value=code_bucket)
        context["task_instance"].xcom_push(key="log_bucket", value=log_bucket)
        context["task_instance"].xcom_push(key="stats_bucket", value=stats_bucket)
        
        # Get files from previous task
        metadata_files = context["ti"].xcom_pull(key="metadata_files", task_ids="check_for_new_ttdgeo_files")
        data_files = context["ti"].xcom_pull(key="data_files", task_ids="check_for_new_ttdgeo_files")
        
        # Define paths using your original approach
        ttdgeo_filepaths = {
            "metadata_input": metadata_files[0] if metadata_files else None,
            "data_input": data_files[0] if data_files else None,
            "metadata_output": f"{PROTOCOL}://{output_bucket}/marketplaces/ttdgeo/metadata/{mask}/ttdgeo_taxonomy_{{cc}}.csv",
            "data_output_partitioned": f"{PROTOCOL}://{temp_bucket}/marketplaces/ttdgeo/data/{mask}/partitioned/ttd_{{cc}}.csv",
            "data_output_final": f"{PROTOCOL}://{temp_bucket}/marketplaces/ttdgeo/data/{mask}/final",
            "metadata_formatted_stats": f"{PROTOCOL}://{stats_bucket}/ttdgeo/metadata_stats_{now_str}_formatted.txt",
            "data_formatted_stats": f"{PROTOCOL}://{stats_bucket}/ttdgeo/data_stats_{now_str}_formatted.txt",
        }
        
        logging.info(f"Using TTD Geo filepaths {ttdgeo_filepaths}")
        
        # Store all paths
        context["task_instance"].xcom_push(key="TTDGEO_FILEPATHS", value=ttdgeo_filepaths)
        
        # Check if input files exist
        metadata_exists = False
        data_exists = False
        
        if ttdgeo_filepaths["metadata_input"]:
            try:
                bucket_name, key = parse_s3_path(ttdgeo_filepaths["metadata_input"])
                metadata_exists = file_exists(bucket_name, key, is_pattern_parent_directory_name=False)
            except Exception as e:
                logging.error(f"Error checking metadata file: {str(e)}")
        
        if ttdgeo_filepaths["data_input"]:
            try:
                bucket_name, key = parse_s3_path(ttdgeo_filepaths["data_input"])
                data_exists = file_exists(bucket_name, key, is_pattern_parent_directory_name=False)
            except Exception as e:
                logging.error(f"Error checking data file: {str(e)}")
        
        context["task_instance"].xcom_push(key="metadata_exists", value=metadata_exists)
        context["task_instance"].xcom_push(key="data_exists", value=data_exists)
        
        # Push EMR common configuration
        execution_role_arn = shared.utils.utils.get_emr_serverless_role(env)
        log_uri_prefix = f"s3://{log_bucket}/spark-logs"
        shared_code = [
            f"s3://{code_bucket}/zipped/ems-code-shared.zip,s3://{code_bucket}/zipped/openpyxl.zip,s3://{code_bucket}/zipped/fsspec.zip,s3://{code_bucket}/zipped/s3fs.zip"
        ]
        ttdgeo_code_prefix = f"s3://{code_bucket}/repos/ems-code-marketplaces-tradedesk-geo"
        
        # Push common args
        context["task_instance"].xcom_push(key="EXECUTION_ROLE_ARN", value=execution_role_arn)
        context["task_instance"].xcom_push(key="LOG_URI_PREFIX", value=log_uri_prefix)
        context["task_instance"].xcom_push(key="SHARED_CODE", value=shared_code)
        context["task_instance"].xcom_push(key="TTDGEO_CODE_PREFIX", value=ttdgeo_code_prefix)
        
        return True

    def initialise(**context):
        """
        Initialize EMR Serverless application
        """
        logging.info("Initializing EMR Serverless application")
        
        # Create application name with timestamp
        date = datetime.now().strftime("%Y%m%d%H%M%S")
        emr_application_name = f"ttdgeo-processing-{date}"
        
        logging.info(f"Creating EMR application with name {emr_application_name}")
        
        # Create EMR application
        app_id = create_emr_application(
            context, emr_application_name, None, None
        )
        
        # Store in XCom
        context["task_instance"].xcom_push(key="application_id", value=app_id)
        context["task_instance"].xcom_push(key="emr_application_name", value=emr_application_name)
        context["task_instance"].xcom_push(key="emr_start_time", value=time.time())
        
        logging.info(f"Created EMR application {app_id}")
        
        return "Executed initialise..."

    def check_input_exists(**context):
        """
        Check if the input files exist in S3
        """
        metadata_files = context["ti"].xcom_pull(key="metadata_files", task_ids="check_for_new_ttdgeo_files")
        data_files = context["ti"].xcom_pull(key="data_files", task_ids="check_for_new_ttdgeo_files")
        
        has_files = (metadata_files and len(metadata_files) > 0) or (data_files and len(data_files) > 0)
        
        if has_files:
            logging.info("Input files exist, proceeding with processing")
            return "process_metadata_files"
        else:
            logging.warning("Input files do not exist, skipping processing")
            return "input_missing"

    def process_metadata_files(**context):
        """
        Process TTD Geo metadata files
        """
        from shared.utils.emr_application_factory import start_emr_job
        import shared.functions as sf
        
        metadata_files = context["ti"].xcom_pull(key="metadata_files", task_ids="check_for_new_ttdgeo_files")
        
        if not metadata_files or len(metadata_files) == 0:
            logging.info("No metadata files to process.")
            return "No metadata files to process"
        
        app_id = context["task_instance"].xcom_pull(key="application_id", task_ids="initialise")
        mask = context["task_instance"].xcom_pull(key="mask", task_ids="create_script_arguments")
        output_bucket = context["task_instance"].xcom_pull(key="output_bucket", task_ids="create_script_arguments")
        temp_bucket = context["task_instance"].xcom_pull(key="temp_bucket", task_ids="create_script_arguments")
        
        EXECUTION_ROLE_ARN = context["task_instance"].xcom_pull(key="EXECUTION_ROLE_ARN", task_ids="create_script_arguments")
        LOG_URI_PREFIX = context["task_instance"].xcom_pull(key="LOG_URI_PREFIX", task_ids="create_script_arguments")
        SHARED_CODE = context["task_instance"].xcom_pull(key="SHARED_CODE", task_ids="create_script_arguments")
        TTDGEO_CODE_PREFIX = context["task_instance"].xcom_pull(key="TTDGEO_CODE_PREFIX", task_ids="create_script_arguments")
        
        execution_date = context["task_instance"].xcom_pull(key="execution_date", task_ids="create_script_arguments")
        
        # Process each metadata file
        for metadata_file in metadata_files:
            logging.info(f"Processing metadata file: {metadata_file}")
            
            # Extract country from filename
            filename = metadata_file.split('/')[-1]
            filename_parts = filename.split('_')
            if len(filename_parts) >= 3:
                country = filename_parts[2].upper()
            else:
                country = "DK"
            
            logging.info(f"Country detected: {country}")
            
            # Email data path
            email_data_key = f"marketplaces/ttdgeo/metadata/{country}/{datetime.now().strftime('%Y-%m-%d')}"
            
            # Job arguments
            job_args = [
                "--input_path", metadata_file,
                "--output_path", f"s3://{output_bucket}/marketplaces/ttdgeo/metadata/{mask}/Update.TTDGEO.Taxonomy.{country}.{datetime.now().strftime('%Y%m%d%H%M%S')}.csv",
                "--execution_date", execution_date,
                "--country_code", country,
                "--email_data_bucket", temp_bucket,
                "--email_data_key", email_data_key
            ]
                
            main = f"{TTDGEO_CODE_PREFIX}/spark/ttdgeo_metadata_emr.py"
            
            job = start_emr_job(
                task_id="process_metadata",
                application_id=app_id,
                execution_role_arn=EXECUTION_ROLE_ARN,
                job_driver={
                    "sparkSubmit": {
                        "entryPoint": main,
                        "entryPointArguments": job_args,
                        "sparkSubmitParameters": f"--conf spark.submit.pyFiles={','.join(SHARED_CODE) if isinstance(SHARED_CODE, list) else SHARED_CODE}",
                    },
                },
                configuration_overrides={
                    "monitoringConfiguration": {
                        "s3MonitoringConfiguration": {
                            "logUri": f"{LOG_URI_PREFIX}/ttdgeo_metadata_{country}",
                        },
                    }
                },
            )
            
            job_id = job.execute(get_current_context())
            logging.info(f"Executed metadata processing for {country}: {job_id}")
            
            # Send email immediately after EMR job (like on-premises - each file sends its own email)
            try:
                s3 = sf.get_s3_client()
                
                subject = s3.get_object(
                    Bucket=temp_bucket,
                    Key=f"{email_data_key}/subject.txt"
                )["Body"].read().decode('utf-8')
                
                html_content = s3.get_object(
                    Bucket=temp_bucket,
                    Key=f"{email_data_key}/body.txt"
                )["Body"].read().decode('utf-8')
                
                email_op = EmailOperator(
                    task_id="send_ttdgeo_metadata_email_report",
                    to=['kallusrujan.reddy@experian.com'],
                    subject=subject,
                    html_content=html_content,
                    dag=dag
                )
                
                email_op.execute(get_current_context())
                logging.info(f"Sent metadata email for {country}")
                
            except Exception as e:
                logging.warning(f"Failed to send metadata email for {country}: {e}")
        
        return f"Processed {len(metadata_files)} metadata files"

    def process_data_files(**context):
        """
        Process ALL TTD Geo data files (like Robin's exact approach)
        """
        from shared.utils.emr_application_factory import start_emr_job
        import shared.functions as sf
        
        data_files = context["ti"].xcom_pull(key="data_files", task_ids="check_for_new_ttdgeo_files")
        
        if not data_files or len(data_files) == 0:
            logging.info("No data files to process.")
            return "No data files to process"
        
        app_id = context["task_instance"].xcom_pull(key="application_id", task_ids="initialise")
        mask = context["task_instance"].xcom_pull(key="mask", task_ids="create_script_arguments")
        temp_bucket = context["task_instance"].xcom_pull(key="temp_bucket", task_ids="create_script_arguments")
        
        EXECUTION_ROLE_ARN = context["task_instance"].xcom_pull(key="EXECUTION_ROLE_ARN", task_ids="create_script_arguments")
        LOG_URI_PREFIX = context["task_instance"].xcom_pull(key="LOG_URI_PREFIX", task_ids="create_script_arguments")
        SHARED_CODE = context["task_instance"].xcom_pull(key="SHARED_CODE", task_ids="create_script_arguments")
        TTDGEO_CODE_PREFIX = context["task_instance"].xcom_pull(key="TTDGEO_CODE_PREFIX", task_ids="create_script_arguments")
        
        execution_date = context["task_instance"].xcom_pull(key="execution_date", task_ids="create_script_arguments")
        
        # Process EACH data file individually (like on-premises exact approach)
        for data_file in data_files:
            logging.info(f"Processing data file: {data_file}")
            
            # On-premises does NOT extract country from filename for data files
            # Country is extracted from actual data inside the Python script
            filename = data_file.split('/')[-1]
            
            # Email data path - use generic path since country is unknown until processing
            email_data_key = f"marketplaces/ttdgeo/data/{datetime.now().strftime('%Y-%m-%d')}"
            
            # TTD geo processes each file separately (country extracted from data inside script)
            job_args = [
                "--input_path", data_file,
                "--output_path", f"s3://{temp_bucket}/marketplaces/ttdgeo/data/{mask}/partitioned/ttd_{{cc}}.csv",
                "--final_output_path", f"s3://{temp_bucket}/marketplaces/ttdgeo/data/{mask}/final",
                "--execution_date", execution_date,
                "--email_data_bucket", temp_bucket,
                "--email_data_key", email_data_key
            ]
                
            main = f"{TTDGEO_CODE_PREFIX}/spark/ttdgeo_data_emr.py"
            
            job = start_emr_job(
                task_id="process_data",
                application_id=app_id,
                execution_role_arn=EXECUTION_ROLE_ARN,
                job_driver={
                    "sparkSubmit": {
                        "entryPoint": main,
                        "entryPointArguments": job_args,
                        "sparkSubmitParameters": f"--conf spark.submit.pyFiles={','.join(SHARED_CODE) if isinstance(SHARED_CODE, list) else SHARED_CODE}",
                    },
                },
                configuration_overrides={
                    "monitoringConfiguration": {
                        "s3MonitoringConfiguration": {
                            "logUri": f"{LOG_URI_PREFIX}/ttdgeo_data_{filename}",
                        },
                    }
                },
            )
            
            job_id = job.execute(get_current_context())
            logging.info(f"Executed data processing for {filename}: {job_id}")
            
            # Send email immediately after EMR job (like on-premises - each file sends its own email)
            try:
                s3 = sf.get_s3_client()
                
                # Find the email files (country is extracted inside the EMR job)
                # List all objects under the email_data_key to find the country-specific folder
                response = s3.list_objects_v2(
                    Bucket=temp_bucket,
                    Prefix=f"{email_data_key}/"
                )
                
                subject_key = None
                body_key = None
                
                if 'Contents' in response:
                    for obj in response['Contents']:
                        if obj['Key'].endswith('/subject.txt'):
                            subject_key = obj['Key']
                        elif obj['Key'].endswith('/body.txt'):
                            body_key = obj['Key']
                
                if subject_key and body_key:
                    subject = s3.get_object(Bucket=temp_bucket, Key=subject_key)["Body"].read().decode('utf-8')
                    html_content = s3.get_object(Bucket=temp_bucket, Key=body_key)["Body"].read().decode('utf-8')
                    
                    email_op = EmailOperator(
                        task_id="send_ttdgeo_data_email_report",
                        to=['kallusrujan.reddy@experian.com'],
                        subject=subject,
                        html_content=html_content,
                        dag=dag
                    )
                    
                    email_op.execute(get_current_context())
                    logging.info(f"Sent data email for {filename}")
                else:
                    logging.warning(f"Could not find email files for {filename}")
                
            except Exception as e:
                logging.warning(f"Failed to send data email for {filename}: {e}")
        
        return f"Processed {len(data_files)} data files"

    def send_metadata_stats_email(**context):
        """
        Send consolidated email with all metadata processing statistics
        """
        import boto3
        import shared.functions as sf
        
        current_date = datetime.now()
        mask = current_date.strftime("%Y-%m-%d")
        recipients = ['kallusrujan.reddy@experian.com']
        
        # Get stored email data paths
        email_data_paths = context["ti"].xcom_pull(key="metadata_email_paths", task_ids="process_metadata_files") or []
        
        if not email_data_paths:
            logging.warning("No metadata email data paths found")
            return "No metadata email data paths found"
        
        try:
            s3 = boto3.client('s3')
            combined_content = f"TTD GEO Metadata Processing - {mask}\n\n"
            overall_success = True
            
            # Read all email data and combine
            for email_data in email_data_paths:
                country = email_data["country"]
                email_data_key = email_data["email_data_key"]
                temp_bucket = email_data["temp_bucket"]
                
                try:
                    # Read subject to check success/failure
                    subject = s3.get_object(
                        Bucket=temp_bucket,
                        Key=f"{email_data_key}/subject.txt"
                    )["Body"].read().decode('utf-8')
                    
                    # Read body content
                    body_content = s3.get_object(
                        Bucket=temp_bucket,
                        Key=f"{email_data_key}/body.txt"
                    )["Body"].read().decode('utf-8')
                    
                    combined_content += f"\n=== {country} Metadata Processing ===\n"
                    combined_content += f"Status: {subject}\n"
                    combined_content += f"{body_content}\n\n"
                    
                    # Check if this country failed
                    if "red" in subject.lower() or "failed" in subject.lower():
                        overall_success = False
                        
                except Exception as e:
                    logging.error(f"Error reading email data for {country}: {e}")
                    combined_content += f"\n=== {country} Metadata Processing ===\n"
                    combined_content += f"Status: ERROR - Could not read email data\n\n"
                    overall_success = False
            
            # Create consolidated email
            status_emoji = "🟢" if overall_success else "🔴"
            subject = f"*** TEUG00: TTD GEO Metadata Processing {status_emoji} *** - {mask}"
            
            html_content = f"""
            <html>
            <body>
                <h2>TTD GEO Metadata Processing - {mask}</h2>
                <pre>{combined_content}</pre>
                <p>This is an automated message from the Airflow system.</p>
            </body>
            </html>
            """
            
            email_op = EmailOperator(
                task_id="send_metadata_consolidated_email",
                to=recipients,
                subject=subject,
                html_content=html_content,
                dag=dag
            )
            
            email_op.execute(context=context)
            
            logging.info(f"Sent consolidated metadata email for {mask}")
            return f"Sent consolidated metadata email for {mask}"
            
        except Exception as e:
            logging.error(f"Error sending consolidated metadata email: {str(e)}")
            return f"Error sending consolidated metadata email: {str(e)}"

    def send_data_stats_email(**context):
        """
        Send consolidated email with all data processing statistics
        """
        import boto3
        import shared.functions as sf
        
        current_date = datetime.now()
        mask = current_date.strftime("%Y-%m-%d")
        recipients = ['kallusrujan.reddy@experian.com']
        
        # Get stored email data paths
        email_data_paths = context["ti"].xcom_pull(key="data_email_paths", task_ids="process_data_files") or []
        
        if not email_data_paths:
            logging.warning("No data email data paths found")
            return "No data email data paths found"
        
        try:
            s3 = boto3.client('s3')
            combined_content = f"TTD GEO Data Processing - {mask}\n\n"
            overall_success = True
            
            # Read all email data and combine
            for email_data in email_data_paths:
                country = email_data["country"]
                email_data_key = email_data["email_data_key"]
                temp_bucket = email_data["temp_bucket"]
                
                try:
                    # Read subject to check success/failure
                    subject = s3.get_object(
                        Bucket=temp_bucket,
                        Key=f"{email_data_key}/subject.txt"
                    )["Body"].read().decode('utf-8')
                    
                    # Read body content
                    body_content = s3.get_object(
                        Bucket=temp_bucket,
                        Key=f"{email_data_key}/body.txt"
                    )["Body"].read().decode('utf-8')
                    
                    combined_content += f"\n=== {country} Data Processing ===\n"
                    combined_content += f"Status: {subject}\n"
                    combined_content += f"{body_content}\n\n"
                    
                    # Check if this country failed
                    if "red" in subject.lower() or "failed" in subject.lower():
                        overall_success = False
                        
                except Exception as e:
                    logging.error(f"Error reading email data for {country}: {e}")
                    combined_content += f"\n=== {country} Data Processing ===\n"
                    combined_content += f"Status: ERROR - Could not read email data\n\n"
                    overall_success = False
            
            # Create consolidated email
            status_emoji = "🟢" if overall_success else "🔴"
            subject = f"*** TEUG01: TTD GEO Data Processing {status_emoji} *** - {mask}"
            
            html_content = f"""
            <html>
            <body>
                <h2>TTD GEO Data Processing - {mask}</h2>
                <pre>{combined_content}</pre>
                <p>This is an automated message from the Airflow system.</p>
            </body>
            </html>
            """
            
            email_op = EmailOperator(
                task_id="send_data_consolidated_email",
                to=recipients,
                subject=subject,
                html_content=html_content,
                dag=dag
            )
            
            email_op.execute(context=context)
            
            logging.info(f"Sent consolidated data email for {mask}")
            return f"Sent consolidated data email for {mask}"
            
        except Exception as e:
            logging.error(f"Error sending consolidated data email: {str(e)}")
            return f"Error sending consolidated data email: {str(e)}"

    def move_ttdgeo_files(**context):
        """
        Move and rename TTD geo files from temp to final output location
        Similar to Robin's move_ttdids_files but for TTD geo format
        """
        try:
            import shared.functions as sf
            
            env = sf.get_env()
            mask = context["task_instance"].xcom_pull(key="mask", task_ids="create_script_arguments")
            temp_bucket = context["task_instance"].xcom_pull(key="temp_bucket", task_ids="create_script_arguments")
            output_bucket = context["task_instance"].xcom_pull(key="output_bucket", task_ids="create_script_arguments")
            
            quick_stats = []
            
            # Find all TTD geo files in temp that need to be moved
            # Looking for files like: Replace.TTDGEO.DK74.20250129123456.csv/part-xxxx.csv
            output_files = sf.list_files(
                temp_bucket,
                f"marketplaces/ttdgeo/data/{mask}/final/Replace.TTDGEO",
                "part",
                is_pattern_parent_directory_name=False
            )
            
            logging.info(f"TTD Geo output files found: {output_files}")
            
            s3 = sf.get_s3_client()
            
            for out in output_files:
                out_bucket, out_key = sf.parse_s3_path(out)
                # Extract the base filename from the directory structure
                # Convert: /final/Replace.TTDGEO.DK74.20250129123456.csv/part-xxxx.csv
                # To: /Replace.TTDGEO.DK74.20250129123456.csv
                final_key = "/".join(out_key.split("/")[:-1])  # Remove part filename, keep directory name as final filename
                final_key = final_key.replace("/final/", "/")  # Remove final directory
                
                s3.copy(CopySource={"Bucket": out_bucket, "Key": out_key}, Bucket=output_bucket, Key=final_key)
                logging.info(f"Moved TTD geo file from {out_key} to {final_key}")
                sf.update_stats(quick_stats, "TTD Geo File Move", "Success", f"Moved file from {out_key} to {final_key}")
            
            logging.info(f"Moved all TTD geo files to {output_bucket}/marketplaces/ttdgeo/data/{mask}/")
            success_flag = True
            
        except Exception as e:
            logging.error(f"Error moving TTD geo files: {e}")
            sf.update_stats(quick_stats, "TTD Geo File Move", "Failed", str(e))
            success_flag = False
        
        # Send email report using Robin's format but for TTD geo
        try:
            title = "TTD GEO Files Moved to Output Bucket"
            subject = f"***{title} - {sf.emoji['green']}***" if success_flag else f"***{title} - {sf.emoji['red']}***"
            
            table = "<html><body><table><tr><th>Time</th><th>Milestone</th><th>Message</th><th>Status</th></tr>{data}</table></body></html>"
            email_body = table.format(data="".join([f"<tr><td>{q['Time']}</td><td>{q['Milestone']}</td><td>{q['Message']}</td><td>{q['Status']}</td></tr>" for q in quick_stats]))
            
            email_op = EmailOperator(
                task_id="send_ttdgeo_move_email_report",
                to=['kallusrujan.reddy@experian.com'],
                subject=subject,
                html_content=email_body,
                dag=dag
            )
            
            email_op.execute(get_current_context())
            
        except Exception as e:
            logging.warning(f"Failed to send TTD geo email: {e}")
        
        if not success_flag: 
            raise Exception("Failed to move TTD geo files")
        
        return f"Moved TTD geo files to {output_bucket}/marketplaces/ttdgeo/data/{mask}/"

    def finalise(**context):
        """
        Delete EMR Serverless application and log workflow completion
        Similar to Robin's finalise_emr function
        """
        from shared.utils.emr_application_factory import delete_emr_application
        
        logging.info("Finalizing EMR application")
        
        app_id = context["task_instance"].xcom_pull(key="application_id", task_ids="initialise")
        emr_application_name = context["task_instance"].xcom_pull(key="emr_application_name", task_ids="initialise")
        workflow_start_time = context["task_instance"].xcom_pull(key="workflow_start_time", task_ids="create_script_arguments")
        
        logging.info(f"Finalization started, deleting application {app_id}")
        
        # Delete EMR application
        delete_emr_application(context, emr_application_name, app_id)
        
        end_time = time.time()
        logging.info(f"Workflow finished, time taken: {timedelta(seconds=end_time - workflow_start_time)}")
        
        return "Finalized EMR application"

    # Define tasks
    start = DummyOperator(task_id="start")
    
    task_check_for_new_ttdgeo_files = PythonOperator(
        task_id="check_for_new_ttdgeo_files",
        python_callable=check_for_new_ttdgeo_files,
        dag=dag,
    )
    
    task_create_arguments = PythonOperator(
        task_id="create_script_arguments",
        python_callable=create_script_arguments,
        trigger_rule="none_failed",
        dag=dag,
    )
    
    task_initialise = PythonOperator(
        task_id="initialise",
        python_callable=initialise,
        trigger_rule="one_success",
        dag=dag,
    )
    
    check_input = BranchPythonOperator(
        task_id="check_input",
        python_callable=check_input_exists,
        dag=dag,
    )
    
    input_missing = DummyOperator(task_id="input_missing", dag=dag)
    
    task_process_metadata_files = PythonOperator(
        task_id="process_metadata_files",
        python_callable=process_metadata_files,
        trigger_rule="none_failed",
        dag=dag,
    )
    
    task_process_data_files = PythonOperator(
        task_id="process_data_files",
        python_callable=process_data_files,
        trigger_rule="none_failed",
        dag=dag,
    )
    
    task_move_ttdgeo_files = PythonOperator(
        task_id="move_ttdgeo_files",
        python_callable=move_ttdgeo_files,
        trigger_rule="all_done",
        dag=dag,
    )
    
    task_finalise = PythonOperator(
        task_id="finalise",
        python_callable=finalise,
        trigger_rule="none_failed_min_one_success",
        dag=dag,
    )
    
    # Task dependencies - Sequential like on-premises (metadata FIRST, then data)
    start >> task_check_for_new_ttdgeo_files >> task_create_arguments >> task_initialise >> check_input
    check_input >> task_process_metadata_files >> task_process_data_files >> task_move_ttdgeo_files >> task_finalise
    check_input >> input_missing >> task_finalise