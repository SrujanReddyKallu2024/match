import pandas as pd
import sys
from pathlib import Path
import argparse
import os
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from datetime import datetime
import time

sys.path.append(str(Path(__file__).resolve().parents[2])) # should be setting PYTHONPATH

import config
import functions
import logging


def check_weird_codes(df, column_name, logger):
    weird_codes = df[column_name].where(df[column_name].str.contains("xa", regex=False)).dropna().to_list()
    weird_codes = [code for code in weird_codes if "\\" in code]
    logger.info(f"checking for weird codes in {column_name}")
    if len(weird_codes) > 0:
        logger.error(f"found weird codes in {column_name}: {weird_codes}")
        raise ValueError(f"found weird codes in {column_name}: {weird_codes}")


def replace_characters(df, column_name, char_replacements, trim_edges=True):
    for char, replacement in char_replacements.items():
        df[column_name] = df[column_name].str.replace(char, replacement, regex=False)
        if trim_edges: df[column_name] = df[column_name].str.strip()


def format_metadata(logger, df, TTL):
    """
    Format the marketplace file based on desired format
    """
    logger.info("formatting metadata")
    logger.info(F"columns: {df.columns}")
    df1 = (
        df[["Segment_ID", "Segment_Name", "Description", "CPM"]]
        .rename({
        "Segment_ID": "seg_temp",
        }, axis=1)
    )

    # clean up
    df1.replace(r"N/A","",inplace=True)

    # create new column with segment number and sort
    df2 = df1[df1.seg_temp.str.startswith("S")].copy()

    # Replace long dashes with hyphens in Segment_Name and Description
    char_replacements = {
        "\\xa3": "£",
        "\\xa0": " "
    }

    replace_characters(df2, "Segment_Name", char_replacements)
    replace_characters(df2, "Description", char_replacements)

    check_weird_codes(df2, "Segment_Name", logger)
    check_weird_codes(df2, "Description", logger)

    df2['num'] = df2.seg_temp.str.replace("S","").astype("int")
    df2.sort_values("num",inplace=True)

    # create new segment id column with no leading zeroes
    df2["Segment_ID"] = "S" + df2.num.astype("string")

    logger.info(f"TTL is {TTL}")
    if TTL: df2["TTL"] = TTL

    # return dataframe with only the columns we want, ordered
    return df2[["Segment_ID", "Segment_Name", "Description", "CPM", "TTL"]] if TTL else df2[["Segment_ID", "Segment_Name", "Description", "CPM"]]


def create_local_parent_dir(output_folder):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)


def logic_main(logger, mask, email_to, output_folder, make_local_dir, metadata_path, date_with_time, ttl=None):

    # import functions after logger is created
    import functions
    logger.info(f"running bw00_generate_metadata script for mask: {mask}")
    quick_stats = []

    try:
        startime = datetime.now()

        try:
            beeswax_marketplace_taxonomy = functions.latest_local_file(metadata_path, "bw_marketplacefile", dateformat="%Y-%m-%d")
            logger.info(f"latest beeswax file: {beeswax_marketplace_taxonomy}")

            input_df = pd.read_csv(beeswax_marketplace_taxonomy, skiprows=0, encoding="utf-8", encoding_errors="backslashreplace")
            logger.info(f"read data from marketplace file {input_df}")

            functions.update_stats(quick_stats, "Beeswax Metadata Input", "Success", f"Found total of {input_df.shape[0]:,} rows in from Path: {beeswax_marketplace_taxonomy}")
        except Exception as e:
            functions.update_stats(quick_stats, "Beeswax Metadata Input", "Failed", str(e))
            raise

        try:
            df_formatted = format_metadata(logger, input_df, ttl)
            logger.info(f"formatted input data and filtered out non-country segments, current count: {df_formatted.shape[0]:,} rows")

            # there is no need to remove segments that are not in the previous file
            # since this is not in the PBI for beeswax
            # this is the code that would do that

            # # got the new taxonomy file need to compare to previous before write out
            # # otherwise it will pick up the one wer're writing out now

            # try:
            #     if functions.platform.is_local:
            #         last_taxonomy = functions.latest_local_file(previous_tax_location, pattern="20", dateformat="%Y-%m-%d", isdir=True)
            #     else:
            #         last_taxonomy = os.path.join( functions.latest_hdfs_file(previous_tax_location, "20"),
            #                                     f"{client_id}__replace__bw_taxonomy.csv"
            #         )
            #         if len(functions.list_files(last_taxonomy)) == 0: last_taxonomy = None
            # except Exception as e:
            #     last_taxonomy = None
            #     logger.warning(f"failed to find previous taxonomy file: {e}")


            # if last_taxonomy:
            #     logger.info(f"last taxonomy file: {last_taxonomy}")
            #     df_last_taxonomy = spark.read.csv(last_taxonomy, header=True).toPandas()
            #     logger.info(f"read last taxonomy file with {df_last_taxonomy.shape[0]:,} rows")
            #     df_remove = df_last_taxonomy[~df_last_taxonomy["Segment ID"].isin(df_formatted["Segment ID"])]
            #     df_remove = df_remove[["Segment ID"]]
            #     removals = int(f"{df_remove.shape[0]:,}")
            #     logger.info(f"filtered out segments that are not in the current file, current count: {removals} rows")

            #     if removals > 0:
            #         output_file_remove = f"{output_folder}/{config.BW_TAX_FILENAME.format(clientid=client_id, logic='remove', filename=f'bw_taxonomy')}"
            #         df_remove.to_csv(output_file_remove, index=False)
            #         logger.info(f"saved formatted remove data to local path: {output_file_remove}")
            #         functions.update_stats(quick_stats, "Beeswax Metadata Output", "Success",
            #             f"Formatted and saved {removals:,} rows to local path: {output_file_remove}")

            #     else:
            #         functions.update_stats(quick_stats, "Beeswax Metadata Output", "Success",
            #             f"Segment IDs in previous file match current file, no removals needed")
            # else:
            #     logger.warning("no previous taxonomy file found, skipping remove file creation")


            if make_local_dir: create_local_parent_dir(output_folder)

            output_file_replace = f"{output_folder}/{config.BW_TAX_FILENAME.format(YYYYMMddHHmmss=date_with_time)}"
            df_formatted.to_csv(output_file_replace, index=False, encoding="utf-8")
            logger.info(f"saved formatted replace data to local path: {output_file_replace}")

            functions.update_stats(quick_stats, "Beeswax Metadata Output", "Success", f"Formatted and saved {df_formatted.shape[0]:,} rows to local path: {output_file_replace}")
            # need to get the removes as well as the replace
            # previous is here: $BW_HDFS_DIR/$RUNDATE
        except Exception as e:
            functions.update_stats(quick_stats, "Beeswax Metadata Output", "Failed", str(e))
            raise

        success_flag = True

    except Exception as e:
        logger.error(e)
        success_flag = False
        functions.send_status_email("Error: bw00_generate_metadata script failed",  e, email_to=email_to)
        raise
    finally:
        alerts_df = pd.DataFrame(quick_stats)
        title = "BW00 - Generate beeswax metadata"
        email_sub = f"***{title} - {config.STATUS_EMOJIS['green']}***" if success_flag else f"***{title} - {config.STATUS_EMOJIS['red']}***"
        functions.send_teams_email(mask, email_sub, alerts_df.to_html(index=False), email_to=email_to)
        endtime = datetime.now()
        logger.info(f"process completed in {str(endtime - startime).split('.')[0]}")

def setup_parser():
    ## Setup Args
    parser = argparse.ArgumentParser()
    parser.add_argument("-m", "--mask", help="date on which process is run in format YYYY-MM-DD", default=config.TODAY_DATE)
    parser.add_argument("-dt", "--date_with_time", help="beeswax required datetime - YYMMDDHHmmss", default=config.BW_DATE_TIME)
    parser.add_argument("-et", "--email_to", help="recipients of email alerts", default=config.EMAIL_TO)
    parser.add_argument("-of", "--output_folder", required=True, help="formatted marketplace file sent to this local file path")
    parser.add_argument("-mld", "--make_local_dir", help="optionally make local directory if it doesn't exist", action="store_true")
    parser.add_argument("-pt", "--previous_tax_location", help="location of previous taxonomy file has a folder with rundate and a name containing bw_taxonomy", default=None)
    parser.add_argument("-cid", "--client_id", help="client id for the output file", default=config.BW_DEFAULT_CLIENT_ID)
    parser.add_argument("-md", "--metadata_path", help="local path to the beeswax marketplace file", default=config.MKP_SCODES_PATH_LOCAL)
    parser.add_argument("-ttl", "--time_to_live", help="add ttl column with this value or None", default=None)
    return parser

if __name__ == "__main__":

    parser = setup_parser()
    config_parser = config.setup_parser()

    # Manually add each argument from config.py to the main parser
    for action in config_parser._actions:
        parser._add_action(action)  # This adds the arguments from config.py

    args, unknown = parser.parse_known_args()

    ## Setup Spark and logging
    name = os.path.basename(__file__)

    #global logger
    logger = config.LogConfig(f"{config.LOGPATH}/{name}_{args.mask}.log").generate_logger(name)
    spark = SparkSession.builder.appName(f"{name}_{args.mask}").getOrCreate()
    spark.sparkContext.setLogLevel("WARN")

    logger.info(f"args are {args}")
    logger.info("setup complete")
    logger.info(f"output path: {args.output_folder}")

    if len(args.date_with_time) != 14:
        logger.error(f"date_with_time must be 12 characters long, got {args.date_with_time}")

    if functions.platform.is_local:
        logger.info("running windows or docker")
        if args.email_to is config.EMAIL_TO:
            logger.error(f"Email address {config.EMAIL_TO} is not valid in local environment")
            sys.exit(1)



    ## Process starts here
    logic_main(logger, args.mask, args.email_to, args.output_folder, args.make_local_dir, args.metadata_path, args.date_with_time, args.time_to_live)

# Testing command
# docker run -it --rm -v C:\Users\potterr\ConsumerSync\match-marketplaces:/hello -e PYTHONPATH=/hello/marketplaces -w /hello pysparktestboto /opt/spark/bin/spark-submit /hello/marketplaces/beeswax/bw00_generate_metadata.py --mask 2022-02-22 --output_folder /hello/testing/metadata/plop2 --make_local_dir --email_to robin.potter@experian.com
# spark-submit marketplaces/beeswax/bw00_generate_metadata.py --mask 2022-02-22 --output_folder testing/metadata --email_to robin.potter@experian.com



