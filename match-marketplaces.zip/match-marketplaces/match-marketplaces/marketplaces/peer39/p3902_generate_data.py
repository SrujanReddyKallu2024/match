import pandas as pd
import sys
from pathlib import Path
import argparse
import os
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from datetime import datetime
import numpy as np

sys.path.append(str(Path(__file__).resolve().parents[2]))

from config import LogConfig, LOGPATH, TODAY_DATE, IDG_GRAPH_PATH, TAX_PATH, P39_PATH_HDFS, EMAIL_TO, STATUS_EMOJIS
from functions import latest_hdfs_file, send_status_email, update_stats, send_teams_email


def format_data(pd_df):
    """
    Add cumulative sums of pc hh count and scode hh count for each S_Code
    """
    pd_df['pen']= pd_df['shh']/ pd_df['hh']
    pd_df = pd_df.sort_values(by= ['S_Code', 'pen'], ascending= [True, False])
    pd_df['shh_cum']= pd_df.groupby('S_Code')['shh'].cumsum()
    pd_df['hh_cum']= pd_df.groupby('S_Code')['hh'].cumsum()
    return pd_df


def get_hh_proportion(df, cbk_pc_count):
    """
    Add proportions of households for pc and scodes
    """    
    df['shh_prop']= df['shh_cum']/ df['stot']
    df['hh_prop']= df['hh_cum']/ cbk_pc_count
    df['diff']= df['shh_prop']- df['hh_prop']
    df.reset_index(inplace= True, drop= True)
    df['prop']= df['stot']/ cbk_pc_count        
    return df


def format_ccode_prop(df):
    """
    Format ccode with proportion data
    """
    df.loc[df['S_Code_Count'] > 2, 'ln_count'] = df['prop'] * np.log(df['S_Code_Count'])
    df.loc[(df['S_Code_Count'] > 2) & (df['hh_prop'] > df['ln_count']), 'factor'] = df['prop']* np.log(df['S_Code_Count'])/ df['hh_prop']    
    df.loc[(df['S_Code_Count'] > 2) & (df['hh_prop'] < df['ln_count']), 'factor'] = 1    
    df.loc[df['S_Code_Count'] == 2, 'factor'] = 1    
    df.loc[df['S_Code_Count'] == 1, 'factor'] = 1
    return df[['C_Code', 'factor']]


def flag_scode_per_pc(df):
    """
    Pivot data to get pc-scode 
    """
    df1 = (
        df[['ps2', 'S_Code2']]
        .copy()
        .drop_duplicates(subset=['ps2', 'S_Code2'], keep='first')
    )
    df1['value']= 1
    return (
        df1
        .pivot(index= 'ps2', columns= 'S_Code2', values= 'value')
        .fillna(0)
        .reset_index()
    )


def logic_main(ctx, logger, mask, pc_path, out_path, email_to):
    logger.info(f"running p3901_get_pc_scode_hhcount script for mask: {mask}")
    quick_stats = []

    try:
        startime = datetime.now()

        try:
            latest_pc_scodes_file = latest_hdfs_file(pc_path, pattern="pc_scodes_hhcount")
            logger.info(f"latest pc scodes file: {latest_pc_scodes_file}")

            pc_scodes_hh = ctx.read.parquet(latest_pc_scodes_file).toPandas()
            logger.info("read pc scodes with hh count data")

            pc_scodes_hh_fmt = format_data(pc_scodes_hh)
            logger.info("formatted pc scodes with hh count data")

            scodes_hh_count= pc_scodes_hh_fmt.groupby('S_Code')['shh'].sum()
            scodes_hh_count.rename('stot', inplace= True)
            logger.info("summed hh count for each S_Code")

            pc_scodes_hh_fmt = pd.merge(pc_scodes_hh_fmt, scodes_hh_count, on= 'S_Code')
            logger.info("added total hh count for each scode to existing pc-scode hh count data")

            update_stats(quick_stats, "Format PC Data", "Success", f"Latest pc scodes data read from: {latest_pc_scodes_file} and formatted")
        except Exception as e:
            update_stats(quick_stats, "Format PC Data", "Failed", str(e))
            raise

        try:
            tax_cbk_pc_file = latest_hdfs_file(pc_path, pattern="cbk_pc")
            logger.info("latest cbk pc file: {tax_cbk_pc_file}")

            tax_cbk_pc_count = ctx.read.parquet(tax_cbk_pc_file).count()
            logger.info("read cbk pc data and counted records")

            pc_scodes_hh_with_prop = get_hh_proportion(pc_scodes_hh_fmt, tax_cbk_pc_count)
            logger.info("added proportions of households for pc and scodes")

            pc_scodes_hh_with_prop_filtered = pc_scodes_hh_with_prop[(pc_scodes_hh_with_prop['hh_prop']< np.power(pc_scodes_hh_with_prop['prop'], 0.5))]
            logger.info("filtered pc-scode hh data to get records where hh prop is less than square root of prop")

            pc_scodes_hh_grp = pc_scodes_hh_with_prop.loc[pc_scodes_hh_with_prop_filtered.groupby(['S_Code'])['diff'].idxmax()]
            logger.info("identified pc-scode hh count with proportion records where scode has maximum diff value in the filtered data")

            update_stats(quick_stats, "Add Proportions to PC Data", "Success", f"Latest cbk pc data read from: {tax_cbk_pc_file} and added proportions and differences to pc-scode hh data")
        except Exception as e:
            update_stats(quick_stats, "Add Proportions to PC Data", "Failed", str(e))
            raise
        
        try:
            ccode_scode_lookup_file = latest_hdfs_file(pc_path, pattern="metadata")
            logger.info(f"latest ccode lookup file: {ccode_scode_lookup_file}")

            ccode_scode_lookup = ctx.read.csv(ccode_scode_lookup_file, header=True).toPandas()
            logger.info("read ccode lookup data")

            scode_count_per_ccode = ccode_scode_lookup.groupby('C_Code')['C_Code'].count()
            scode_count_per_ccode = pd.DataFrame(scode_count_per_ccode).rename(columns= {"C_Code": "S_Code_Count"}).reset_index()
            logger.info("identified count of scodes per ccode")
            
            pc_scode_with_ccode = pd.merge(pc_scodes_hh_grp, ccode_scode_lookup, on= 'S_Code')
            logger.info("merged pc-scode hh data with ccode to scode lookup")

            pc_scode_with_scode_count = pd.merge(pc_scode_with_ccode, scode_count_per_ccode, on= 'C_Code').sort_values(by= ['C_Code', 'S_Code2'], ascending= [True, True])
            logger.info("merged pc-scode hh data with scode count by ccode")

            update_stats(quick_stats, "Attach CCode Lookup to PC-Scode Data", "Success", f"Latest ccode lookup data read from: {ccode_scode_lookup_file} and merged with pc-scode hh data")
        except Exception as e:
            update_stats(quick_stats, "Attach CCode Lookup to PC-Scode Data", "Failed", str(e))
            raise

        try:
            ccode_with_propsum = pc_scode_with_scode_count.groupby('C_Code')['hh_prop', 'prop'].sum()
            logger.info("calculated sum of hhprop and prop columns per ccode")

            ccode_with_propsum_df = pd.DataFrame(ccode_with_propsum).reset_index()
            logger.info("converted series to dataframe")

            pc_scode_less_2 = pc_scode_with_scode_count[pc_scode_with_scode_count['S_Code_Count']<= 2].copy()
            pc_scode_more_2 = pc_scode_with_scode_count[pc_scode_with_scode_count['S_Code_Count']> 2].copy()
            pc_scode_more_2['ln_count']= pc_scode_more_2['prop']* np.log(pc_scode_more_2['S_Code_Count'])
            logger.info("split pc-scode data into 2 dataframes based on scode count")

            ccode_prop_with_scodecount = pd.merge(ccode_with_propsum_df, scode_count_per_ccode, on= "C_Code")
            logger.info("merged ccode with proportion sum data with scode count per ccode")
            
            ccode_prop_with_scodecount_fmt = format_ccode_prop(ccode_prop_with_scodecount)
            logger.info("formatted ccode with proportion data to get ccode with a prop factor")

            pc_scode_with_ccode_factor= pd.merge(pc_scode_with_scode_count, ccode_prop_with_scodecount_fmt, on= 'C_Code')
            pc_scode_with_ccode_factor['hh_prop2']= pc_scode_with_ccode_factor['factor'] * pc_scode_with_ccode_factor['hh_prop']
            logger.info("merged pc-scode hh proportion data with ccode prop factor")

            pc_scode_with_prop = pc_scode_with_ccode_factor[['S_Code', 'S_Code2', 'hh_prop2']]
            logger.info("filtered out required columns from pc-scode-ccode hh data")

            update_stats(quick_stats, "Create HH Proportion for Scode", "Success", f"Calculated sum of hh prop and prop columns per ccode, split pc-scode data into 2 dataframes based on scode count, formatted ccode with proportion data")
        except Exception as e:
            update_stats(quick_stats, "Create HH Proportion for Scode", "Failed", str(e))
            raise

        try:
            pc_scode_initial = pd.merge(pc_scodes_hh_with_prop_filtered, pc_scode_with_prop, on= 'S_Code')
            logger.info("merged pc-scode hh data with hh prop by scode data")

            pc_scode_initial.loc[pc_scode_initial['hh_prop'] <= pc_scode_initial['hh_prop2'], 'flag'] = 1
            pc_scode_initial.loc[pc_scode_initial['hh_prop'] > pc_scode_initial['hh_prop2'], 'flag'] = 0
            logger.info("identified records where hh prop is less than, equal or more than hh prop2")

            pc_scode_initial_filtered = pc_scode_initial[pc_scode_initial['flag']== 1].copy()
            logger.info("filtered out records where hh prop is less than or equal to hh prop2")

            pc_scode_initial_filtered['ps2']= pc_scode_initial_filtered['ps'].str[:4].str.replace(' ','') + ' ' + pc_scode_initial_filtered['ps'].str[5:6]
            logger.info("formatted postcode to get first 4 characters and last character")

            final_scodes = pc_scode_initial_filtered.groupby('S_Code2')['S_Code2'].count()
            final_scodes = pd.DataFrame(final_scodes).rename(columns= {'S_Code2': 'count'}).reset_index()
            logger.info("identified final scodes")
            
            final_scode_count = len(set(list(final_scodes['S_Code2'])))
            update_stats(quick_stats, "Identify Final SCodes", "Success", f"Final SCode count: {final_scode_count:,}")
        except Exception as e:
            update_stats(quick_stats, "Identify Final SCodes", "Failed", str(e))
            raise
        
        try:
            pc_scode_initial_flagged = flag_scode_per_pc(pc_scode_initial_filtered)
            logger.info("flag all scodes for a given postcode")

            pc_scode_initial_spk = ctx.createDataFrame(pc_scode_initial_flagged)
            logger.info("converted pandas dataframe to pyspark dataframe")

            cols_to_int = [c for c in pc_scode_initial_spk.columns if c not in ['ps2']]
            pc_scode_final = (
                pc_scode_initial_spk
                .select('ps2', *(F.col(c).cast('integer').alias(c) for c in cols_to_int))
                .withColumnRenamed('ps2', 'PS')
            )
            logger.info("converted all columns to integer type and renamed ps2 to PS")            
            logger.info(f"final scode list: {cols_to_int}")

            pc_scode_final.repartition(1).write.csv(out_path, header=True, mode='overwrite')
            logger.info(f"written out final pc-scode data to path: {out_path}")

            update_stats(quick_stats, "Final SCodes per PC", "Success", f"Flagged all available scodes ({len(cols_to_int):,}) for a given postcode and written out {pc_scode_final.count():,} records to path: {out_path}")
        except Exception as e:
            update_stats(quick_stats, "Final SCodes per PC", "Failed", str(e))
            raise
        success_flag = True
    except Exception as e:
        logger.error(e)
        success_flag = False
        send_status_email("Error: p3902_generate_data script failed", e, email_to)
        raise
    finally:
        alerts_df = pd.DataFrame(quick_stats)    
        email_sub = f"***P3902 - Generate Peer39 Data - {STATUS_EMOJIS['green']}***" if success_flag else f"***P3902 - Generate Peer39 Data - {STATUS_EMOJIS['red']}***"
        send_teams_email(mask, email_sub, alerts_df.to_html(index=False))
        endtime = datetime.now()
        logger.info(f"process completed in {str(endtime - startime).split('.')[0]}")


if __name__ == "__main__":
    ## Setup Args
    parser = argparse.ArgumentParser()

    parser.add_argument("-m", "--mask", help="date on which process is run in format YYYY-MM-DD", default=TODAY_DATE)
    parser.add_argument("-pp", "--pc_path", help="parent hdfs file path for peer39 data", default=f"{P39_PATH_HDFS}/*/")
    parser.add_argument("-et", "--email_to", help="recipients of email alerts", default=EMAIL_TO)
    parser.add_argument("-op", "--out_path", help="final peer39 pc-scode data is written out to this hdfs file path")

    args = parser.parse_args()
    if args.out_path is None:
        args.out_path = f"{P39_PATH_HDFS}/{args.mask}/p39_final__{datetime.now().strftime('%H-%M-%S')}.csv"

    ## Setup Spark and logging
    name = os.path.basename(__file__)
    logger = LogConfig(f"{LOGPATH}/{name}_{args.mask}.log").generate_logger(name)
    spark = SparkSession.builder.appName(f"{name}_{args.mask}").getOrCreate()

    ## Process starts here
    logic_main(spark, logger, args.mask, args.pc_path, args.out_path, args.email_to)
    