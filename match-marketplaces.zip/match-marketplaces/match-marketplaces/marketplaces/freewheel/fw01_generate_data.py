import pandas as pd
import sys
from pathlib import Path
import argparse
import os
from pyspark.sql import SparkSession, Window
import pyspark.sql.functions as F
from datetime import datetime
import time

sys.path.append(str(Path(__file__).resolve().parents[2])) # should be setting PYTHONPATH

import config
import functions

def logic_main(spark, logger, mask, email_to, output_folder, client_id, metadata_path, debug=False, number_of_partitions=20):
    logger.info(f"running fw01_placeholder script for mask: {mask}")
    quick_stats = []


    ### find most recent match2/taxonomy/*/process/dt_long_cb_key_hh_s.parquet    segments 
    ### find recent "id_graph/lookup/experian/match_id_lookup_experian_*.parquet" matchid
    ### find most recent ip graph id_graph/graphs/ip/ip_*.parquet                 ip_graph
    ### find recent freewheel taxonomy file                                       segments list 

    try:
        startime = datetime.now()
        try:
            section_name = "Discover Files"

            if not functions.platform.is_hdfs:
                ip_graph = functions.latest_local_file(
                    f"{config.IDG_GRAPH_PATH}/ip",
                    pattern="parquet",
                    dateformat="%Y%m%d%H%M",
                    isdir=functions.platform.is_docker,
                )
                experian_taxonomy = os.path.join(
                    functions.latest_local_file(config.TAX_PATH, pattern="20", dateformat="%Y-%m-%d", isdir=True),
                    "process",
                    "dt_long_cb_key_hh_s.parquet",
                )
                match_id_hh_key = functions.latest_local_file(
                    config.FW_MATCH_ID, 
                    "match_id_lookup_experian", 
                    dateformat="%Y%m%d%H%M", isdir=True
                )
                freewheel_taxonomy = functions.latest_local_file(
                    metadata_path, pattern="fw_marketplacefile", dateformat="%Y-%m-%d" 
                )
            else:
                ip_graph = functions.latest_hdfs_file(f"{config.IDG_GRAPH_PATH}/ip")
                experian_taxonomy = os.path.join(
                    functions.latest_hdfs_file(config.TAX_PATH),
                      "process",
                      "dt_long_cb_key_hh_s.parquet"
                )                
                match_id_hh_key = functions.latest_hdfs_file(
                    config.FW_MATCH_ID, "match_id_lookup_experian"
                )
                freewheel_taxonomy = functions.latest_hdfs_file(
                    f"{os.path.dirname(output_folder)}/*/", 
                    f"{client_id}__replace__fw_taxonomy.csv"
                )

            logger.info(f"found files: "
                f"ip_graph: {ip_graph},"
                f"experian_taxonomy: {experian_taxonomy},"
                f"match_id_hh_key: {match_id_hh_key},"
                f"freewheel_taxonomy: {freewheel_taxonomy}"
            )

            functions.update_stats(
                quick_stats,
                section_name,
                "Success",
                f"discovered ip_graph: {ip_graph},\n"
                f"experian_taxonomy: {experian_taxonomy},\n"
                f"match_id_hh_key: {match_id_hh_key},\n"
                f"freewheel_taxonomy: {freewheel_taxonomy}",
            )            

        except Exception as e:
            functions.update_stats(quick_stats, section_name , "Failed", str(e))
            raise


        # load segments data as hh_scode
        # load freewheel taxonomy xls as freewheel_taxonomy
        # giant select/filter (freewheel_taxonomy) on hh_scode as df_hh_scode_extract
        try:
            section_name = "Load Data"
            df_ip_graph = spark.read.parquet(ip_graph).repartition("ip").cache()
            logger.info(f"cached df_ip_graph with count: {df_ip_graph.count()}")

            df_experian_taxonomy = spark.read.parquet(experian_taxonomy)
            logger.info("read taxonomy data")

            if not functions.platform.is_hdfs:
                df_freewheel_taxonomy = pd.read_excel(freewheel_taxonomy, sheet_name="Sheet1", skiprows=0)
                logger.info("read raw input freewheel taxonomy data")
            else:
                df_freewheel_taxonomy = spark.read.csv(freewheel_taxonomy, header=True).toPandas()
                logger.info("read raw input freewheel taxonomy data")

            df_match_id_hh_key = spark.read.parquet(match_id_hh_key)
            logger.info("read match id data")

            if debug: functions.logdf(df_ip_graph)
            if debug: functions.logdf(df_experian_taxonomy)
            if debug: functions.logdf(df_match_id_hh_key)
            if debug: logger.info(df_freewheel_taxonomy)

            s_codes = df_freewheel_taxonomy["Segment ID"].str.replace("S", "").astype(int).to_list()
            s_codes = [f"S{s}" for s in s_codes]
            logger.info(f"count of df_experian_taxonomy: {df_experian_taxonomy.count()}")
            df_hh_scode_extract = df_experian_taxonomy.filter(F.col("S_Code").isin(s_codes)).cache()
            logger.info(f"cached df_hh_scode_extract with count: {df_hh_scode_extract.count()}")

            logger.info("data loaded")

            functions.update_stats(quick_stats, section_name, "Success", 
                f"loaded:\n"
                f"df_match_id_hh_key ({df_match_id_hh_key.count()}),\n"
                f"df_ip_graph ({df_ip_graph.count()}),\n"
                f"df_experian_taxonomy ({df_experian_taxonomy.count()}),\n"
                f"and used df_freewheel_taxonomy to create df_hh_scode_extract ({df_hh_scode_extract.count()})"
            )
        except Exception as e:
            functions.update_stats(quick_stats, section_name, "Failed", str(e))
            raise

            

        # load ip data as input_ip_graph

        # load match id graph lookup as match_id_hh_key
        # window sorted by descending last_seen and descending count of source take top 1 as df_ip_graph

        # Define the window specification
        #! window_spec = Window.partitionBy("key1", "key2").orderBy(F.desc("val1"), F.desc("val2"))
        # Add a row number to each row within the window
        #! df_with_row_num = input_ip_graph.withColumn("row_num", F.row_number().over(window_spec))
        # Filter to keep only the first row in each window partition
        #! df_ip_graph = df_with_row_num.filter(F.col("row_num") <= 5).drop("row_num")

        try:
            section_name = "Dedupe IP/Match graph"

            # griffin said to use last_seen and count of source
            window_spec = Window.partitionBy("ip").orderBy(F.desc("last_seen"), F.desc("source_count"))

            df_with_row_num = ( df_ip_graph
                .withColumn("source_count", F.size(F.split("source",r",")))
                .withColumn("row_num", F.row_number().over(window_spec))
            )
            df_ip_graph_deduped = df_with_row_num.filter(F.col("row_num") <= 5).drop("row_num").cache()
            logger.info(f"cached df_ip_graph_deduped with count: {df_ip_graph_deduped.count()}")

            if debug: functions.logdf(df_ip_graph_deduped)

            logger.info("deduped ip graph")
            
            functions.update_stats(quick_stats, section_name, "Success",
                f"ip graph deduped with count: {df_ip_graph_deduped.count()}"
            )
        except Exception as e:
            functions.update_stats(quick_stats, section_name, "Failed", str(e))
            raise


        # match df_ip_graph to match_id_hh_key as df_graph
        # match df_graph to df_hh_scode_extract

        try:
            section_name = "Join and Extract"

            # join all graphand segment extract
            data = ( df_ip_graph_deduped
                .join(df_match_id_hh_key, "match_id", "left")
                .join(df_hh_scode_extract, "cb_key_household", "left")
                #.select("ip","S_Code")
            )

            if debug: functions.logdf(data)

            # final required values
            data = data.select("ip","S_Code").dropDuplicates().cache()
            logger.info(f"cached data with count: {data.count()}")
            
            logger.info("joined and extracted data")

            if debug: functions.logdf(data)

            functions.update_stats(quick_stats, section_name, "Success", f"Created ip to segment data with count: {data.count()}")
        except Exception as e:
            functions.update_stats(quick_stats, section_name, "Failed", str(e))
            raise

        
        # reformat and output

        try:
            section_name = "Reformat and Output"
            # aggregate to ip line
            output = data.groupBy("ip").agg(F.collect_list("S_Code").alias("segments"))
            output = output.withColumn("segments", F.array_join("segments", ","))
            
            if debug: functions.logdf(output)

            # format output
            output = functions.add_ip_type_column(output, "ip")
            output = output.withColumn("data", F.concat(F.col("ip") , F.lit(",") , F.col("segments"))).select("data", "ip_type").cache()
            logger.info(f"cached raw output with count: {output.count()}")

            if debug: functions.logdf(output)

            # ip4 output
            # ip4 output

            output_filename = f"{output_folder}/{config.FW_AUDIENCE_FILENAME.format(clientid=client_id, logic='add', idtype='ip', filename='fw_audience')}"

            logger.info(f"writing ip4 data to {output_filename}")

            # these will be written to hdfs as txt files inside filename folder
            # write to csv with quote="" produces a null character, rather than an empty string
            num_parts = int(number_of_partitions)
            output.filter(F.col("ip_type")=="ipv4").drop("ip_type").repartition(num_parts).write.mode("overwrite").text(output_filename)
            
            output_ip4_count = spark.read.text(output_filename).count()

            logger.info(f"created output file: {output_filename} at ip4 level with count: {output_ip4_count}")

            functions.update_stats(quick_stats, section_name, "Success", f"Created output file: {output_filename} at ip4 level with count: {output_ip4_count}")

            # ip6 output

            output_filename_ip6 = f"{output_folder}/{config.FW_AUDIENCE_FILENAME.format(clientid=client_id, logic='add', idtype='ipv6', filename='fw_audience')}"

            logger.info(f"writing ip6 data to {output_filename_ip6}")

            # these will be written to hdfs as txt files inside filename folder
            # write to csv with quote="" produces a null character, rather than an empty string
            output.filter(F.col("ip_type")=="ipv6").drop("ip_type").repartition(num_parts).write.mode("overwrite").text(output_filename_ip6)
            
            output_ip6_count = spark.read.text(output_filename_ip6).count()

            logger.info(f"created output file: {output_filename_ip6} at ip level with count: {output_ip6_count}")

            functions.update_stats(quick_stats, section_name, "Success", f"Created output file: {output_filename_ip6} at ip6 level with count: {output_ip6_count}")
        except Exception as e:
            functions.update_stats(quick_stats, section_name, "Failed", str(e))
            raise
        
        time.sleep(60) #added delay to allow writing of file

        update_type = "segment_replace" # "add" or "remove" or "segment_replace"
        
        ## Rename it based on required format i.e. <clientid>__<logic>__{idtype}_fw_audience_001.csv
        try:            
            all_files = functions.get_all_files(output_filename)
            logger.info(f"all ip4 out files: {all_files}")

            if len(all_files) == 0:
                raise Exception("No files found to rename")

            functions.rename_files(logger, mask, all_files, graph_type="ip", new_name_template=f"{client_id}__{update_type}__{{graph_type}}__fw_audience_{{partname}}.csv")

            new_files = functions.get_all_files(output_filename)
            logger.info(f"new_files : {','.join(new_files)}")

            functions.update_stats(quick_stats, "File Rename", "Success", f"Renamed {len(all_files)} files as per FW Format i.e. {new_files[0]}")
        except Exception as e:
            functions.update_stats(quick_stats, "File Rename", "Failed", str(e))
            raise

        
        ## Rename it based on required format i.e. <clientid>__<logic>__{idtype}_fw_audience_001.csv
        try:            
            all_files = functions.get_all_files(output_filename_ip6)
            logger.info(f"all ip6 out files: {all_files}")

            if len(all_files) == 0:
                raise Exception("No files found to rename")

            functions.rename_files(logger, mask, all_files, graph_type="ipv6", new_name_template=f"{client_id}__{update_type}__{{graph_type}}__fw_audience_{{partname}}.csv")

            new_files = functions.get_all_files(output_filename_ip6)
            logger.info(f"new_files : {','.join(new_files)}")

            functions.update_stats(quick_stats, "File Rename", "Success", f"Renamed {len(all_files)} files as per FW Format i.e. {new_files[0]}")
        except Exception as e:
            functions.update_stats(quick_stats, "File Rename", "Failed", str(e))
            raise

        
        success_flag = True

    except Exception as e:
        logger.error(e)
        success_flag = False
        functions.send_status_email("Error: fw01_generate_data script failed", e, email_to)
        raise
    finally:
        alerts_df = pd.DataFrame(quick_stats)
        title = "FW01 - Generate Data"
        email_sub = (
            f"***{title} - {config.STATUS_EMOJIS['green']}***"
            if success_flag
            else f"***{title} - {config.STATUS_EMOJIS['red']}***"
        )
        functions.send_teams_email(mask, email_sub, alerts_df.to_html(index=False), email_to=email_to)
        endtime = datetime.now()
        logger.info(f"process completed in {str(endtime - startime).split('.')[0]}")

def setup_parser():
    ## Setup Args
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("-m", "--mask", help="date on which process is run in format YYYY-MM-DD", default=config.TODAY_DATE,)
    parser.add_argument("-et", "--email_to", help="recipients of email alerts", default=config.EMAIL_TO)
    parser.add_argument("-of", "--output_folder", required=True, help="formatted marketplace file sent to this HDFS file path")
    parser.add_argument("-dbg", "--debug", help="debug mode", action="store_true")
    parser.add_argument("-cid", "--client_id", help="client id for the output file", default="-1")
    parser.add_argument("-np", "--number_of_partitions", help="output number of partitions", default=20)
    parser.add_argument("-md", "--metadata_path", help="local path to the freewheel marketplace file", default=config.MKP_SCODES_PATH_LOCAL)
    return parser

if __name__ == "__main__":

    parser = setup_parser()
    config_parser = config.setup_parser()
    
    # Manually add each argument from config.py to the main parser
    for action in config_parser._actions:
        parser._add_action(action)  # This adds the arguments from config.py
    
    args, unknown = parser.parse_known_args()

    if len(unknown) > 0:
        raise Exception(f"Unknown arguments passed: {unknown}") 

    ## Setup Spark and logging
    name = os.path.basename(__file__)
    
    logger = config.LogConfig(f"{config.LOGPATH}/{name}_{args.mask}.log").generate_logger(name)
    spark = SparkSession.builder.appName(f"{name}_{args.mask}").getOrCreate()

    logger.info(f"args are {args}")
    
    if functions.platform.is_local:
        logger.info("running windows or docker")
        if args.email_to is config.EMAIL_TO:
            logger.error(f"Email address {config.EMAIL_TO} is not valid in local environment")
            sys.exit(1)


    ## Process starts here
    logic_main(spark, logger, args.mask, args.email_to, args.output_folder, args.client_id, args.metadata_path, debug=args.debug, number_of_partitions=args.number_of_partitions)


# Testing command
# docker run -it --rm -v C:\Users\potterr\ConsumerSync\match-marketplaces:/hello -e PYTHONPATH=/hello/marketplaces -w /hello pysparktestboto /opt/spark/bin/spark-submit /hello/marketplaces/freewheel/fw01_generate_data.py --mask 2022-03-04 --base_path_hdfs /hello/testing/data/hdfs/user/unity --email_to robin.potter@experian.com --debug --output_folder testing/data/hdfs/match2/marketplaces/freewheel  | findstr /V 25/02
# spark-submit marketplaces/freewheel/fw01_generate_data.py --mask 2022-02-22 --base_path_hdfs /user/unity/testing/data/hdfs/user/unity --email_to robin.potter@experian.com --debug --output_folder testing/data/hdfs/match2/marketplaces/freewheel | grep fw
# spark-submit --master yarn --queue adam marketplaces/freewheel/fw01_generate_data.py --mask $(date +%Y-%m-%d) --email_to robin.potter@experian.com --debug --output_folder /user/unity/fw_testing/data/hdfs/match2/marketplaces/freewheel | grep fw
