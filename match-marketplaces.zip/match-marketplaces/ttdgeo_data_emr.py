"""
Script Name: ttdgeo_data_emr.py
Description: EMR-compatible version of TTD geo data processing
Date: 2025-07-29
"""

# ----------------------------------------------------------------------
# STANDARD IMPORTS
# ----------------------------------------------------------------------

import os
import sys
import datetime
import argparse
import logging
from typing import Dict
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from timeit import default_timer as timer
import pandas as pd
from shared.functions import save_formatted_report

# Configure root logger
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

# Use the module logger
logger = logging.getLogger(__name__)

# ----------------------------------------------------------------------
# SCRIPT CONFIGURATION
# ----------------------------------------------------------------------

SCRIPT_CODE = "TTDGEO_DATA"

# Status emojis to match on-premises
STATUS_EMOJIS = {
    'green': '✅',
    'red': '❌'
}

# ----------------------------------------------------------------------
# HELPER FUNCTIONS
# ----------------------------------------------------------------------

def update_stats(stats, milestone, status="success", message=""):
    """
    Update the stats dictionary with the milestone, status and message
    """
    stats.append({
        "Time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "Milestone": milestone,
        "Message": message,
        "Status": STATUS_EMOJIS['green'] if status.lower()=="success" else STATUS_EMOJIS['red']
    })

def format_in_data(df, init_cols):
    """    
    Renames the first few columns to the init columns and filters out non-integer values in 'Radius'
    """
    rename_cols = [f'`{df.columns[r]}` as `{init_cols[r]}`' for r in range(len(init_cols))]
    remaining_cols = [f'`{col}`' for col in df.columns[len(init_cols):]]
    return (
        df
        .selectExpr(rename_cols + remaining_cols)
        .filter(F.col("Radius").cast("int").isNotNull())        
    )

# ----------------------------------------------------------------------
# ARGUMENT PARSING
# ----------------------------------------------------------------------

def create_parser():
    """Create argument parser for the script."""
    parser = argparse.ArgumentParser(description="Process TTD geo data for EMR")
    
    parser.add_argument("--input_path", type=str, required=True,
                      help="S3 path to TTD geo CSV file")
    parser.add_argument("--output_path", type=str, required=True,
                      help="S3 path for partitioned geo data output")
    parser.add_argument("--final_output_path", type=str, required=True,
                      help="S3 path for final CSV files output")
    parser.add_argument("--execution_date", type=str, required=True,
                      help="Execution date in YYYY-MM-DD format")
    parser.add_argument("--formatted_stats_path", type=str, required=True,
                      help="S3 path for saving formatted statistics report")
    
    return parser

# ----------------------------------------------------------------------
# MAIN FUNCTION
# ----------------------------------------------------------------------

def main():
    """Main entry point for the script."""
    start_time = timer()
    
    # Parse arguments
    parser = create_parser()
    args, unknown = parser.parse_known_args()
    
    if unknown:
        logger.warning(f"Unknown arguments: {unknown}")
    
    # Initialize Spark Session
    spark = (SparkSession.builder
        .appName("TTD Geo Data Processing")
        .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
        .config("spark.hadoop.fs.s3a.aws.credentials.provider", "com.amazonaws.auth.DefaultAWSCredentialsProvider")
        .getOrCreate())
    
    spark.sparkContext.setLogLevel("WARN")
    
    logger.info("Starting TTD Geo Data Processing")
    logger.info(f"Input path: {args.input_path}")
    logger.info(f"Output path: {args.output_path}")
    
    # Initialize stats like on-premises
    quick_stats = []
    success_flag = False
    
    try:
        # Read CSV file from S3
        input_df = spark.read.csv(args.input_path, header=False)
        logger.info(f"read data from {args.input_path}")
        
        input_count = input_df.count()
        
        # These are the columns we know about and will start the file
        cols = ["SlNo","Lat","Long","Radius"]
        df_formatted = format_in_data(input_df, cols).cache()
        logger.info(f"formatted input data, init cols: {','.join(cols)}")
        
        formatted_count = df_formatted.count()
        logger.info(f"Found {input_count:,} rows in input, filtered out invalids, current count: {formatted_count:,} rows")
        
        update_stats(quick_stats, "TTD Input Data", "Success", f"Found {input_count:,} rows from Path: {args.input_path}, filtered out invalids, current count: {formatted_count:,} rows")
        
        # Bundle up the non-repeating columns into an array
        df_bundled = (
            df_formatted
            .withColumn(
                "list", F.array([F.array(F.lit(c), F.col(f"`{c}`")) for c in df_formatted.columns[len(cols):]])
            )
            .select(*[f"`{col}`" for col in cols] + ["list"])
        )
        logger.info("bundled up the non-repeating columns into an array called list")
        
        # Explode list array and filter out null audiences
        df_exploded = (
            df_bundled
            .withColumn("exploded", F.explode(F.col("list")))
            .select(*cols, F.col("exploded")[1].alias("audience"))
            .filter(F.col("audience").isNotNull())
        )
        logger.info("exploded list array and filtered out null audiences")
        
        update_stats(quick_stats, "TTD Apply Filters", "Success", f"Filtered out null audiences, current count: {df_exploded.count():,} rows")
        
        # Drop SlNo, repartition and drop duplicates
        final_df = df_exploded.drop("SlNo").repartition(128, F.col("audience")).dropDuplicates().cache()
        logger.info("dropped SlNo column, repartitioned and dropped duplicates")
        
        final_count = final_df.count()
        
        # Get audiences
        audiences = [row["audience"] for row in final_df.select("audience").distinct().collect()]
        logger.info(f"final audience count: {len(audiences)}")
        
        # Extract country code from first audience (first two letters from DK74,DK174,DK0 etc)
        country_code = audiences[0][:2] if audiences else "XX"
        output_path_with_cc = args.output_path.format(cc=country_code)
        
        # Write partitioned data
        final_df.write.partitionBy("audience").csv(output_path_with_cc, header=False, mode="overwrite")
        logger.info(f"written out the final data to {output_path_with_cc}")
        
        update_stats(quick_stats, "TTD Output Data", "Success", f"Found {final_count:,} rows in output data after dropping duplicates, saved to {output_path_with_cc}")
        
        # Process each audience to create individual CSV files
        date_time = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        all_files = []
        
        for audience in audiences:
            logger.info(f"Processing audience: {audience}")
            
            # Read the partitioned data for this audience
            audience_df = spark.read.csv(f"{output_path_with_cc}/audience={audience}", header=False)
            
            # Add header and save as single CSV file
            audience_with_header = audience_df.selectExpr("_c0 as LatDeg", "_c1 as LngDeg", "_c2 as RadMet")
            
            final_file_path = f"{args.final_output_path}/Replace.TTDGEO.{audience}.{date_time}.csv"
            audience_with_header.repartition(1).write.csv(final_file_path, header=True, mode="overwrite")
            
            logger.info(f"saved audience {audience} to {final_file_path}")
            all_files.append(1)
        
        if len(all_files) != len(audiences):
            raise Exception(f"failed to process all audiences, count of files: {len(all_files)} is not equal to audiences: {len(audiences)}")
        
        update_stats(quick_stats, "TTD Output Data Files", "Success", f"Processed {len(audiences)} audiences, saved to {args.final_output_path}")
        
        success_flag = True
        
    except Exception as e:
        logger.error(e, exc_info=True)
        update_stats(quick_stats, "TTD Data Processing", "Failed", str(e))
        
    finally:
        # Calculate total time
        end_time = timer()
        time_taken = str(datetime.timedelta(seconds=round(end_time - start_time, 0)))
        
        # Create email-style report like on-premises
        alerts_df = pd.DataFrame(quick_stats)
        email_sub = f"***TEUG01 - Generate TTD data - {STATUS_EMOJIS['green']}***" if success_flag else f"***TEUG01 - Generate TTD data - {STATUS_EMOJIS['red']}***"
        
        # Format report content similar to on-premises
        report_content = f"{email_sub}\n\n"
        report_content += f"Execution Date: {args.execution_date}\n"
        report_content += f"Processing Time: {time_taken}\n\n"
        report_content += alerts_df.to_html(index=False)
        
        # Save formatted report
        logger.info(f"Saving formatted report to: {args.formatted_stats_path}")
        save_formatted_report(args.formatted_stats_path, report_content)
        logger.info("Formatted report saved successfully")
        
        logger.info(f"process completed in {time_taken}")
        
        if not success_flag:
            sys.exit(1)
        else:
            sys.exit(0)
    
    finally:
        spark.stop()

if __name__ == "__main__":
    main()