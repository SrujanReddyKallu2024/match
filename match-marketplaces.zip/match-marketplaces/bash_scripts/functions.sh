#!/bin/bash

source /etc/profile.d/hadoop.sh
dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
source $dir/conf.sh

command -v mailx || alias mailx=echo

# Check if a file exists in HDFS or local; 
# Arguments:
#   1. Input Folder location
#   2. Filename
#   3. Process Name
#   4. If process needs to check a local folder (optional)
check_file_exists(){    
    if [ -n "$4" ]; then
        if [ -f $1/$2 ]
        then
            echo "$1/$2 exists"
        else
            echo "$1/$2 doesn't exist"
            echo "$2 not found in $1, please check logs" | mailx -r "$FROM_EMAIL" -s "$3 - Failed" $MAILLIST
            exit 1
        fi
    elif hdfs dfs -test -e $1/$2
    then
        echo "$1/$2 exists"
    else
        echo "$1/$2 doesn't exist"
        echo "$2 not found in $1, please check logs" | mailx -r "$FROM_EMAIL" -s "$3 - Failed" $MAILLIST
        exit 1
    fi
}


# Transfer files from HDFS to local
# Arguments:
#   1. Filename/filepattern
#   2. If "merge" then run the getmerge command to combine files into one file else simply copy
#   3. Input folder in HDFS
#   4. Output folder in local path
transfer_file_to_local() {
    echo "searching files in hdfs"
    # create local dir
    mkdir -p $4    
    REQ_FILES=$(hdfs dfs -ls $3 | grep $1 | awk '{print $8}' | while read f; do basename $f; done)
    for f in $REQ_FILES
    do        
        if [ -e "$4/$f" ]; then
            echo "$f file already exists in $4, so didn't copy"
        else
            if [[ $2 == "merge" ]]; then
                echo "start transfer of $2 file to local"  
                hdfs dfs -getmerge -skip-empty-file $3/$f $4/$f
                echo "copied $f file from $3 to $4"   
            else
                echo "start transfer file to local"  
                hdfs dfs -copyToLocal $3/$f $4
                echo "copied $f file from $3 to $4"
            fi
        fi
    done
}


# Moves files from source to destination either in local or HDFS. 
# Doesn't move if file doesn't exist at source or it already exists at destination
# Arguments:
#   1. Source type (locals or hdfs)
#   2. Filename/filepattern
#   3. Source folder
#   4. Destination folder
move_file(){
    if [[ $1 == "locals" ]]; then
        mkdir -p $4
        echo "searching for files matching pattern"
        INPUT_FILES=$3/*$2*
        echo "moving local file"
        for i in $INPUT_FILES
        do
            file_name=$(basename $i)
            if test -f $i; then
                if test -f $4/$file_name; then
                    echo "$file_name already exists in $4, cannot move"
                else
                    mv $i $4
                    echo "moved $i into $4"
                fi
            else
                echo "$i doesn't exist"
            fi
        done
    else
        hdfs dfs -mkdir -p $4
        echo "moving HDFS file"
        INPUT_FILES=$(hdfs dfs -ls $3 | grep $2 | awk '{print $8}')
        for i in $INPUT_FILES
        do
            file_name=$(basename $i)
            if hdfs dfs -test -e $i; then
                if hdfs dfs -test -e $4/$file_name; then
                    echo "$file_name already exists in $4, will not move"
                else
                    hdfs dfs -mv $i $4
                    echo "moved $i into $4"
                fi
            else
                echo "$i doesn't exist"
            fi
        done
    fi
}


# Change permissions of a file or folder in HDFS to allow STS to grab the files
# Arguments:
#   1. Path to file or folder
set_permissions(){
    chown -R unity:stsgrp $1 && echo "updated ownership of all files in $1"
    chmod -R 774 $1 && echo "updated file permissions of all files in $1"
}


# Check if a process is already running, Returns 1 if process is running, 0 if not
# Arguments:
#   1. Path of temp lock file
can_mkp_process_run(){
    if [ -f $1 ]
    then
        return 1  
    else
        return 0
    fi
}


#Check if flag file exists in given HDFS path
check_trigger_flag(){
    if hdfs dfs -test -e $1
    then
        return 0
    else
        return 1
    fi
}


# Function to check if a file with a given name pattern in a given folder is older than 15 minutes
# Returns 0 if the file is older than 15 minutes, 1 otherwise
# Arguments: 1. Input folder , 2. File pattern
is_file_ingestible() {
    local folder=$1
    local pattern=$2

    # Get the latest file matching the pattern
    local latest_file=$(find "$folder" -name "*${pattern}*" -type f -printf '%T@ %p\n' | sort -n | tail -1 | cut -d' ' -f2-)

    # Check if no files found or if the file has a .inprogress extension
    if [ -z "$latest_file" ]; then
        echo "No files found matching the pattern."
        return 1
    elif [[ "$latest_file" == *.inprogress ]]; then
        echo "The latest file has a .inprogress extension."
        return 1
    else
        echo "Latest file found: $latest_file"
    fi

    # Get the current time and the file's modification time
    local current_time=$(date +%s)
    local file_mod_time=$(stat -c %Y "$latest_file")

    # Calculate the time difference in minutes
    local time_diff=$(( (current_time - file_mod_time) / 60 ))

    # Check if the time difference is greater than 15 minutes
    if [ $time_diff -gt 15 ]; then        
        return 0
    else
        echo "The file is newer than 15 minutes."
        return 1
    fi
}


# Function to find the latest file in an hdfs directory based on a file name pattern
# Arguments: 1. HDFS directory, 2. File pattern
find_latest_file_in_hdfs() {
    local hdfs_dir=$1
    local file_pattern=$2

    # Get the latest file matching the pattern
    local latest_file=$(hdfs dfs -ls "$hdfs_dir" | grep "$file_pattern" | awk '{print $8}' | sort | tail -1)

    # Check if no files found
    if [ -z "$latest_file" ]; then
        echo "No files found matching the pattern."
        return 1
    else        
        echo "$latest_file"
    fi    
}

# Function to create HDFS directories
# Arguments: 1. HDFS directory path
create_hdfs_dir() {
    local dir_path=$1
    hdfs dfs -mkdir -p "$dir_path" && echo "Created HDFS directory: $dir_path"
}


# Function to copy files to HDFS
# Arguments: 1. Source file path, 2. Destination HDFS path
copy_to_hdfs() {
    local src=$1
    local dest=$2
    hdfs dfs -copyFromLocal "$src" "$dest" && echo "Copied $src to HDFS: $dest"
}


# Function to check if a file exists in HDFS
# Arguments: 1. HDFS file path
check_hdfs_file_exists() {
    local file_path=$1
    hdfs dfs -test -e "$file_path"
}

# Function to copy files to Local
# Arguments: 1. Source file path, 2. Destination HDFS path
copy_to_local() {
    local src=$1
    local dest=$2
    hdfs dfs -copyToLocal "$src" "$dest" && echo "Copied $src to Local: $dest"
}