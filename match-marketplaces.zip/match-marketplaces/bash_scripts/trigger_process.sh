#!/bin/bash

source conf.sh
source functions.sh
source ./triggers/aud_trigger.sh
source ./triggers/p39_trigger.sh
source ./triggers/ttdgeo_trigger.sh
source ./triggers/fw_trigger.sh
source ./triggers/bw_trigger.sh
source ./triggers/ttdid_trigger.sh
# source ./triggers/fwgeo_trigger.sh
source ./triggers/inf_trigger.sh
source ./triggers/snf_trigger.sh

CURRENT_HOUR=$(date +%H)

# Set all scripts in the triggers folder as executable
# chmod +x ./triggers/*.sh

#Process starts here
run_mkp_process_flow() {  
    printf '#%.0s' {1..100}; echo                
    #started process
    starttime=$(date +%s)
    #################
    run_audigent_trigger
    run_p39_trigger
    run_ttdgeo_trigger
    run_freewheel_trigger
    run_beeswax_trigger
    run_ttdids_trigger
    # trigger_fwgeo_process commented out as this has been put on hold indefinitely
    run_infosum_trigger
    run_snowflake_trigger     
    #################
    #finished process
    endtime=$(date +%s)
    duration=$(($endtime - $starttime))
    echo "Finished Marketplace Data Generation Process, took $duration seconds to complete"        
}


run_mkp_process_flow 2>&1 | grep -v 'INFO\|_JAVA_OPTIONS' | awk '{ print strftime("%Y-%m-%d %H:%M:%S"), $0; fflush(); }' >> "$LOGS_DIR/mkp-$RUNDATE.log"
# Check the exit status and alert if it is 1
if [ $? -ne 0 ]; then
    echo "Alert: Marketplace process failed with exit status 1, please check logs at ${LOGS_DIR}/mkp-${RUNDATE}.log"
fi