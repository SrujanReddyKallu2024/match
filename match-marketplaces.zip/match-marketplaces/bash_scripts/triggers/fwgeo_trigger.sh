#!/bin/bash

dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
source $dir/../conf.sh
source $dir/../functions.sh

CURRENT_HOUR=$(date +%H)


trigger_fwgeo_generation() {    
    if is_file_ingestible $MKP_SEG_FILE_DIR "fwgeo_marketplacefile"
    then
        # create destination hdfs backup directory
        hdfs dfs -mkdir -p $FWGEO_MKT_HDFS_DIR/$RUNDATE && echo "created HDFS directory: $FWGEO_MKT_HDFS_DIR/$RUNDATE"
        echo "Triggering FW GEO Metadata Process"
        all_mkp_files=$(ls $MKP_SEG_FILE_DIR/fwgeo_marketplacefile*.xlsx)
        for mfile in ${all_mkp_files[@]}; do
            echo "Running metadata ingestion for : $mfile"
            mfile_name=$(basename "$mfile" | sed 's/\.[^.]*$//')
            country_code=$(echo "$mfile_name" | cut -d'_' -f3)
            echo "Country detected : $country_code"
            postcode_file=$(ls $FWGEO_INPUT_DATA_DIR/fwgeo_marketplace_${country_code}_*.csv | sort | tail -n 1)
            postcode_file_name=$(basename "$postcode_file")
            echo "Postcode file detected: $postcode_file_name"
            hdfs dfs -copyFromLocal ${FWGEO_INPUT_DATA_DIR}/$postcode_file_name $FWGEO_MKT_HDFS_DIR/$RUNDATE && echo "copied postcode file to HDFS: $FWGEO_MKT_HDFS_DIR/$RUNDATE/$postcode_file_name"
            spark-submit $SCHEDULER "${FWGEO_SCRIPT_DIR}/fwg00_generate_metadata.py" \
            -lmf $mfile \
            -apl $FWGEO_MKT_HDFS_DIR/$RUNDATE/$postcode_file_name \
            -c $country_code \
            --email_to $MAILLIST \
            -olp $FWGEO_TEMP_LOCAL_PATH
            # move if the above command runs fine
            if [ $? -eq 0 ]; then
                # move original file to backup
                move_file locals $mfile_name $MKP_SEG_FILE_DIR $DATA_FROM_STS_BACKUP
                # copy marketplacefiles to hdfs
                hdfs dfs -copyFromLocal ${FWGEO_TEMP_LOCAL_PATH}/*csv $FWGEO_MKT_HDFS_DIR/$RUNDATE && echo "copied file to HDFS: $FWGEO_MKT_HDFS_DIR/$RUNDATE/*.csv"
                # copy data file to hdfs
                # move files to local path
                move_file locals $postcode_file_name $FWGEO_INPUT_DATA_DIR $FWGEO_STS_LOCAL_PATH
                move_file locals "fwgeo_taxonomy_" $FWGEO_TEMP_LOCAL_PATH $FWGEO_STS_LOCAL_PATH                
                set_permissions $FWGEO_STS_LOCAL_PATH
                move_file locals $mfile $MKP_SEG_FILE_DIR $DATA_FROM_STS_BACKUP
                echo "Completed FWGEO metadata generation process"
            else
                echo "Metadata process failed for $mfile, will not move the file to data path"
            fi
        done
    else
        echo "File not found in $MKP_SEG_FILE_DIR, FW GEO Metadata process can't be triggered on $RUNDATE at $CURRENT_HOUR"
    fi
}


trigger_fwgeo_process() {
    echo "Triggering FW GEO process"
    trigger_fwgeo_generation
    echo "FW GEO process completed"
}