#!/bin/bash

source conf.sh
source functions.sh
source triggers/lookup_trigger.sh


CURRENT_HOUR=$(date +%H)
AUD_LOCK_FILE="${MKP_LOCK_FILE_DIR}/aud_${RUNDATE}.lock"


trigger_audigent_metadata_generation(){
    echo "Triggering Audigent metadata generation process"
    trigger_client_lookup_generation "audigent"    
    check_file_exists $AUD_LOOKUP_DIR "match_id_lookup_audigent_${LOOKUP_DATE_FORMAT}*.parquet" "Audigent Lookup Generation"
    spark-submit --master yarn --queue $QUEUE1 "${AUD_SCRIPT_DIR}/aud00_generate_metadata.py" -m $RUNDATE -et $MAILLIST
    check_file_exists $AUD_MKT_HDFS_DIR/$RUNDATE "metadata__${CURRENT_HOUR}*.csv" "Audigent Metadata Generation"
    spark-submit --master yarn --queue $QUEUE1 "${AUD_SCRIPT_DIR}/aud01_matchid_with_scodes.py" -m $RUNDATE -et $MAILLIST
    check_file_exists $AUD_MKT_HDFS_DIR/$RUNDATE "matchid_with_scodes__${CURRENT_HOUR}*.parquet" "Audigent MID with SCodes Generation"
    echo "Completed Audigent metadata generation process"
}


trigger_audigent_data_generation(){
    echo "Triggering Audigent data generation process"
    spark-submit --master yarn --queue $QUEUE1 "${AUD_SCRIPT_DIR}/aud02_generate_data.py" -m $RUNDATE -et $MAILLIST
    for id in "${AUD_IDS[@]}"
    do
        check_file_exists $AUD_MKT_HDFS_DIR/$RUNDATE "audigent_${id}_graph.csv" "Audigent ${id} Graph Generation"
        transfer_file_to_local "UK__experianuk_${id}_UK_${RUNDATE}" "gz" "${AUD_MKT_HDFS_DIR}/${RUNDATE}/audigent_${id}_graph.csv" $AUD_LOCAL_TEMP_DIR
        move_file locals "UK__experianuk_${id}_UK_${RUNDATE}_*.csv.gz" $AUD_LOCAL_TEMP_DIR $AUD_LOCAL_DATA_DIR
    done
    transfer_file_to_local "UK__experianuk_meta_UK_${RUNDATE}" "gz" "${AUD_MKT_HDFS_DIR}/${RUNDATE}/metadata__*.csv" $AUD_LOCAL_TEMP_DIR
    move_file locals "UK__experianuk_meta_UK_${RUNDATE}_*.csv.gz" $AUD_LOCAL_TEMP_DIR $AUD_LOCAL_METADATA_DIR
    set_permissions "${MKP_LOCAL_DIR}/audigent"
    echo "Completed Audigent data generation process"
}


trigger_audigent_custom_data(){
    if is_file_ingestible $AUD_LOCAL_CUSTOM_INDIR "audigent_hhkeys"
    then
        echo "Triggering Audigent custom data generation process"
        spark-submit --master yarn --queue $QUEUE1 "${AUD_SCRIPT_DIR}/aud03_generate_custom_data.py" -m $RUNDATE -et $MAILLIST
        sleep 120s
        check_file_exists $AUD_LOCAL_TEMP_DIR "audigent_custom_audience_${RUNDATE}.csv" "Audigent Custom Data Generation" "Local"
        hdfs dfs -mkdir -p "$AUD_MKT_HDFS_DIR/$RUNDATE" && echo "created HDFS directory: ${AUD_MKT_HDFS_DIR}/${RUNDATE}"
        hdfs dfs -copyFromLocal "${AUD_LOCAL_TEMP_DIR}/audigent_custom_audience_${RUNDATE}.csv" "${AUD_MKT_HDFS_DIR}/${RUNDATE}" && echo "copied custom data file to HDFS: ${AUD_MKT_HDFS_DIR}/${RUNDATE}"        
        move_file locals "audigent_custom_audience_${RUNDATE}.csv" $AUD_LOCAL_TEMP_DIR $AUD_LOCAL_CUSTOM_OUTDIR
        set_permissions $AUD_LOCAL_CUSTOM_OUTDIR
        move_file locals "audigent_hhkeys" $AUD_LOCAL_CUSTOM_INDIR $DATA_FROM_STS_BACKUP
        echo "Completed Audigent custom data generation process"
    else
        echo "File not found in $AUD_LOCAL_CUSTOM_INDIR, Audigent custom data process can't be triggered on $RUNDATE at $CURRENT_HOUR"
    fi

}


trigger_audigent_process() {
    trigger_audigent_custom_data
    if [ $RUNDATE == $SUN_DATE ] && [ $CURRENT_HOUR == "11" ];
    then
        echo "Triggering Audigent process"        
        trigger_audigent_metadata_generation
        trigger_audigent_data_generation        
        echo "Audigent process completed"
    else
        echo "Audigent process can't be triggered on $RUNDATE at $CURRENT_HOUR"
    fi
}


run_audigent_trigger(){
    if can_mkp_process_run $AUD_LOCK_FILE 
    then
        touch $AUD_LOCK_FILE && echo "created audigent mkp lock file"
        trigger_audigent_process
        if [ $? -ne 0 ]; then
            echo "Alert: Audigent process failed with exit status 1, please check logs at ${LOGS_DIR}/mkp-${RUNDATE}.log"
            return 1
        fi
        rm $AUD_LOCK_FILE && echo "removed audigent mkp lock file"
    else
        echo "Audigent process is already running on $RUNDATE"
    fi
}