#!/bin/bash

dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
source $dir/../conf.sh
source $dir/../functions.sh

CURRENT_HOUR=$(date +%H)
TTDIDS_LOCK_FILE="${MKP_LOCK_FILE_DIR}/ttdids_${RUNDATE}.lock"


trigger_ttdids_metadata_generation() {
    if is_file_ingestible $MKP_SEG_FILE_DIR "ttdid_marketplacefile"
    then
        echo "Triggering TTD IDs Metadata Process"
        all_mkp_files=$(ls $MKP_SEG_FILE_DIR/ttdid_marketplacefile*.csv)
        mkdir -p $TTDIDS_TEMP_LOCAL_PATH
        for mfile in ${all_mkp_files[@]}; do
            echo "Running metadata ingestion for : $mfile"
            mfile_name=$(basename "$mfile" | sed 's/\.[^.]*$//')
            spark-submit $SCHEDULER "${TTDIDS_SCRIPT_DIR}/ti00_generate_metadata.py" -of $TTDIDS_TEMP_LOCAL_PATH -m $RUNDATE --segment_prefix SU
            # move if the above command runs fine
            if [ $? -eq 0 ]; then
                move_file locals $mfile_name $MKP_SEG_FILE_DIR $DATA_FROM_STS_BACKUP
                hdfs dfs -mkdir -p $TTDIDS_MKT_HDFS_DIR/$RUNDATE && echo "created HDFS directory: $TTDIDS_MKT_HDFS_DIR/$RUNDATE"
                metafiles=($(ls $TTDIDS_TEMP_LOCAL_PATH/*ttdid_marketplacefile*))
                for mfile in ${metafiles[@]}; do
                    file_name=$(basename "$mfile")
                    hdfs dfs -copyFromLocal "${TTDIDS_TEMP_LOCAL_PATH}/${file_name}" "$TTDIDS_MKT_HDFS_DIR/" && echo "copied metadata files to HDFS: $TTDIDS_MKT_HDFS_DIR/"
                done
                move_file locals "Update" $TTDIDS_TEMP_LOCAL_PATH $TTDIDS_STS_LOCAL_PATH
                set_permissions $TTDIDS_STS_LOCAL_PATH
                move_file locals $mfile $MKP_SEG_FILE_DIR $DATA_FROM_STS_BACKUP
                echo "Completed TTDIDS metadata generation process"
            else
                echo "Metadata process failed for $mfile, will not move the file to data path"
            fi
        done
    else
        echo "File not found in $MKP_SEG_FILE_DIR, TTD IDs Metadata process can't be triggered on $RUNDATE at $CURRENT_HOUR"
    fi
}

trigger_ttdids_metadata_generation_data_alliance() {
    if is_file_ingestible $MKP_SEG_FILE_DIR "ttdda_marketplacefile"
    then
        echo "Triggering TTD Data Alliance Metadata Process"
        all_mkp_files=$(ls $MKP_SEG_FILE_DIR/ttdda_marketplacefile*.xlsx)
        mkdir -p $TTDIDS_TEMP_LOCAL_PATH
        for mfile in ${all_mkp_files[@]}; do
            echo "Running metadata ingestion for : $mfile"
            mfile_name=$(basename "$mfile" | sed 's/\.[^.]*$//')
            spark-submit $SCHEDULER "${TTDIDS_SCRIPT_DIR}/ti00_generate_metadata.py" -of $TTDIDS_TEMP_LOCAL_PATH -m $RUNDATE --segment_prefix DA -tf ttdda_marketplacefile -sk 1
            # move if the above command runs fine
            if [ $? -eq 0 ]; then
                move_file locals $mfile_name $MKP_SEG_FILE_DIR $DATA_FROM_STS_BACKUP
                hdfs dfs -mkdir -p $TTDIDS_MKT_HDFS_DIR/$RUNDATE && echo "created HDFS directory: $TTDIDS_MKT_HDFS_DIR/$RUNDATE"
                metafiles=($(ls $TTDIDS_TEMP_LOCAL_PATH/*ttdda_marketplacefile*))
                for mfile in ${metafiles[@]}; do
                    file_name=$(basename "$mfile")
                    hdfs dfs -copyFromLocal "${TTDIDS_TEMP_LOCAL_PATH}/${file_name}" "$TTDIDS_MKT_HDFS_DIR/" && echo "copied metadata files to HDFS: $TTDIDS_MKT_HDFS_DIR/"
                done
                mv ${TTDIDS_TEMP_LOCAL_PATH}/${TTD_TTDDA_TAXONOMY_FILENAME} ${TTDIDS_TEMP_LOCAL_PATH}/${TTD_TTDDA_TAXONOMY_FILENAME_OUTPUT} 
                move_file locals "UPDATE" $TTDIDS_TEMP_LOCAL_PATH $TTDIDS_STS_LOCAL_PATH
                set_permissions $TTDIDS_STS_LOCAL_PATH
                move_file locals $mfile $MKP_SEG_FILE_DIR $DATA_FROM_STS_BACKUP
                echo "Completed TTD Data Alliance metadata generation process"
            else
                echo "Metadata process failed for $mfile, will not move the file to data path"
            fi
        done
    else
        echo "File not found in $MKP_SEG_FILE_DIR, TTD IDs Metadata process can't be triggered on $RUNDATE at $CURRENT_HOUR"
    fi
}


trigger_ttdids_data_generation() {
    echo "Triggering TTD IDs data generation process"
    spark-submit $SCHEDULER "${TTDIDS_SCRIPT_DIR}/ti01_generate_data.py" -of $TTDIDS_MKT_HDFS_DIR/$RUNDATE  -m $RUNDATE  --segment_prefix SU -md $TTDIDS_MKT_HDFS_DIR
    if [ $? -eq 0 ]; then

        last_ttdda=$(find_latest_file_in_hdfs $TTDIDS_MKT_HDFS_DIR ttdda_marketplacefile)
        last_ttdid=$(find_latest_file_in_hdfs $TTDIDS_MKT_HDFS_DIR ttdid_marketplacefile)

        echo "Latest TTDA file: $last_ttdda"
        echo "Latest TTDID file: $last_ttdid"

        # Get the list of SU segments and DA segments
        su_segments=$(hdfs dfs -cat $last_ttdid | tail -n +2 | cut -d',' -f1 | sed 's/^SU//' | sed 's/^0*//')
        da_segments=$(hdfs dfs -cat $last_ttdda | tail -n +2 | cut -d',' -f1 | sed 's/^DA//' | sed 's/^0*//')

        for id in maids ttdids uid; do
            mkdir -p $TTDIDS_TEMP_LOCAL_PATH/$id && echo "Created directory $TTDIDS_TEMP_LOCAL_PATH/$id"
            for su in $su_segments; do
                echo "Processing SU segment: $su"
                hdfs dfs -copyToLocal $TTDIDS_MKT_HDFS_DIR/$RUNDATE/$id/S_Code=${su} $TTDIDS_TEMP_LOCAL_PATH/$id/ && echo "Copied SU segment $su to local"
                for chunk in $(ls $TTDIDS_TEMP_LOCAL_PATH/$id/S_Code=${su} | grep -o -P '(?<=chunk=)[0-9]+' | sort -u); do
                    echo "Processing chunk: $chunk"
                    echo $id | gzip - > $TTDIDS_TEMP_LOCAL_PATH/${id}/S_Code=${su}/chunk=${chunk}/_.gz
                    sup=SU$(printf %07d ${su})
                    cat $TTDIDS_TEMP_LOCAL_PATH/$id/S_Code=${su}/chunk=${chunk}/* > $TTDIDS_TEMP_LOCAL_PATH/Replace.TTDID.${sup}.${chunk}.${id}.${TTDIDS_DATE}.csv.gzip && echo "Created TTDID file for SU $su, chunk $chunk"
                    # Check if the SU segment is in the DA list
                    if echo "$da_segments" | grep -q "^$su$"; then
                        newfile=$TTDIDS_TEMP_LOCAL_PATH/Replace.TTDDA.DA$(printf %07d ${su}).${chunk}.${id}.${TTDIDS_DATE}.csv.gzip
                        cp $TTDIDS_TEMP_LOCAL_PATH/Replace.TTDID.${sup}.${chunk}.${id}.${TTDIDS_DATE}.csv.gzip $newfile && echo "Created DA file: $newfile"
                    fi
                    move_file locals Replace $TTDIDS_TEMP_LOCAL_PATH $TTDIDS_STS_LOCAL_PATH && echo "Moved TTDID/DA file to STS path"
                    set_permissions $TTDIDS_STS_LOCAL_PATH && echo "Set permissions for STS path"
                    rm -r $TTDIDS_TEMP_LOCAL_PATH/$id/S_Code=${su}/chunk=${chunk}
                    remain=`df | grep /data | awk '{print $4}'`
                    if [[ $remain -lt 100000000 ]]; then echo "sleep!"; sleep 1h; fi
                done
                rm -r $TTDIDS_TEMP_LOCAL_PATH/$id/S_Code=${su}
            done
            echo "Processing for ID $id complete"
        done

        hdfs dfs -rm -r -skipTrash /user/unity/writetemp/df_maids_graph
        hdfs dfs -rm -r -skipTrash /user/unity/writetemp/df_uid_graph
        hdfs dfs -rm -r -skipTrash /user/unity/writetemp/df_ttdids_graph
        hdfs dfs -rm -r -skipTrash /user/unity/writetemp/df_matchid_scode_extract
        hdfs dfs -rm -r -skipTrash /user/unity/writetemp/deduped_maids_graph
        hdfs dfs -rm -r -skipTrash /user/unity/writetemp/deduped_uid_graph
        hdfs dfs -rm -r -skipTrash /user/unity/writetemp/deduped_ttdids_graph

        hdfs dfs -touchz $TTDIDS_MKT_HDFS_DIR/ttdids_flag_${RUNDATE} && echo "created flag file in HDFS: $TTDIDS_MKT_HDFS_DIR/ttdids_flag_${RUNDATE}"
        echo "Completed TTD IDs data generation process"
    else
        echo "TTD IDs Data generation process failed, will not move the file to sts data path"
    fi
}



trigger_ttdids_process() {
    echo "Triggering TTD ID and Data Allience processes"
    trigger_ttdids_metadata_generation
    trigger_ttdids_metadata_generation_data_alliance
    if [ $CURRENT_HOUR == "00" ] && ! hdfs dfs -test -d "$TTDIDS_MKT_HDFS_DIR/$RUNDATE"; then
        echo "Triggering TTD IDs data generation process"
        trigger_ttdids_data_generation
    else
        echo "TTD IDs data generation process will not be triggered on $RUNDATE at $CURRENT_HOUR"
    fi
    echo "TTD IDs process completed"
}


run_ttdids_trigger(){
    if can_mkp_process_run $TTDIDS_LOCK_FILE
    then
        touch $TTDIDS_LOCK_FILE && echo "created ttdids mkp lock file"
        trigger_ttdids_process
        if [ $? -ne 0 ]; then
            echo "Alert: TTDIDs process failed with exit status 1, please check logs at ${LOGS_DIR}/mkp-${RUNDATE}.log"
            return 1
        fi
        rm $TTDIDS_LOCK_FILE && echo "removed ttdids mkp lock file"
    else
        echo "TTDIDs process is already running on $RUNDATE"
    fi
}