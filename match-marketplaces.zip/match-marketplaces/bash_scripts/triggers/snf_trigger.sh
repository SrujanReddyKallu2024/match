#!/bin/bash

source conf.sh
source functions.sh
source triggers/lookup_trigger.sh


CURRENT_HOUR=$(date +%H)
SNF_LOCK_FILE="${MKP_LOCK_FILE_DIR}/snf_${RUNDATE}.lock"


trigger_snowflake_lookup_generation(){
    echo "Triggering Snowflake metadata generation process"
    trigger_client_lookup_generation "snowflake"    
    check_file_exists $SNF_LOOKUP_DIR "match_id_lookup_snowflake_${LOOKUP_DATE_FORMAT}*.parquet" "Snowflake Lookup Generation"    
    echo "Completed Snowflake metadata generation process"
}

trigger_snowflake_process() {
    if [ $RUNDATE == $SUN_DATE ] && [ $CURRENT_HOUR == "16" ];
    then
        echo "Triggering Snowflake process"
        trigger_snowflake_lookup_generation
        spark-submit --master yarn --queue $QUEUE1 "${SNF_SCRIPT_DIR}/snf01_generate_data.py" -m $RUNDATE -et $MAILLIST
        if [ $? -eq 0 ]; then
            hdfs dfs -mkdir -p $SNF_MKT_HDFS_DIR/$RUNDATE && echo "created HDFS directory: $SNF_MKT_HDFS_DIR/$RUNDATE"
            mkdir -p $SNF_TEMP_LOCAL_PATH
            hdfs dfs -copyToLocal "${SNF_MKT_HDFS_DIR}/${RUNDATE}/snowflake*/*__part*.parquet" $SNF_TEMP_LOCAL_PATH && echo "copied file from HDFS to local: $SNF_TEMP_LOCAL_PATH"
            move_file locals "__part" $SNF_TEMP_LOCAL_PATH $SNF_STS_LOCAL_PATH
            set_permissions $SNF_STS_LOCAL_PATH
        else
            echo "Snowflake Data generation process failed, will not move the file to sts data path"
            return 1
        fi
        echo "Snowflake process completed"
    else
        echo "Snowflake process can't be triggered on $RUNDATE at $CURRENT_HOUR"
    fi
}


run_snowflake_trigger(){
    if can_mkp_process_run $SNF_LOCK_FILE 
    then
        touch $SNF_LOCK_FILE && echo "created snowflake mkp lock file"        
        trigger_snowflake_process
        if [ $? -ne 0 ]; then
            echo "Alert: Snowflake process failed with exit status 1, please check logs at ${LOGS_DIR}/mkp-${RUNDATE}.log"
            return 1
        fi
        rm $SNF_LOCK_FILE && echo "removed snowflake mkp lock file"
    else
        echo "Snowflake process is already running on $RUNDATE"
    fi
}