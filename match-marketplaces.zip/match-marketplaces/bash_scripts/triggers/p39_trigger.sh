#!/bin/bash

source conf.sh
source functions.sh


CURRENT_HOUR=$(date +%H)
P39_LOCK_FILE="${MKP_LOCK_FILE_DIR}/p39_${RUNDATE}.lock"


trigger_p39_metadata_generation(){
    echo "Triggering P39 metadata generation process"
    spark-submit --master yarn --queue $QUEUE1 "${P39_SCRIPT_DIR}/p3900_generate_metadata.py" -m $RUNDATE -et $MAILLIST
    check_file_exists $P39_MKT_HDFS_DIR/$RUNDATE "metadata__${CURRENT_HOUR}*.csv" "P39 Metadata Generation"
    spark-submit --master yarn --queue $QUEUE1 "${P39_SCRIPT_DIR}/p3901_get_pc_scode_hhcount.py" -m $RUNDATE -et $MAILLIST
    check_file_exists $P39_MKT_HDFS_DIR/$RUNDATE "pc_scodes_hhcount__${CURRENT_HOUR}*.parquet" "P39 MID with SCodes Generation"
    echo "Completed P39 metadata generation process"    
}


trigger_p39_data_generation(){
    echo "Triggering P39 data generation process"
    spark-submit --master yarn --queue $QUEUE1 "${P39_SCRIPT_DIR}/p3902_generate_data.py" -m $RUNDATE -et $MAILLIST
    check_file_exists $P39_MKT_HDFS_DIR/$RUNDATE "p39_final__${CURRENT_HOUR}*.csv" "P39 Data Generation"
    transfer_file_to_local "p39_final__${CURRENT_HOUR}" "csv" "${P39_MKT_HDFS_DIR}/${RUNDATE}/p39_final__${CURRENT_HOUR}*.csv" $P39_LOCAL_TEMP_DIR
    mv $P39_LOCAL_TEMP_DIR/part*.csv $P39_LOCAL_DIR/peer39_ps_taxonomy_${P39_DATE_FORMAT}.csv
    set_permissions $P39_LOCAL_DIR
    hdfs dfs -rm "${P39_TAX_FLAG_PATH}/p39_taxonomy_${P39_MONTH}-*_inprogress" && echo "removed new taxonomy flag file"
    echo "Completed P39 data generation process"
}


trigger_p39_process() {
    if check_trigger_flag "${P39_TAX_FLAG_PATH}/p39_taxonomy_${P39_MONTH}-*_inprogress" && [ $RUNDATE == $SUN_DATE ] && [ $CURRENT_HOUR == "15" ];
    then
        echo "Triggering P39 process"
        trigger_p39_metadata_generation
        trigger_p39_data_generation
        echo "P39 process completed"
    else
        echo "Peer39 process can't be triggered on $RUNDATE at $CURRENT_HOUR"
    fi
}


run_p39_trigger(){
    if can_mkp_process_run $P39_LOCK_FILE 
    then
        touch $P39_LOCK_FILE && echo "created p39 mkp lock file"
        trigger_p39_process
        if [ $? -ne 0 ]; then
            echo "Alert: Peer39 process failed with exit status 1, please check logs at ${LOGS_DIR}/mkp-${RUNDATE}.log"
            return 1
        fi
        rm $P39_LOCK_FILE && echo "removed p39 mkp lock file"
    else
        echo "Peer39 process is already running on $RUNDATE"
    fi
}