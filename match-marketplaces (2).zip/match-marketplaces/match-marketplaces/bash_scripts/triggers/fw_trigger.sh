#!/bin/bash

dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
source $dir/../conf.sh
source $dir/../functions.sh


CURRENT_HOUR=$(date +%H)
FW_LOCK_FILE="${MKP_LOCK_FILE_DIR}/fw_${RUNDATE}.lock"


# This function generates Freewheel metadata files once the marketplace file is ingested
# copies the metadata files to HDFS and to STS folder and moves the marketplace file to backup location
trigger_freewheel_metadata_generation(){    
    if is_file_ingestible "$MKP_SEG_FILE_DIR" "fw_marketplacefile"
    then
        echo "Triggering Freewheel metadata generation process"
        mkdir -p "$FW_LOCAL_TMP_DIR" && echo "created local directory: $FW_LOCAL_TMP_DIR"              
        
        spark-submit $SCHEDULER "${FW_SCRIPT_DIR}/fw00_generate_metadata.py" \
            -m "$RUNDATE" -cid "$FW_CLIENT_DEFAULT_ID" -of "$FW_LOCAL_TMP_DIR" -pt "$FW_HDFS_DIR" -et "$MAILLIST"

        if [ $? -eq 0 ]; then
            create_hdfs_dir "$FW_HDFS_DIR/$RUNDATE"
            metafiles=($(ls $FW_LOCAL_TMP_DIR/*fw_taxonomy*))
            for mfile in ${metafiles[@]}; do
                file_name=$(basename "$mfile")                
                copy_to_hdfs "${FW_LOCAL_TMP_DIR}/${file_name}" "$FW_HDFS_DIR/$RUNDATE"                    
            done
            move_file locals "fw_taxonomy" "$FW_LOCAL_TMP_DIR" "$FW_LOCAL_TAX_DIR"
            set_permissions "$FW_LOCAL_TAX_DIR"
            move_file locals "fw_marketplacefile" "$MKP_SEG_FILE_DIR" "$DATA_FROM_STS_BACKUP"
            echo "Completed Freewheel metadata generation process"
        else
            echo "Metadata process failed, will not move the output metadata file to sts data path"
            return 1
        fi
    else
        echo "File not found in $MKP_SEG_FILE_DIR, Freewheel metadata process can't be triggered on $RUNDATE at $CURRENT_HOUR"
    fi
}


# This function will generate freewheel segment data and copy the generated files to local temp dir and create a flag file
trigger_freewheel_data_generation() {
    echo "Triggering Freewheel data generation process"
    spark-submit $SCHEDULER "${FW_SCRIPT_DIR}/fw01_generate_data.py" \
        -et "$MAILLIST" -m "$RUNDATE" -cid "$FW_CLIENT_DEFAULT_ID" -of "$FW_HDFS_DIR/$RUNDATE"
    if [ $? -eq 0 ]; then
        all_data_files=$(hdfs dfs -ls "${FW_HDFS_DIR}/${RUNDATE}/${FW_CLIENT_DEFAULT_ID}*fw_audience*/${FW_CLIENT_DEFAULT_ID}*fw_audience*" | awk '{print $8}')
        for dfile in $all_data_files; do                
            copy_to_local "$dfile" "$FW_LOCAL_TMP_DIR"
        done                
        hdfs dfs -touchz "$FW_HDFS_DIR/fw_flag_${RUNDATE}" && echo "Created flag file in HDFS: $FW_HDFS_DIR/fw_flag_${RUNDATE}"
    else
        echo "Freewheel Data generation process failed, will not move the file to sts data path"
        return 1
    fi
}


# This function checks the status of Freewheel metadata files
# if metadata files have been sent today and if the response files have been received it will set the data_flag to 0
# if its running for the first time it will set the data_flag to 0, else if there is mismatch in counts then data_flag will be set to 1
get_freewheel_metadata_status() {
    echo "Checking Freewheel metadata status for $RUNDATE"
    # Check if metadata files have been sent today
    if check_hdfs_file_exists "$FW_HDFS_DIR/$RUNDATE"; then
        sent_metafiles=($(hdfs dfs -ls "$FW_HDFS_DIR/$RUNDATE" | awk '/fw_taxonomy/ {print $8}'))
    else
        sent_metafiles=()
    fi
    
    # Check if metadata response file has been received today
    if [ -d "$FW_LOCAL_RESP_DIR" ]; then
        received_metafiles=($(ls "$FW_LOCAL_RESP_DIR"/*fw_taxonomy* 2>/dev/null))
    else
        received_metafiles=()
    fi
    
    # Log the counts of sent and received files
    echo "Sent metadata files: ${#sent_metafiles[@]}"
    echo "Received metadata files: ${#received_metafiles[@]}"
    
    # check if sent_metafiles count is same as received metafiles
    if  [ ${#sent_metafiles[@]} -ne 0 ] && [ ${#sent_metafiles[@]} -eq ${#received_metafiles[@]} ]
    then
        data_flag=0
        echo "Metadata files count match, Freewheel data process can be triggered on $RUNDATE at $CURRENT_HOUR"
    elif [ ${#sent_metafiles[@]} -eq 0 ]
    then
        data_flag=0
        echo "No metadata files sent to client, other conditions can be checked"
    else        
        echo "Metadata files count mismatch, Freewheel data process can't be triggered on $RUNDATE at $CURRENT_HOUR"
        for metafile in "${sent_metafiles[@]}"; do
            local_file="$FW_LOCAL_RESP_DIR/$(basename "$metafile")"
            if [[ ! -f "$local_file" ]]; then
                echo "Missing file: $local_file"                
            fi
        done
        data_flag=1
    fi
}


# This function checks for the flag file in HDFS directory and sets the flag_date_ts variable
# if the flag file exists it will set the flag_date_ts to the timestamp of the flag file such that the difference in days can be calculated
# else it will set the flag_date_ts to the rundate timestamp 
get_freewheel_flag_date() {
    echo "Checking for flag file in HDFS directory: $FW_HDFS_DIR"

    ## check if flag file exists in hdfs path
    flag_file=$(hdfs dfs -ls "$FW_HDFS_DIR" | awk '/fw_flag/ {print $8}' | sort | tail -n 1)
    if [ -n "$flag_file" ]
    then
        echo "Flag file found: $flag_file"
        flag_date=$(basename "$flag_file" | awk -F'_' '{print $3}')
        flag_date_ts=$(date -d "$flag_date" +%s)        
    else
        echo "Flag file not found in HDFS directory: $FW_HDFS_DIR"
        flag_date=''
        if [ $data_flag -eq 0 ] && [ ${#sent_metafiles[@]} -ne 0 ]
        then
            flag_date_ts=0
            echo "Metafiles exist but flag file doesn't, we can run for first time"
        else            
            flag_date_ts=$rundate_ts
            echo "No metadata files found in local directory and no flag file, no need to run data process"
            return 1
        fi              
    fi    
}


# This function checks if the Freewheel data process can run based on the flag file and metadata status
# it will check if the time difference between the flag file date and the current run date is greater
# than or equal to 14 days and if the data_flag is set to 0.
check_if_data_can_run() {
    echo "Initializing Freewheel data process checks..."

    mkdir -p "$FW_LOCAL_TMP_DIR" && echo "created local directory: $FW_LOCAL_TMP_DIR"
    
    # initialising variables
    flag_date_ts=0
    data_flag=1

    # Trigger metadata generation process
    if ! trigger_freewheel_metadata_generation; then
        echo "Metadata generation process failed. Exiting."
        return 1
    fi

    # Check metadata status
    if ! get_freewheel_metadata_status; then
        echo "Metadata status check failed. Exiting."
        return 1
    fi

    # Check for flag file and calculate time difference
    if ! get_freewheel_flag_date; then
        echo "Flag file check failed. Exiting."
        return 1
    fi

    rundate_ts=$(date -d "$RUNDATE" +%s)
    time_diff=$(( ($rundate_ts - $flag_date_ts) / 86400 ))
    echo "Time difference in days: $time_diff"

    # Determine if data generation can proceed
    if [ $time_diff -ge 14 ] && [ $data_flag -eq 0 ]
    then
        echo "Data generation process can be triggered on $RUNDATE at $CURRENT_HOUR"        
    else
        echo "Data generation process cannot proceed. Time difference is less than or equal to 14 days."        
        return 1
    fi
}


# This function generates the Freewheel trigger file based on the local temp directory files
# it will create a trigger file with the format: {clientid}_{idtype}_{logic}_{date}_{filename}
trigger_freewheel_trigger_generation() {

    echo "Generating Freewheel trigger file"

    STS_DATE=$(date +%Y-%m-%d)

    for type in ip ipv6; do
        echo doing type $type
        # remove existing trigger file

        if [ "$(ls $FW_LOCAL_TMP_DIR/*$type*trigger*)" ]; then
            rm $FW_LOCAL_TMP_DIR/*$type*trigger*
            echo "old trigger removed"
        fi

        #create new trigger file ..
        ls $FW_LOCAL_TMP_DIR | grep __${type}__ | while read f; do
            echo "Processing file: $f"
            echo $FW_FINAL_LOCATION | \
            sed s"/{clientid}/${FW_CLIENT_DEFAULT_ID}/" | \
            sed s"/{idtype}/${type}/" | \
            sed s"/{logic}/${FW_AUD_DEFAULT_LOGIC}/" | \
            sed s"/{date}/${STS_DATE}/" | \
            sed s"/{filename}/${f}/" | \
            sed s"/[^\/]*__//" >> $(echo $FW_LOCAL_TMP_DIR/$FW_AUDIENCE_TRIGGER_FILENAME | \
            sed s"/{clientid}/${FW_CLIENT_DEFAULT_ID}/" | \
            sed s"/{idtype}/${type}/" | \
            sed s"/{logic}/${FW_AUD_DEFAULT_LOGIC}/" ) || echo "Failed to create trigger file for $f"
        done        
        echo "Completed Freewheel trigger generation process"
        echo "Trigger file created in: $FW_LOCAL_TMP_DIR $(ls $FW_LOCAL_TMP_DIR/*$type*trigger*)"
    done
}


# This function triggers the Freewheel data process
# it will check if the data can run and if the trigger generation process is successful
# if successful it will move the taxonomy response files to the backup location
trigger_freewheel_data_process(){
    echo "Starting Freewheel data process..."
    # Check if data process can run
    if ! check_if_data_can_run; then
        echo "Freewheel data generation process cannot be triggered. Exiting silently."
        return 2
    fi

    # Trigger data generation
    if ! trigger_freewheel_data_generation; then
        echo "Freewheel data generation process failed. Exiting."
        return 1
    fi
    
    # Move taxonomy response files if data generation succeeds
    move_file locals "fw_taxonomy" "$FW_LOCAL_RESP_DIR" "$DATA_FROM_STS_BACKUP"
}


# This function moves the Freewheel segment files from local temp directory to the STS directory
send_freewheel_segments() {
    echo "Moving Freewheel segment files to STS directory"

    if [ $CURRENT_HOUR -lt 20 ]
    then
        move_file locals "fw_audience" "$FW_LOCAL_TMP_DIR" "$FW_LOCAL_SEG_DIR"
        set_permissions "$FW_LOCAL_SEG_DIR"
        echo "Segment files moved and permissions set successfully."
        mailx -r mkp_monitor_$HOSTNAME@experian.com -s "$RUNDATE: ***FW - segments moved" $DEVSMAIL <<< "Freewheel segments for $RUNDATE have been moved to $FW_LOCAL_SEG_DIR"
    else
        echo "Current time is greater than 8PM. Exiting."
        return 1
    fi
}


# This function checks if the fw_delivered file exists in HDFS and local sts segment directory is empty
# if so, it will move the trigger file from local temp directory to the local sts segment directory
send_freewheel_trigger(){
    echo "Checking for trigger flag file in HDFS and local segment directory..."
    if check_hdfs_file_exists "$FW_HDFS_DIR/fw_delivered_${RUNDATE}" && [ ! "$(ls -A $FW_LOCAL_SEG_DIR)" ]
    then        
        echo "Delivered flag file found in HDFS directory: $FW_HDFS_DIR and no files in $FW_LOCAL_SEG_DIR"

        move_file locals "experian.trigger" "$FW_LOCAL_TMP_DIR" "$FW_LOCAL_SEG_DIR"
        set_permissions $FW_LOCAL_SEG_DIR
        local MESSAGE="Trigger file moved and permissions set successfully."
        mailx -r mkp_monitor_$HOSTNAME@experian.com -s "$RUNDATE: ***FW - segments moved" $DEVSMAIL <<< "$MESSAGE"
        echo "$MESSAGE"
 
        # Remove the trigger file from HDFS
        hdfs dfs -rm "$FW_HDFS_DIR/fw_delivered_${RUNDATE}" && echo "Removed trigger flag file from HDFS: $FW_HDFS_DIR/fw_delivered_${RUNDATE}"        
    else
        local MESSAGE="fw_delivered_${RUNDATE} flag file not found in $FW_HDFS_DIR or local segment directory is not empty."
        mailx -r mkp_monitor_$HOSTNAME@experian.com -s "$RUNDATE: ***FW - segments moved" $DEVSMAIL <<< "$MESSAGE"
        echo "$MESSAGE"
    fi
    
}


# This function triggers the Freewheel data process
# it will first trigger the data process, then the generation process, and finally send the segments
# if successful it will create the fw_delivered flag file in HDFS
trigger_freewheel_process(){
    echo "Triggering Freewheel process"

    # Trigger data process
    trigger_freewheel_data_process
    local status=$?
    echo "Freewheel trigger_freewheel_process status: $status"
    if [ $status -eq 2 ]; then
        echo "Freewheel data process will not be triggered"
        return 2        
    elif [ $status -eq 1 ]; then
        echo "Alert: Freewheel data process failed. Check logs at ${LOGS_DIR}/mkp-${RUNDATE}.log"
        return 1
    else
        echo "Freewheel data generation completed successfully."
    fi

    # Trigger generation process
    if ! trigger_freewheel_trigger_generation; then
        echo "Freewheel trigger generation process failed. Exiting."
        return 1
    fi

    # Send segments
    if ! send_freewheel_segments; then
        echo "Failed to send Freewheel segments. Exiting."
        return 1
    fi

    # Create flag file in HDFS to show segments have been delivered
    hdfs dfs -touchz "$FW_HDFS_DIR/fw_delivered_${RUNDATE}" && echo "Created flag file in HDFS: $FW_HDFS_DIR/fw_flag_${RUNDATE}"

    echo "Freewheel process completed successfully."
    return 0
}


# This function triggers the entire process
# it will first check if the process can run, then run trigger_freewheel_process
# if successful it will send the trigger file based on conditions and remove the lock file
run_freewheel_trigger(){
    echo "Starting Freewheel trigger process..."

    # Check if the process can run
    if ! can_mkp_process_run "$FW_LOCK_FILE"; then
        echo "Freewheel process is already running on $RUNDATE"
        return 1
    fi

    # Create lock file
    touch "$FW_LOCK_FILE" && echo "Created Freewheel MKP lock file: $FW_LOCK_FILE"

    # Trigger the Freewheel process
    trigger_freewheel_process
    local status=$?
    echo "Freewheel trigger_freewheel_process status: $status"
    if [ $status -eq 2 ]; then
        echo "Freewheel data process cannot be triggered. Exiting silently."
    elif [ $status -eq 1 ]; then
        echo "Alert: Freewheel process failed. Check logs at ${LOGS_DIR}/mkp-${RUNDATE}.log"        
        return 1
    else
        echo "Freewheel data sent, proceeding"
    fi

    # Send Freewheel trigger
    if ! send_freewheel_trigger; then
        echo "Failed to send Freewheel trigger. Exiting."        
        return 1
    fi

    # Remove lock file after successful execution
    rm "$FW_LOCK_FILE" && echo "Removed Freewheel MKP lock file: $FW_LOCK_FILE"

    echo "Freewheel trigger process completed successfully."
}
