#!/bin/bash

source conf.sh
source functions.sh
source triggers/lookup_trigger.sh


CURRENT_HOUR=$(date +%H)
INF_LOCK_FILE="${MKP_LOCK_FILE_DIR}/inf_${RUNDATE}.lock"


send_monthly_infosum_lookup(){
    echo "Running Infosum Lookup file creation for $RUNDATE"
    #check if today is 1st of the month
    if [ $DATEPART == 1 ] && [ $CURRENT_HOUR == "15" ];
    then
        latest_infosum_lookup=$(find_latest_file_in_hdfs "${LOOKUP_HDFS_DIR}/infosum" "cbk_hh_lookup_infosum")        
        if [ $? -eq 0 ]; then
            in_file_name=$(basename "$latest_infosum_lookup")
            out_file_name="${in_file_name%.*}.csv"
            spark-submit --master yarn --queue $QUEUE1 "${INF_SCRIPT_DIR}/inf00_convert_lookup.py" -m $RUNDATE -ifp $latest_infosum_lookup -ofp $INF_TEMP_LOCAL_PATH/$out_file_name -et $MAILLIST
            if [ $? -eq 0 ]; then
                sleep 60s
                move_file locals "cbk_hh_lookup_infosum" $INF_TEMP_LOCAL_PATH $CD_TEAM_PATH
                set_permissions $CD_TEAM_PATH
                echo "Sent Infosum CBK-Matchid Lookup for CD team on $RUNDATE"
            else
                echo "Error converting Infosum Lookup for CD team on $RUNDATE at $CURRENT_HOUR"                
            fi            
        fi
    else
        echo "Infosum Lookup can't be converted on $RUNDATE at $CURRENT_HOUR"
    fi    
}


trigger_infosum_process() {
    send_monthly_infosum_lookup
    if [ $RUNDATE == $SUN_DATE ] && [ $CURRENT_HOUR == "07" ];
    then
        echo "Triggering Infosum process"
        touch "${MKP_LOCK_FILE_DIR}/inf_${RUNDATE}.lock" && echo "created mkp lock file"
        trigger_client_lookup_generation "infosum"
        spark-submit --master yarn --queue $QUEUE1 "${INF_SCRIPT_DIR}/inf01_generate_data.py" -m $RUNDATE -et $MAILLIST
        if [ $? -eq 0 ]; then
            hdfs dfs -mkdir -p $INF_MKT_HDFS_DIR/$RUNDATE && echo "created HDFS directory: $INF_MKT_HDFS_DIR/$RUNDATE"
            hdfs dfs -copyToLocal "${INF_MKT_HDFS_DIR}/${RUNDATE}/infosum*/infosum*.csv" $INF_TEMP_LOCAL_PATH && echo "copied file from HDFS to local: $INF_TEMP_LOCAL_PATH"
            move_file locals "infosum" $INF_TEMP_LOCAL_PATH $INF_STS_LOCAL_PATH
            set_permissions $INF_STS_LOCAL_PATH
        else
            echo "Infosum Data generation process failed, will not move the file to sts data path"
            return 1
        fi
        rm "${MKP_LOCK_FILE_DIR}/inf_${RUNDATE}.lock" && echo "removed mkp lock file"
        echo "Infosum process completed"
    else
        echo "Infosum process can't be triggered on $RUNDATE at $CURRENT_HOUR"
    fi
}


run_infosum_trigger(){
    if can_mkp_process_run $INF_LOCK_FILE 
    then
        touch $INF_LOCK_FILE && echo "created infosum mkp lock file"
        trigger_infosum_process
        if [ $? -ne 0 ]; then
            echo "Alert: Infosum process failed with exit status 1, please check logs at ${LOGS_DIR}/mkp-${RUNDATE}.log"
            return 1
        fi
        rm $INF_LOCK_FILE && echo "removed infosum mkp lock file"
    else
        echo "Infosum process is already running on $RUNDATE"
    fi
}