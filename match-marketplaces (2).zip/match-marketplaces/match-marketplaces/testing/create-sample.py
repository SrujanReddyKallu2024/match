# run in repo root
# # docker run -it --rm -v %cd%:/hello -e PYTHONPATH=/hello/marketplaces -w /hello pysparktestboto /opt/spark/bin/spark-submit /hello/testing/create-sample.py

from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("example").getOrCreate()

data = [
    
    {"match_id": -1000000000000000000, "ip": "123.123.123.123", "first_seen": "2024-01-01", "last_seen": "2024-01-20", "source": "chv,uc"},
    {"match_id": -2000000000000000000, "ip": "123.123.123.124", "first_seen": "2024-01-01", "last_seen": "2024-01-20", "source": "chv,ab,cd"},
    {"match_id":  5000000000000000000, "ip": "123.123.123.125", "first_seen": "2024-01-01", "last_seen": "2024-01-20", "source": "uc,a"},
    {"match_id":  5000000000000000000, "ip": "123.123.123.125", "first_seen": "2024-01-01", "last_seen": "2024-01-20", "source": "uc,a"},
    {"match_id":  5000000000000000000, "ip": "123.123.123.125", "first_seen": "2024-01-01", "last_seen": "2024-01-20", "source": "uc,a"},
    {"match_id":  5000000000000000000, "ip": "123.123.123.125", "first_seen": "2024-01-01", "last_seen": "2024-01-20", "source": "uc,a"},
    {"match_id":  5000000000000000000, "ip": "123.123.123.125", "first_seen": "2024-01-01", "last_seen": "2024-01-20", "source": "uc,a"},
    {"match_id":  5000000000000000000, "ip": "123.123.123.125", "first_seen": "2024-01-01", "last_seen": "2024-01-20", "source": "uc,a"},
    {"match_id":  5000000000000000000, "ip": "123.123.123.125", "first_seen": "2024-01-01", "last_seen": "2024-01-20", "source": "uc,a"},
    {"match_id":  5000000000000000000, "ip": "123.123.123.125", "first_seen": "2024-01-01", "last_seen": "2024-01-20", "source": "uc,a"},
    {"match_id":  5000000000000000000, "ip": "123.123.123.125", "first_seen": "2024-01-01", "last_seen": "2024-01-20", "source": "uc"},
    {"match_id": -4000000000000000000, "ip": "123.123.123.126", "first_seen": "2024-01-01", "last_seen": "2024-01-20", "source": "uc"},
    {"match_id": -4000000000000000000, "ip": "123.123.123.126", "first_seen": "2024-01-01", "last_seen": "2024-01-20", "source": "uc"},
    {"match_id": -4000000000000000000, "ip": "123.123.123.126", "first_seen": "2024-01-01", "last_seen": "2024-01-20", "source": "uc"},
    {"match_id": -4000000000000000000, "ip": "123.123.123.126", "first_seen": "2024-01-01", "last_seen": "2024-01-20", "source": "uc"},
    {"match_id": -5000000000000000000, "ip": "123.123.123.126", "first_seen": "2024-01-05", "last_seen": "2024-01-25", "source": "uc"},
    {"match_id": -6000000000000000000, "ip": "123.123.123.126", "first_seen": "2024-01-01", "last_seen": "2024-01-22", "source": "uc,g,u,k"},
    {"match_id": -6000000000000000000, "ip": "10.123.123.126", "first_seen": "2024-01-01", "last_seen": "2024-01-22", "source": "uc,g,u,k"},
    {"match_id": -6000000000000000000, "ip": "fc00:aaaa:aaaa:aaaa:aaaa:aaaa:aaa:aaa", "first_seen": "2024-01-01", "last_seen": "2024-01-22", "source": "uc,g,u,k"},
    {"match_id": -6000000000000000000, "ip": "aaaa:aaaa:aaaa:aaaa:aaaa:aaaa:aaa:aaa", "first_seen": "2024-01-01", "last_seen": "2024-01-22", "source": "uc,g,u,k"},
    {"match_id": -4000000000000000000, "ip": "123.123.123.126", "first_seen": "2024-01-01", "last_seen": "2024-01-20", "source": "uc"},
    {"match_id": -4000000000000000000, "ip": "123.123.123.126", "first_seen": "2024-01-01", "last_seen": "2024-01-20", "source": "uc"},
]

df = spark.createDataFrame(data)
df.repartition(1).write.parquet("testing/data/hdfs/user/unity/id_graph/graphs/ip/ip_202501250925.parquet", mode="overwrite")


data = [
    {"match_id": -1000000000000000000, "cb_key_household": "h1"},
    {"match_id": -2000000000000000000, "cb_key_household": "h2"},
    {"match_id":  5000000000000000000, "cb_key_household": "h3"},
    {"match_id":  5000000000000000000, "cb_key_household": "h4"},
    {"match_id": -4000000000000000000, "cb_key_household": "h5"},
    {"match_id": -5000000000000000000, "cb_key_household": "h6"},
    {"match_id": -6000000000000000000, "cb_key_household": "h7"},
]

df = spark.createDataFrame(data)
df.repartition(1).write.parquet("testing/data/hdfs/user/unity/id_graph/lookup/experian/match_id_lookup_experian_202501250915.parquet" , mode="overwrite")


data = [
    { "cb_key_household": "h1", "S_Code": "S91"},  
    { "cb_key_household": "h1", "S_Code": "S92"},  
    { "cb_key_household": "h1", "S_Code": "S93"},  
    { "cb_key_household": "h1", "S_Code": "S94"},  
    { "cb_key_household": "h2", "S_Code": "S91"},  
    { "cb_key_household": "h3", "S_Code": "S91"},  
    { "cb_key_household": "h3", "S_Code": "S92"},  
    { "cb_key_household": "h3", "S_Code": "S93"},  
    { "cb_key_household": "h4", "S_Code": "S94"},  
    { "cb_key_household": "h4", "S_Code": "S95"},  
    { "cb_key_household": "h4", "S_Code": "S96"},  
    { "cb_key_household": "h5", "S_Code": "S91"},  
    { "cb_key_household": "h5", "S_Code": "S92"},  
    { "cb_key_household": "h5", "S_Code": "S95"},  
    { "cb_key_household": "h5", "S_Code": "S96"},  
    { "cb_key_household": "h6", "S_Code": "S96"},  
    { "cb_key_household": "h6", "S_Code": "S97"},  
    { "cb_key_household": "h6", "S_Code": "S98"},  
    { "cb_key_household": "h7", "S_Code": "S96"},  
    { "cb_key_household": "h7", "S_Code": "S97"},  
    { "cb_key_household": "h7", "S_Code": "S98"},  
]

df = spark.createDataFrame(data)

df.repartition(1).write.parquet("testing/data/hdfs/user/unity/match2/taxonomy/2025-01-15/process/dt_long_cb_key_hh_s.parquet", mode="overwrite")


df_ttddids_graph = spark.createDataFrame([
    {"match_id": "-1000000000000000000", "ttdids": "3cef2d2a-7e0e-46bc-be5c-607e7f813a9f", "type_uid": "TradeDesk", "source": "uc", "diff": 25, "week0": 0, "week1": 0, "week2": 0, "week3": 0, "week4": 1, "date": "2024-10-25"}, 
    {"match_id": "-1000000000000000000", "ttdids": "53129258-f9e5-4d3c-a6f5-15bc51798192", "type_uid": "TradeDesk", "source": "uc", "diff": 20, "week0": 0, "week1": 0, "week2": 0, "week3": 1, "week4": 1, "date": "2024-12-15"}, 
    {"match_id": "-1000000000000000000", "ttdids": "597e4994-a583-4c90-9222-96e580815309", "type_uid": "TradeDesk", "source": "uc", "diff": 22, "week0": 0, "week1": 0, "week2": 0, "week3": 0, "week4": 1, "date": "2024-12-09"}, 
    {"match_id": "-1000000000000000000", "ttdids": "62b41188-2058-433b-a6de-921037d13aab", "type_uid": "TradeDesk", "source": "uc", "diff": 6, "week0": 0, "week1": 1, "week2": 1, "week3": 1, "week4": 1, "date": "2024-12-01"}, 
    {"match_id": "-1000000000000000000", "ttdids": "9d59f12a-43bb-4571-8803-5ad41dad81f3", "type_uid": "TradeDesk", "source": "uc", "diff": 7, "week0": 0, "week1": 1, "week2": 1, "week3": 1, "week4": 1, "date": "2024-11-12"}, 
    {"match_id": "-1000000000000000000", "ttdids": "a1663c51-8bc8-458b-94b0-abf91d92ec21", "type_uid": "TradeDesk", "source": "uc", "diff": 25, "week0": 0, "week1": 0, "week2": 0, "week3": 0, "week4": 1, "date": "2025-01-03"}, 
    {"match_id": "-1000000000000000000", "ttdids": "d660f88f-3997-4f0b-9014-c553e51eea9e", "type_uid": "TradeDesk", "source": "uc", "diff": 26, "week0": 0, "week1": 0, "week2": 0, "week3": 0, "week4": 1, "date": "2024-10-24"},
    {"match_id": "-6000000000000000000", "ttdids": "a58a06c4-5e3a-4762-9583-db8f42ae0abc", "type_uid": "TradeDesk", "source": "de", "diff": 0, "week0": 1, "week1": 3, "week2": 5, "week3": 7, "week4": 8, "date": "2025-01-22"}, 
    {"match_id": "-4000000000000000000", "ttdids": "1f9e2701-74fd-4c16-a6db-f27a171cd8aa", "type_uid": "TradeDesk", "source": "uc", "diff": 0, "week0": 2, "week1": 4, "week2": 6, "week3": 8, "week4": 8, "date": "2024-11-24"}, 
    {"match_id": "-4000000000000000000", "ttdids": "4c885e5f-2bdd-41e1-ad5c-3e9d83573ff6", "type_uid": "TradeDesk", "source": "uc", "diff": 21, "week0": 0, "week1": 0, "week2": 0, "week3": 1, "week4": 1, "date": "2024-11-04"}
])

df_ttddids_graph.repartition(1).write.parquet("testing/data/hdfs/user/unity/id_graph/graphs/ttdids/ttdids_202501250925.parquet", mode="overwrite")



df_maids_graph = spark.createDataFrame([
    {"match_id": "-5000000000000000000", "maids": "36501f1d-e9f2-4aad-a8e7-158543f6487a", "type_uid": "ios", "source": "uc", "diff": 0, "week0": 1, "week1": 3, "week2": 5, "week3": 7, "week4": 9, "date": "2024-10-08"},
    {"match_id": "-5000000000000000000", "maids": "f80528a9-8bac-41ab-b826-a29c720e1a63", "type_uid": "android", "source": "uc", "diff": 9, "week0": 0, "week1": 0, "week2": 1, "week3": 1, "week4": 1, "date": "2024-11-10"}, 
    {"match_id": "-1000000000000000000", "maids": "0effdf73-0d39-4654-a96e-08dbf0a3f90e", "type_uid": "ios", "source": "uc", "diff": 7, "week0": 0, "week1": 1, "week2": 1, "week3": 2, "week4": 2, "date": "2024-09-03"}, 
    {"match_id": "-1000000000000000000", "maids": "33479570-25aa-46c6-9694-ff47dfe8f5c2", "type_uid": "android", "source": "uc", "diff": 2, "week0": 0, "week1": 1, "week2": 1, "week3": 1, "week4": 1, "date": "2024-11-17"}, 
    {"match_id": "-1000000000000000000", "maids": "43270b58-6d8e-417c-9934-dec0e2c99f39", "type_uid": "ios", "source": "uc", "diff": 9, "week0": 0, "week1": 0, "week2": 1, "week3": 1, "week4": 1, "date": "2024-11-10"}, 
    {"match_id": "-1000000000000000000", "maids": "552ff305-de5d-4300-b28d-45ed26b6ab0e", "type_uid": "ios", "source": "uc", "diff": 0, "week0": 1, "week1": 1, "week2": 2, "week3": 2, "week4": 3, "date": "2024-10-03"}, 
    {"match_id": "-1000000000000000000", "maids": "773e3d43-24db-351a-a1f3-1dce8eda899e", "type_uid": "ios", "source": "uc", "diff": 21, "week0": 0, "week1": 0, "week2": 0, "week3": 1, "week4": 1, "date": "2024-09-03"}, 
    {"match_id": "-1000000000000000000", "maids": "98deb1d3-e671-4643-bd14-c502714a6fa9", "type_uid": "android", "source": "uc", "diff": 9, "week0": 0, "week1": 0, "week2": 1, "week3": 1, "week4": 1, "date": "2024-11-10"}, 
    {"match_id": "-1000000000000000000", "maids": "ac966077-d4ec-4cdd-a800-479740bddabf", "type_uid": "ios", "source": "uc", "diff": 9, "week0": 0, "week1": 0, "week2": 1, "week3": 1, "week4": 1, "date": "2024-12-04"}, 
    {"match_id": "-1000000000000000000", "maids": "cd9536fc-c83e-4810-8a1b-3d24432e43a4", "type_uid": "ios", "source": "uc", "diff": 6, "week0": 0, "week1": 1, "week2": 1, "week3": 1, "week4": 1, "date": "2024-11-13"}
])

df_maids_graph.repartition(1).write.parquet("testing/data/hdfs/user/unity/id_graph/graphs/maids/maids_202501250925.parquet", mode="overwrite")



df_uid_graph = spark.createDataFrame([
    {"match_id": "-4000000000000000000", "uid": "ID5-2c0cJzJM7riarr1DdvXva2C0zv0HSMta94PDmb62dg", "source": "chv", "diff": 13, "week0": 0, "week1": 0, "week2": 1, "week3": 1, "week4": 1, "date": "2024-10-27", "week_start": "2024-10-28", "uid_source": "id5"}, 
    {"match_id": "-1000000000000000000", "uid": "ID5-1044rem-nctmv6J9ssuj6O9ANvYlsEKNk8C8Bync3w", "source": "uc", "diff": 3, "week0": 0, "week1": 1, "week2": 1, "week3": 1, "week4": 1, "date": "2024-11-16", "week_start": "2024-12-02", "uid_source": "id5"}, 
    {"match_id": "-1000000000000000000", "uid": "ID5-16f9xI0EfbHArXJf6Y2vCxIQK6Te0PENkp-v10m9zQ", "source": "uc", "diff": 7, "week0": 0, "week1": 3, "week2": 3, "week3": 3, "week4": 3, "date": "2024-12-16", "week_start": "2024-12-30", "uid_source": "id5"}, 
    {"match_id": "-1000000000000000000", "uid": "ID5-1e380-l0fUWIbzdFRYswPXWcykWmzcsbR1yAvnWkzQ", "source": "uc", "diff": 6, "week0": 0, "week1": 1, "week2": 1, "week3": 1, "week4": 1, "date": "2024-11-13", "week_start": "2024-12-16", "uid_source": "id5"}, 
    {"match_id": "-1000000000000000000", "uid": "ID5-62f0QDJ5Cik0pdlv-TtKARoMAsb7X1vnK0BQtnRhUA", "source": "uc", "diff": 20, "week0": 0, "week1": 0, "week2": 0, "week3": 1, "week4": 1, "date": "2024-09-04", "week_start": "2024-09-30", "uid_source": "id5"}, 
    {"match_id": "-1000000000000000000", "uid": "ID5-67f5doK_GkdBp4hWeTcLLWwER4I_baZW0pMEH7f1hQ", "source": "uc", "diff": 5, "week0": 0, "week1": 1, "week2": 1, "week3": 1, "week4": 1, "date": "2024-11-23", "week_start": "2024-12-02", "uid_source": "id5"}, 
    {"match_id": "-1000000000000000000", "uid": "ID5-67fcZNeIqg-ho5BbyWfidQEy_olvg6HmU-KsFEz7KA", "source": "uc", "diff": 19, "week0": 0, "week1": 0, "week2": 0, "week3": 1, "week4": 1, "date": "2024-10-31", "week_start": "2024-11-04", "uid_source": "id5"}, 
    {"match_id": "-1000000000000000000", "uid": "ID5-72e4USy4S_nUuvNPKG9WcRf-1mvjPvoHRJE1irkF9g", "source": "uc", "diff": 21, "week0": 0, "week1": 0, "week2": 0, "week3": 1, "week4": 1, "date": "2024-10-29", "week_start": "2024-11-04", "uid_source": "id5"}, 
    {"match_id": "-1000000000000000000", "uid": "ID5-890dS9_SND9frA5k1vt0lY5gz97OqBDV00kBhwit6Q", "source": "uc", "diff": 14, "week0": 0, "week1": 0, "week2": 1, "week3": 2, "week4": 2, "date": "2024-10-14", "week_start": "2024-10-14", "uid_source": "id5"}, 
    {"match_id": "-1000000000000000000", "uid": "ID5-8ec8NYfwZNVItFNZ-mmPH0SgCrnd1L1pHVY__rNbhw", "source": "uc", "diff": 22, "week0": 0, "week1": 0, "week2": 0, "week3": 0, "week4": 1, "date": "2024-12-17", "week_start": "2024-12-16", "uid_source": "id5"}
])

df_uid_graph.repartition(1).write.parquet("testing/data/hdfs/user/unity/id_graph/graphs/uid/uid_202501250925.parquet", mode="overwrite")
