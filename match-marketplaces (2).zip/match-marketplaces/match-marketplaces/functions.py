import os
import subprocess
import re
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib
from datetime import datetime
import sys
import glob
import pyspark.sql.functions as F
import time
import inspect
import logging

from config import EMAIL_TO, STATUS_EMOJIS

def whose_log():
    stack = inspect.stack()
    if len(stack) > 2:
        name =  os.path.basename(stack[-1].filename)
        return name

logger = logging.getLogger(whose_log())

class Platform:
    """
    Class to determine the platform the code is running on.
    """
    def __init__(self):
        import os
        self.is_docker = ".dockerenv" in os.listdir("/") or "entrypoint.sh" in os.listdir("/opt")
        self.is_linux =  "linux" in sys.platform
        self.is_windows =  "win" in sys.platform
        if self.is_docker:
            self.platform = "docker"
        elif self.is_linux:
            self.platform = "linux"
        elif self.is_windows:
            self.platform = "windows"
        else:
            self.platform = "unknown"

        try:
            subprocess.check_call(["hdfs", "dfs", "-ls"])
            self.is_hdfs = True
        except:
            self.is_hdfs = False

        self.is_local = True if self.is_windows or self.is_docker else False
        logger.info(f"platform: {self.platform}")

platform = Platform()

def latest_hdfs_file(path, pattern=''):
    '''
    Finds latest file or directory.
    pattern is the file name before the data.
    Must be a full hdfs path.
    '''
    import subprocess
    import re
    files = subprocess.check_output(f'hdfs dfs -ls {path}', shell=True)
    logger.info(f"finding latest file in: {path} with pattern: {pattern}, found {files}")
    x= [re.search(' (/.+)', i).group(1) for i in str(files).split("\\n") if re.search(' (/.+)', i)]
    lenx= len(pattern)
    y= [x1 for x1 in x if os.path.split(x1)[1][0:lenx]==pattern]
    y= sorted(y)
    dirx= y[-1]
    logger.info(f"latest file: {dirx}")
    return dirx


def list_files(path, pattern='', islocal=False):
    '''
    Finds latest file or directory.
    pattern is the file name before the data.
    '''
    import subprocess
    import re
    if not islocal:
        files = subprocess.check_output(f'hdfs dfs -ls {path}', shell=True)
    else:
        files = subprocess.check_output(f'ls -l {path}', shell=True)
    x= [re.search(' (/.+)', i).group(1) for i in str(files).split("\\n") if re.search(' (/.+)', i)]
    lenx= len(pattern)
    y= [x1 for x1 in x if os.path.split(x1)[1][0:lenx]==pattern]
    y= sorted(y)
    return y


def get_greeting():
    """
    gets the greeting based on time of day
    """
    now_time = datetime.now()
    if (now_time.hour>=12) & (now_time.hour<17):
        return "Good afternoon,"
    elif (now_time.hour>=17):
        return "Good evening,"
    else:
        return "Good morning,"


def send_status_email(email_subject, body, email_to=EMAIL_TO):
    """
    email format for simple text body
    """
    # email variables
    greeting = get_greeting()
    EMAIL_FROM = 'marketplace_monitor@experian.com'
    MESSAGE_BODY = f"{greeting} \n\n{body} \n\nThanks and Regards\nExperian Match Team"
    SMTP_SERVER = "relay.uk.experian.local"
    msg = MIMEMultipart()
    body_part = MIMEText(MESSAGE_BODY, 'plain')
    msg['Subject'] = email_subject
    msg['From'] = EMAIL_FROM
    msg['To'] = email_to
    # Add body to email
    msg.attach(body_part)
    smtp = smtplib.SMTP(SMTP_SERVER)
    logger.info(f"Sending email to: {email_to}")
    smtp.sendmail(EMAIL_FROM, email_to.split(","), msg.as_string())
    smtp.quit()


def latest_local_file(path, pattern='', dateformat=r'%Y%m%d', isdir=False):
    """
    Finds the latest file having given date format in the name in the local directory.
    pattern is the file name before the date.
    """
    logger.info(f"finding latest file in: {path} with pattern: {pattern} acting as directory: {isdir}")
    allfiles = [
        os.path.join(path, i) for i in os.listdir(path)
        if (not isdir and os.path.isfile(os.path.join(path, i)) or isdir) and pattern in i
    ]
    if len(allfiles) == 0:
        logger.error(f"no files found in: {path} with pattern: {pattern}")
        return

    latest_file = sorted(
        allfiles,
        key=lambda x: datetime.strptime(os.path.basename(x).split('_')[-1].split('.')[0], dateformat),
        reverse=True
    )[0]
    return latest_file


def get_all_files(folderpath, file_pattern=False, islocal=False, exclude_pattern=["_SUCCESS"]):
    """
    Outputs a list of all files in a folder on HDFS or local based on the file pattern (if provided)
    """
    if platform.is_hdfs and (not islocal):
        hdfs_command = ["hdfs", "dfs", "-ls", folderpath]
        proc = subprocess.run(hdfs_command, capture_output=True, text=True)
        all_files = [line.split()[7] for line in proc.stdout.splitlines() if line and 'Picked' not in line and len(line.split()) > 7]
    else:
        all_files = glob.glob(os.path.join(folderpath, "*"))
    # check for file pattern
    if file_pattern:
        return [f for f in all_files if file_pattern in f]
    # exclude pattern
    if exclude_pattern:
        return [f for f in all_files if not any([e in f for e in exclude_pattern])]
    return all_files


def rename_files(logger, mask, all_files, graph_type, new_name_template=f"UK__experianuk_{{graph_type}}_UK_{{mask}}_{{partname}}.csv.gz", part_offset=0):
    """
    Renames part files
    """
    logger.info(f"renaming files for {graph_type} and {mask} with template {new_name_template}")
    logger.info(f"preview: {new_name_template.format(graph_type=graph_type, mask=mask, partname='partname')}")
    try:
        for i, filename in enumerate(all_files):
            dir_name = os.path.dirname(filename)
            if graph_type == 'meta':
                partname = str(int(round(1000*time.time(),0)))
            else:
                partname = str(i+1+part_offset).zfill(3)
            # new_name = f"{dir_name}/UK__experianuk_{graph_type}_UK_{mask}_{partname}.csv.gz"
            new_filename = new_name_template.format(
                graph_type=graph_type,
                mask=mask,
                partname=partname
            )
            new_name = os.path.join(dir_name, new_filename)
            ##i f sys.platform[:3]!="win":
            if platform.is_hdfs:
                cmd = ["hdfs", "dfs", "-mv", filename, new_name]
                proc = subprocess.run(cmd, capture_output=True, text=True)
                if proc.returncode != 0:
                    logger.error(f"failed to rename file: {filename}")
                    raise Exception(f"failed to rename file: {filename}")
            else:
                os.rename(filename, new_name)
            logger.info(f"renamed file: {filename} to {new_name}")
    except:
        logger.exception(f"failed to rename files for {graph_type}")
        raise


def add_dummy_column(df, columnlist, arrcol=False):
    """
    Add a dummy static or array column if it isn't present in the incoming df
    """
    if isinstance(columnlist,list):
        columnlist = columnlist
    else:
        columnlist = columnlist.split()

    for i in columnlist:
        if not i in df.columns:
            if arrcol == False:
                df = df.withColumn(i, F.lit(''))
            else:
                df = df.withColumn(i, F.array(F.lit('')))
    return df


def update_stats(stats, milestone, status="success", message=""):
    """
    Update the stats dictionary with the milestone, status and message
    """
    stats.append({
        "Time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "Milestone": milestone,
        "Message": message,
        "Status": STATUS_EMOJIS['green'] if status.lower()=="success" else STATUS_EMOJIS['red']
    })


def send_teams_email(mask, email_subject, body, email_to=EMAIL_TO, swap_newlines=True):
    """
    email formatted for both stats and alerts
    """
    # email variables
    EMAIL_FROM = 'mkp_monitor@experian.com'
    EMAIL_CC = ''
    SMTP_SERVER = "relay.uk.experian.local"
    msg = MIMEMultipart('alternative')
    if body==False:
        body = "No stats generated, please check logs."
    if swap_newlines:
        body = body.replace("\\n","<br>")

    msg_body = f"""\
        <!DOCTYPE html>
        <html>
          <head></head>
          <body>
            <div style="text-align: center;"><b>{email_subject}</b></div>
            <br>
            <br>
            {body}
            <br>
            <p style='margin-bottom:0;'>Thanks and regards</p>
            <p style="margin : 0; padding-top:0;">Experian Match Team</p>
          </body>
        </html>
    """
    body_part = MIMEText(msg_body, 'html')
    msg['Subject'] = mask + ": " + email_subject
    msg['From'] = EMAIL_FROM
    msg['To'] = email_to
    msg.attach(body_part)
    smtp = smtplib.SMTP(SMTP_SERVER)
    logger.info(f"Sending teams email to: {email_to}")
    smtp.sendmail(EMAIL_FROM, email_to.split(","), msg.as_string())
    smtp.quit()


def local_file_rows(file):
    """
    Counts the number of rows in a local file.
    This function uses subprocess to execute shell commands to count the number of lines in the specified file.
    Args:
        file (str): The path to the file whose rows are to be counted.
    Returns:
        int: The number of rows in the file.
    """
    cat_process = subprocess.Popen(["cat", file], stdout=subprocess.PIPE)
    wc_process = subprocess.Popen(['wc', '-l'], stdin=cat_process.stdout, stdout=subprocess.PIPE)
    cat_process.stdout.close()
    output, _ = wc_process.communicate()
    num = output.decode().strip()
    return int(num)


def add_header_to_local_file(input_file, header, output_file):
    """
    Adds a header to a local file and writes the result to an output file. Note the original file is not deleted.
    Parameters:
    input_file (str): The path to the input file.
    header (str): The header text to be added to the file. Must include any delimiters.
    output_file (str): The path to the output file where the result will be written.
    Returns:
    None
    """

    with open(output_file, 'w') as outfile:
        subprocess.run(['echo', header], stdout=outfile)
        with open(input_file, 'r') as infile:
            subprocess.run(['cat'], stdin=infile, stdout=outfile)


def add_header_to_hdfs_file(header, output_file, compress=False):
    """
    Adds a header to a file in HDFS.
    Parameters:
    header (str): The header text to be added to the file. Must include any delimiters.
    output_file (str): The path to the output file where the result will be written.
    compress (bool): If True, the header will be gzip compressed before being written to the output file.
    Returns:
    None
    """
    # echo hello | gzip - | hdfs dfs -put - writetemp/robin/_header2.gzip
    hdfs_command = f"echo '{header}' | hdfs dfs -put - {output_file}"
    if compress:
        hdfs_command = f"echo '{header}' | gzip - | hdfs dfs -put - {output_file}.gzip"
    subprocess.run(hdfs_command, shell=True, check=True)


def merge_files(hdfs_path, local_path, is_hdfs=True):
    """
    Merges part files into a single file in HDFS and copies the result to a local directory.
    """
    if is_hdfs:
        hdfs_cmd = ["hdfs", "dfs", "-getmerge", hdfs_path, local_path]
        subprocess.run(hdfs_cmd, capture_output=True, text=True)
    else:
        cat_cmd = ["cat"]+[f"{hdfs_path}/{f}" for f in os.listdir(hdfs_path) if f.startswith("part")]
        with open(local_path, 'w') as outfile:
            subprocess.run(cat_cmd, stdout=outfile)


def logdf(df, limit=15):
    """
    Log the contents of a DataFrame up to a specified limit.

    Parameters:
    df (DataFrame): The DataFrame to log.
    limit (int): The number of rows to log from the DataFrame.
    """
    import inspect

    frame = inspect.currentframe().f_back
    dfname = [k for k, v in frame.f_locals.items() if v is df][0]
    logger.info(f"df: {dfname}")
    dff = df.limit(limit).collect()
    data_dict = [r.asDict() for r in dff]
    if len(data_dict) == 0:
        logger.warning("empty! with columns %s", ",".join(df.columns))
        return
    headers = list(data_dict[0].keys())
    rows = [headers]
    rows.append(["-" for h in headers])
    for item in data_dict:
        row = [str(item.get(header, "")) for header in headers]
        rows.append(row)
    for row in rows:
        logger.debug("| %s |", " | ".join(row))
    logger.debug(f"{dfname} = spark.createDataFrame({str(data_dict)})")


def add_ip_type_column(df, ip_col='ip'):
    """
    Checks if each row in a column is an IP address, and returns the IP address type (IPv4 or IPv6).
    The result is outputted to a new column called 'ip_type'.

        Parameters:
            df (dataframe): Spark DataFrame with IP address column
            ip_col (str): The name of the IP address column.  Default = "ip"

            Returns:
            df (dataframe): Spark DataFrame with an additional column "ip_type" to denote the IP type (ipv4, ipv6 or invalid_ip)
    """
    # Import libraries
    import ipaddress
    from pyspark.sql.types import StringType
    import pyspark.sql.functions as F
    #
    def ip_type(ip):
        """
        Checks what the IP type is of a given IP address.
        Parameters:
            ip (str) : The IP address

        Returns:
            ip_type (str) : The IP type ("ipv4", "ipv6" or "invalid_ip")
        """
        cidr_blocks = ([
            "0.0.0.0/8",
            "10.0.0.0/8",
            "100.64.0.0/10",
            "127.0.0.0/8",
            "169.254.0.0/16",
            "172.16.0.0/12",
            "192.0.0.0/24",
            "192.0.0.0/29",
            "192.0.0.8/32",
            "192.0.0.9/32",
            "192.0.0.170/32",
            "192.0.0.171/32",
            "192.0.2.0/24",
            "192.31.196.0/24",
            "192.52.193.0/24",
            "192.88.99.0/24",
            "192.168.0.0/16",
            "192.175.48.0/24",
            "198.18.0.0/15",
            "198.51.100.0/24",
            "203.0.113.0/24",
            "240.0.0.0/4",
            "255.255.255.255/32",
        ])
        cidr_blocks_6 = ([
            "fc00::/7",
        ])
        # Check if IPv4
        try:
            ip_test = ipaddress.IPv4Address(ip)
            is_in_cidr = any(ip_test in ipaddress.ip_network(cidr, strict=False) for cidr in cidr_blocks)
            if is_in_cidr: return "ipv4_private"
            else: return "ipv4"
        except:
            # Check if IPv6
            try:
                ip_test = ipaddress.IPv6Address(ip)
                is_in_cidr = any(ip_test in ipaddress.ip_network(cidr, strict=False) for cidr in cidr_blocks_6)
                if is_in_cidr: return "ipv6_private"
                else: return "ipv6"
            except:
                return "invalid_ip"
    #
    # create UDF function
    udf_ip_type = F.udf(lambda x: ip_type(x), StringType())
    #
    return df.withColumn('ip_type', udf_ip_type(F.col(ip_col)))

def writetemp(spark, df, name, mode="overwrite", partitionBy=None):
    """
    Write a temporary file
    """
    import os
    temp_path = os.path.join("writetemp", name)
    if partitionBy:
        df.write.partitionBy(partitionBy).mode(mode).parquet(temp_path)
    else:
        df.write.mode(mode).parquet(temp_path)

    return spark.read.parquet(temp_path)

