"""
Script Name: idg_hems_p10_ingest_emr.py
Description: EMR-compatible version of idg_hems_p10_ingest for processing HEMS data.
             This version is designed to run with S3 paths via EMR Serverless.
Date: May 29, 2025
"""

# ----------------------------------------------------------------------
# STANDARD IMPORTS
# ----------------------------------------------------------------------

import os
import sys
import datetime
import argparse
import logging
from typing import Dict
from pyspark.sql import SparkSession, DataFrame
import pyspark.sql.functions as F
from timeit import default_timer as timer

# Configure root logger so that logs from all modules are printed.
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

# Import shared functions (their loggers will now inherit this configuration)
from shared.functions import (
    ProcessTracker, stats_prev_load, quick_stats_backup, quick_stats,
    nmr_apply, cip_apply, save_formatted_report, result_files
)

# Use the module logger
logger = logging.getLogger(__name__)

# ----------------------------------------------------------------------
# SCRIPT CONFIGURATION
# ----------------------------------------------------------------------

SCRIPT_CODE = "ID010"

# ----------------------------------------------------------------------
# HELPER FUNCTIONS
# ----------------------------------------------------------------------

def quick_stats_definitions(df1: DataFrame, df2: DataFrame, df3: DataFrame) -> Dict:
    """Define and calculate statistics from the dataframes."""
    stats = {}
    stats["1"] = df1.count()
    stats["2"] = df1.select("cb_key_household").distinct().count()
    stats["3"] = df1.select("email_address").distinct().count()
    stats["4"] = df2.select("email_clean").distinct().count()
    stats["5"] = df3.select("hems").distinct().count()
    stats["6"] = df3.count()
    return stats

def current_month():
    """Return the current month in YYYYMM format."""
    return datetime.datetime.now().strftime("%Y%m")

# ----------------------------------------------------------------------
# ARGUMENT PARSING
# ----------------------------------------------------------------------

def create_parser():
    """Create argument parser for the script."""
    parser = argparse.ArgumentParser(description="Process HEMS data for EMR")
    
    parser.add_argument("--input_path", type=str, required=True, 
                      help="Path to HEMS input data (f15_email_{date}.csv.gz)")
    parser.add_argument("--temp_output_path", type=str, required=True,
                      help="Path for temporary output")
    parser.add_argument("--final_output_path", type=str, required=True,
                      help="Path for final f15 output")
    parser.add_argument("--sha256_output_path", type=str, required=True,
                      help="Path for final f15_sha256 output")
    parser.add_argument("--prev_stats_path", type=str, required=False,
                      help="Path for loading previous statistics")
    parser.add_argument("--current_stats_path", type=str, required=True,
                      help="Path for saving current statistics")
    parser.add_argument("--formatted_stats_path", type=str, required=False,
                      help="Path for saving formatted statistics report")
    parser.add_argument("--month", type=str, required=True,
                      help="Month in YYYYMM format")
    
    return parser

# ----------------------------------------------------------------------
# PATH CONFIGURATION
# ----------------------------------------------------------------------

def get_paths(args: argparse.Namespace) -> Dict[str, str]:
    """Configure all paths needed for the process."""
    # Map paths to the original dictionary structure
    paths = {
        "hm_in1": args.input_path,
        "hm_out1": args.temp_output_path,
        "hm_out2": args.final_output_path,
        "hm_out3": args.sha256_output_path,
        "prev_stats": args.prev_stats_path if hasattr(args, 'prev_stats_path') else None,
        "current_stats": args.current_stats_path
    }
    
    # Add formatted_stats path if provided
    if hasattr(args, 'formatted_stats_path') and args.formatted_stats_path:
        paths["formatted_stats"] = args.formatted_stats_path
    
    return paths

# ----------------------------------------------------------------------
# MAIN PROCESSING FUNCTION
# ----------------------------------------------------------------------

def process_data(spark, paths, proc, month):
    """
    Main data processing logic following the pattern of the original script.
    """
    # Process start time for tracking
    start_all = timer()
    
    # Track dataframes for stats collection
    dataframes = {}
    process_health = []
    process_success = {1: False, 2: False, 3: False, 4: False, 5: False}
    
    # Initialize result storage
    result = result_files(paths, "--- FILES ----------------------------------------------")
    result = f"{result}\n\n--- PROCESS HEALTH ---------------------------------"
    
    try:
        # Process 1: Read files/Write Files
        try:
            with ProcessTracker(1, proc):
                logger.info(f"Reading HEMS data from {paths['hm_in1']}")
                hm01 = spark.read.csv(paths["hm_in1"], header=True)
                logger.info(f"HEMS data: {hm01.count():,} rows")
                
                # Write to temp location
                logger.info(f"Writing temporary data to {paths['hm_out1']}")
                hm01.write.parquet(paths["hm_out1"], mode="overwrite")
                
                # Write to final location
                temp = spark.read.parquet(paths["hm_out1"])
                logger.info(f"Writing to final data location {paths['hm_out2']}")
                temp.write.parquet(paths["hm_out2"], mode="overwrite")
                
                # Remove temp files in S3
                logger.info(f"Removing temporary files at {paths['hm_out1']}")
                
                # Read back from final location
                hm02 = spark.read.parquet(paths["hm_out2"])
                logger.info(f"Read back data: {hm02.count():,} rows")
                
                # Store dataframe for stats
                dataframes["hm02"] = hm02
                process_success[1] = True
        except Exception as e:
            logger.error(f"Process 1 failed: {str(e)}")
        finally:
            process_health.append(f"{'✅' if process_success[1] else '❌'} {proc[1]}")
        
        # Process 2: Clean emails
        try:
            with ProcessTracker(2, proc):
                logger.info("Cleaning email addresses")
                hm03 = hm02.select("cb_key_household", "email_address", "best_email_address")
                
                # Remove spaces
                logger.info("Removing spaces from email addresses")
                hm04 = hm03.withColumn("email_clean", F.regexp_replace(F.col("email_address"), " ", ""))
                
                # Lowercase
                logger.info("Converting emails to lowercase")
                hm05 = hm04.withColumn("email_clean", F.lower(F.col("email_clean")))
                process_success[2] = True
        except Exception as e:
            logger.error(f"Process 2 failed: {str(e)}")
        finally:
            process_health.append(f"{'✅' if process_success[2] else '❌'} {proc[2]}")
        
        # Process 3: Dedup
        try:
            with ProcessTracker(3, proc):
                logger.info("Deduplicating by household and email")
                hm06 = hm05.groupby("cb_key_household", "email_clean").count().drop("count")
                logger.info(f"After deduplication: {hm06.count():,} rows")
                
                # Store dataframe for stats
                dataframes["hm06"] = hm06
                process_success[3] = True
        except Exception as e:
            logger.error(f"Process 3 failed: {str(e)}")
        finally:
            process_health.append(f"{'✅' if process_success[3] else '❌'} {proc[3]}")
        
        # Process 4: Apply sha256
        try:
            with ProcessTracker(4, proc):
                logger.info("Applying SHA256 to email addresses")
                hm07 = hm06.withColumn("hems", F.sha2(F.col("email_clean"), 256))
                hm08 = hm07.select("cb_key_household", "hems")
                process_success[4] = True
        except Exception as e:
            logger.error(f"Process 4 failed: {str(e)}")
        finally:
            process_health.append(f"{'✅' if process_success[4] else '❌'} {proc[4]}")
        
        # Process 5: Write to output
        try:
            with ProcessTracker(5, proc):
                logger.info(f"Writing final SHA256 output to {paths['hm_out3']}")
                hm08.write.parquet(paths["hm_out3"], mode="overwrite")
                
                hm09 = spark.read.parquet(paths["hm_out3"])
                logger.info(f"Final output: {hm09.count():,} rows")
                
                # Store dataframe for stats
                dataframes["hm09"] = hm09
                process_success[5] = True
        except Exception as e:
            logger.error(f"Process 5 failed: {str(e)}")
        finally:
            process_health.append(f"{'✅' if process_success[5] else '❌'} {proc[5]}")
         
        # QUICK STATS
        try:
            # Add process health to result
            result += "\n"
            for status in process_health:
                result += f"\n{status}"
                
            # Add quick stats section
            result += f"\n\n--- QUICK STATS --------------------------------------"
            
            # Loads stats from previous run
            logger.info(f"Loading previous stats from: {paths['prev_stats']}")
            stats_prev = stats_prev_load(paths["prev_stats"], SCRIPT_CODE, month, spark)
            logger.info(f"Found {len(stats_prev)} previous stats")
            
            # Define stats names for readability
            stats_name = {
                "1": "Number of rows:",
                "2": "Number of HHs",
                "3": "Number of emails",
                "4": "Number of cleaned emails",
                "5": "Number of HEMS",
                "6": "Number of rows in deduped output"
            }
            
            # Use function to create this weeks stats
            stats = quick_stats_definitions(dataframes["hm02"], dataframes["hm06"], dataframes["hm09"])
            logger.info(f"Generated {len(stats)} new stats")
            
            # Percentage change
            stats_perc, stats_tl, result = quick_stats(stats, stats_name, stats_prev, result)
        
            
            # 1. Save original key-value stats (unchanged format)
            logger.info(f"Saving current stats to: {paths['current_stats']}")
            quick_stats_backup(paths["current_stats"], SCRIPT_CODE, month, stats, spark)
            
            
            logger.info("Stats saved successfully")
            logger.info("Job completed successfully")


        except Exception as e:
            logger.error(f"Error processing stats: {str(e)}")
            result += f"\n\nError processing stats: ❌ {str(e)}"

        finally:

            end_all = timer()
            time_all = str(datetime.timedelta(seconds=round(end_all - start_all, 0)))

            result += f"\n\n--- TOTAL TIME TAKEN --------------------------------"
            result += f"\n\n🕒 {time_all}"

            if "formatted_stats" in paths:
                logger.info(f"Saving formatted report to: {paths['formatted_stats']}")
                from shared.functions import save_formatted_report
                save_formatted_report(paths["formatted_stats"], result)
            else:
                logger.info("No formatted_stats path provided, skipping formatted report")
            
        
    except Exception as e:
        logging.error(f"Process failed: {str(e)}")
        logging.info("Job failed")
        return result, dataframes.get("hm09", None)

# ----------------------------------------------------------------------
# MAIN FUNCTION
# ----------------------------------------------------------------------

def main():
    """Main entry point for the script."""
    # Process start time for overall timing
    start_all = timer()
    
    # Parse arguments
    parser = create_parser()
    args, unknown = parser.parse_known_args()
    
    if unknown:
        logger.warning(f"Unknown arguments: {unknown}")
    
    # Get paths
    address_dict = get_paths(args)
    
    # Set month if not provided
    month = args.month if args.month else current_month()
    logger.info(f"Using month: {month}")
    
    # Dictionary of Process labels
    proc = {
        1: "Read files/Write Files",
        2: "Clean emails",
        3: "Dedup by HH and email",
        4: "Apply sha256",
        5: "Write to output"
    }
    
    # Initialize Spark Session
    spark = (SparkSession.builder
        .appName("HEMS P10 Ingest")
        .config("spark.some.config", "value")
        .getOrCreate())
    
    spark.sparkContext.setLogLevel("WARN")
    
    logger.info("Starting IDG_HEMS_P10_Ingest job")
    logger.info(f"Input path: {args.input_path}")
    logger.info(f"Output path: {args.sha256_output_path}")
    
    try:
        # Run the main process
        result, _ = process_data(spark, address_dict, proc, month)
        
        # Calculate total time
        end_all = timer()
        time_all = str(datetime.timedelta(seconds=round(end_all - start_all, 0)))
        
        # Add timing to result
        result += f"\n\n--- TOTAL TIME TAKEN --------------------------------"
        result += f"\n\n⏱️ {time_all}"
        
        # Log the results
        logger.info("Job completed successfully in " + time_all)
        
        # Exit successfully
        sys.exit(0)
    except Exception as e:
        # Log the error
        logger.error(f"Process failed: {type(e).__name__}: {str(e)}", exc_info=True)
        # Exit with error
        sys.exit(1)

if __name__ == "__main__":
    main()