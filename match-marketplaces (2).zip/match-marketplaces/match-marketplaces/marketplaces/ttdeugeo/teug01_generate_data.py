import pandas as pd
import sys
from pathlib import Path
import argparse
import os
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from datetime import datetime
import time
import glob

sys.path.append(str(Path(__file__).resolve().parents[2]))

import config
import functions

def format_in_data(df, init_cols):
    """    
    Renames the first few columns to the init columns and filters out non-integer values in 'Radius'
    """
    rename_cols = [f'`{df.columns[r]}` as `{init_cols[r]}`' for r in range(len(init_cols))]
    remaining_cols = [f'`{col}`' for col in df.columns[len(init_cols):]]
    return (
        df
        .selectExpr(rename_cols + remaining_cols)
        .filter(F.col("Radius").cast("int").isNotNull())        
    )


def logic_main(ctx, logger, mask, in_path, out_path, out_local_path, email_to):
    logger.info(f"running teug01_generate_data script for mask: {mask}")
    quick_stats = []

    try:
        startime = datetime.now()
        try:
            input_df = ctx.read.csv(in_path, header=False)
            logger.info(f"read data from {in_path}")           

            # these are the columns we know about and will start the file,
            # the rest of the columns may vary from country to country in name and length
            # the output from Donovan will be a csv with the first 4 columns being
            cols = ["SlNo","Lat","Long","Radius"]
            #functions.logdf(input_df)
            df_formatted = format_in_data(input_df, cols).cache()            
            #functions.logdf(df_formatted)
            logger.info(f"formatted input data, init cols: {','.join(cols)}")
            
            functions.update_stats(quick_stats, "TTD Input Data", "Success", f"Found {input_df.count():,} rows in from Path: {in_path}, filtered out invalids, current count: {df_formatted.count():,} rows")
        except Exception as e:
            functions.update_stats(quick_stats, "TTD Input Data", "Failed", str(e))
            raise
        
        try:
            df_bundled = (
                df_formatted
                .withColumn(
                    "list", F.array([F.array(F.lit(c), F.col(f"`{c}`")) for c in df_formatted.columns[len(cols):]])
                )
                .select(*[f"`{col}`" for col in cols] + ["list"])
            )
            logger.info("bundled up the non-repeating columns into an array called list")
            df_exploded = (
                df_bundled
                .withColumn("exploded", F.explode(F.col("list")))
                .select(*cols, F.col("exploded")[1].alias("audience"))
                .filter(F.col("audience").isNotNull())
            )
            logger.info("exploded list array and filtered out null audiences")

            functions.update_stats(quick_stats, "TTD Apply Filters", "Success", f"Filtered out null audiences, current count: {df_exploded.count():,} rows")            
        except Exception as e:
            functions.update_stats(quick_stats, "TTD Apply Filters", "Failed", str(e))
            raise
            
        try:
            final_df = df_exploded.drop("SlNo").repartition(128,F.col("audience")).dropDuplicates().cache()
            logger.info("dropped SlNo column, repartitioned and dropped duplicates")            

            audiences = [row["audience"] for row in final_df.select("audience").distinct().collect()]
            logger.info(f"final audience count: {len(audiences)}")

            #extract first two letters from DK74,DK174,DK0 etc
            country_code = audiences[0][:2]
            out_path = out_path.format(cc=country_code)

            final_df.write.partitionBy("audience").csv(out_path, header=False, mode="overwrite")
            logger.info(f"written out the final data to {out_path}")

            functions.update_stats(quick_stats, "TTD Output Data", "Success", f"Found {final_df.count():,} rows in output data after dropping duplicates, saved to {out_path}")            
        except Exception as e:
            functions.update_stats(quick_stats, "TTD Output Data", "Failed", str(e))
            raise

        try:
            all_files = []
            for a in audiences:                
                hdfs_file_path = f"{out_path}/audience={a}"
                local_file_path_temp = f"{out_local_path}/tmp/Replace.TTDGEO.{a}.{config.TTD_GEO_DATE_TIME}.csv"
                functions.merge_files(hdfs_file_path, local_file_path_temp)
                logger.info(f"merged files for audience: {a}")

                time.sleep(1)

                local_file_path = f"{out_local_path}/Replace.TTDGEO.{a}.{config.TTD_GEO_DATE_TIME}.csv"
                functions.add_header_to_local_file(local_file_path_temp, "LatDeg,LngDeg,RadMet", local_file_path)
                logger.info(f"added header to local file for audience: {a}")

                all_files.append(1)

            if len(all_files) != len(audiences):
                raise Exception(f"failed to process all audiences, count of files: {len(all_files)} is not equal to audiences: {len(audiences)}")            

            functions.update_stats(quick_stats, "TTD Output Data Files", "Success", f"Processed {len(audiences)} audiences, saved to {out_local_path}")
        except Exception as e:
            functions.update_stats(quick_stats, "TTD Output Data Files", "Failed", str(e))
            raise

        success_flag = True
    except Exception as e:
        logger.error(e)
        success_flag = False
        functions.send_status_email("Error: teug01_generate_data script failed", e, email_to)
        raise
    finally:
        alerts_df = pd.DataFrame(quick_stats)    
        email_sub = f"***TEUG01 - Generate TTD data - {config.STATUS_EMOJIS['green']}***" if success_flag else f"***TEUG01 - Generate TTD data - {config.STATUS_EMOJIS['red']}***"
        functions.send_teams_email(mask, email_sub, alerts_df.to_html(index=False), email_to=email_to)
        endtime = datetime.now()
        logger.info(f"process completed in {str(endtime - startime).split('.')[0]}")


def setup_parser():
    ## Setup Args
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("-m", "--mask", help="date on which process is run in format YYYY-MM-DD", default=config.TODAY_DATE)    
    parser.add_argument("-ip", "--in_path", required=True, help="input file path in HDFS for ttd data provided by bash script")            
    parser.add_argument("-op", "--out_path", help="ttd data partitioned by audience is output to this hdfs file path")
    parser.add_argument("-olp", "--out_local_path", help="ttd data file per audience is saved to this local path", default=config.TTD_GEO_TEMP_LOCAL_PATH)
    parser.add_argument("-et", "--email_to", help="recipients of email alerts", default=config.EMAIL_TO)
    return parser

if __name__ == "__main__":

    parser = setup_parser()
    config_parser = config.setup_parser()
    
    # Manually add each argument from config.py to the main parser
    for action in config_parser._actions:
        parser._add_action(action)  # This adds the arguments from config.py
    
    args, unknown = parser.parse_known_args()

    if len(unknown) > 0:
        raise Exception(f"Unknown arguments passed: {unknown}") 

    args = parser.parse_args()
    if args.out_path is None:
        args.out_path = f"{config.TTD_GEO_PATH_HDFS}/{args.mask}/ttd_{{cc}}__{config.TTD_GEO_DATE_TIME}.csv"

    ## Setup Spark and logging
    name = os.path.basename(__file__)
    logger = config.LogConfig(f"{config.LOGPATH}/{name}_{args.mask}.log").generate_logger(name)
    logger.info(f"running teug01_generate_data script with args: {args}")

    spark = SparkSession.builder.appName(f"{name}_{args.mask}").getOrCreate()

    ## Process starts here
    logic_main(spark, logger, args.mask, args.in_path, args.out_path, args.out_local_path, args.email_to)

# testing command
# note: this runs up to the point of running the getmerge command
# docker run -it --rm -v %cd%:/hello -e PYTHONPATH=/hello/marketplaces -w /hello pysparktestboto /opt/spark/bin/spark-submit /hello/marketplaces/ttdeugeo/teug01_generate_data.py --base_path_hdfs /hello/testing/data/hdfs/user/unity --email_to robin.potter@experian.com -ip /hello/testing/ttd_marketplacefile_dk_2025-02-01.csv
