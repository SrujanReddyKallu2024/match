from pathlib import Path
import sys
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
import argparse
from datetime import datetime
import os
import pandas as pd

sys.path.append(str(Path(__file__).resolve().parents[2]))

from config import TODAY_DATE, LogConfig, LOGPATH, LOOKUP_FILE_PATH, AUD_PATH_HDFS, TAX_PATH, EMAIL_TO, STATUS_EMOJIS
from functions import latest_hdfs_file, send_status_email, update_stats, send_teams_email


def logic_main(ctx, logger, mask, idg_lookup_path, scodes_path, tax_path, out_path, email_to):
    logger.info(f"running aud01 matchid with scodes script for mask: {mask}")
    quick_stats = []

    try:
        startime = datetime.now()

        try:
            aud_lookup_file = latest_hdfs_file(f"{idg_lookup_path}/audigent", pattern = 'match_id_lookup_audigent')
            logger.info(f"audigent lookup file: {aud_lookup_file}")

            aud_lookup = ctx.read.parquet(aud_lookup_file)
            logger.info("read audigent lookup data")

            exp_lookup_file = latest_hdfs_file(f"{idg_lookup_path}/experian", pattern = 'match_id_lookup_experian')
            logger.info(f"experian lookup file: {exp_lookup_file}")

            exp_lookup = ctx.read.parquet(exp_lookup_file)
            logger.info("read experian lookup data")

            lookup_init = exp_lookup.join(aud_lookup, 'match_id', 'inner')
            logger.info("joined audigent and experian lookup data")

            lookup = lookup_init.select('cb_key_household', 'match_id_audigent')
            logger.info("selected required columns from lookup data")

            update_stats(
                quick_stats, "Audigent MatchIds", "Success", 
                f"Latest Audigent Lookup: {aud_lookup_file} with {aud_lookup.count():,} matchids; Latest Experian lookup: {exp_lookup_file} with {exp_lookup.count():,} matchids; Found {lookup.count():,} MatchId-CBKey Records"
            )
        except Exception as e:
            update_stats(quick_stats, "Audigent MatchIds", "Failed", str(e))
            raise

        try:
            latest_scodes_file = latest_hdfs_file(scodes_path, pattern='metadata')
            logger.info(f"latest scodes file: {latest_scodes_file}")

            scodes = ctx.read.csv(latest_scodes_file, header=True).select('S_Code')
            logger.info("read scodes data from path")

            latest_tax_path = latest_hdfs_file(tax_path, pattern='2')
            latest_tax_file = os.path.join(latest_tax_path, "process", "dt_long_cb_key_hh_s.parquet")
            logger.info(f"latest taxonomy file: {latest_tax_file}")

            tax_df = ctx.read.parquet(latest_tax_file).select('cb_key_household', 'S_Code').distinct()
            tax_df.cache().count()
            logger.info("read taxonomy data")

            tax_with_aud_scodes = tax_df.join(F.broadcast(scodes), 'S_Code', 'inner')        
            logger.info("joined tax data with audigent scodes")

            update_stats(
                quick_stats, "Available Taxonomy SCodes", "Success", 
                f"Latest Audigent Scodes File: {latest_scodes_file}; Latest Taxonomy file: {latest_tax_file}; Found {tax_with_aud_scodes.count():,} Audigent CBKey-Scode records that are available in Taxonomy")        
        except Exception as e:
            update_stats(quick_stats, "Available Taxonomy SCodes", "Failed", str(e))
            raise
            
        try:
            cbk_with_scodes = (
                tax_with_aud_scodes
                .groupby('cb_key_household')
                .agg(F.collect_list('S_Code').alias('S_Code'))
                .withColumn('SEGID', F.concat_ws(',', 'S_Code')).drop('S_Code')
            )
            logger.info("grouped tax data by cb_key_household and aggregated scodes")

            matchid_with_scodes = (
                lookup
                .join(cbk_with_scodes, 'cb_key_household', 'inner')
                .drop('cb_key_household')
                .withColumnRenamed('SEGID', 's_code')
            )
            logger.info("joined lookup data to get matchids with scodes")

            matchid_with_scodes.write.parquet(out_path, mode='overwrite')
            logger.info(f"written output to path: {out_path}")

            update_stats(quick_stats, "MatchId with SCodes", "Success", f"Found {matchid_with_scodes.count():,} Audigent MatchIds with SCodes and written out to path: {out_path}")
        except Exception as e:
            update_stats(quick_stats, "MatchId with SCodes", "Failed", str(e))
            raise

        success_flag = True

    except Exception as e:
        logger.error(e)
        success_flag = False
        send_status_email("Error: aud01_hh_with_scodes script failed", e, email_to)
        raise
    finally:
        alerts_df = pd.DataFrame(quick_stats)    
        email_sub = f"***AUD01 - Generate Audigent MatchIds with Scodes - {STATUS_EMOJIS['green']}***" if success_flag else f"***AUD01 - Generate Audigent MatchIds with Scodes - {STATUS_EMOJIS['red']}***"
        send_teams_email(mask, email_sub, alerts_df.to_html(index=False))
        endtime = datetime.now()
        logger.info(f"process completed in {str(endtime - startime).split('.')[0]}")


if __name__ == "__main__":
    ## Setup Args
    parser = argparse.ArgumentParser()
    parser.add_argument("-m", "--mask", help="date on which process is run in format YYYY-MM-DD", default=TODAY_DATE)
    parser.add_argument("-ilp", "--idg_lookup_path", help="idgraph parent lookup file path", default=LOOKUP_FILE_PATH)
    parser.add_argument("-sp", "--scodes_path", help="parent hdfs file path containing scodes for audigent", default=f"{AUD_PATH_HDFS}/*/")
    parser.add_argument("-tp", "--tax_path", help="parent hdfs file path for taxonomy file", default=TAX_PATH)
    parser.add_argument("-op", "--out_path", help="cleaned audigent scodes are written out to this hdfs file path")
    parser.add_argument("-et", "--email_to", help="recipients of email alerts", default=EMAIL_TO)

    args = parser.parse_args()

    if args.out_path is None:
        args.out_path = f"{AUD_PATH_HDFS}/{args.mask}/matchid_with_scodes__{datetime.now().strftime('%H-%M-%S')}.parquet"


    ## Setup Spark and logging
    name = os.path.basename(__file__)
    logger = LogConfig(f"{LOGPATH}/{name}_{args.mask}.log").generate_logger(name)
    spark = SparkSession.builder.appName(f"{name}_{args.mask}").getOrCreate()

    ## Process starts here
    logic_main(spark, logger, args.mask, args.idg_lookup_path, args.scodes_path, args.tax_path, args.out_path, args.email_to)