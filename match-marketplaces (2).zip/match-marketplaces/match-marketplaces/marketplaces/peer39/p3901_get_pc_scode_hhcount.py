import pandas as pd
import sys
from pathlib import Path
import argparse
import os
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from datetime import datetime

sys.path.append(str(Path(__file__).resolve().parents[2]))

from config import LogConfig, LOGPATH, TODAY_DATE, IDG_PATH, TAX_PATH, P39_PATH_HDFS, EMAIL_TO, STATUS_EMOJIS
from functions import latest_hdfs_file, send_status_email, update_stats, send_teams_email


def format_idg_pc(df):
    """
    Format PC Graph
    """
    return(
        df
        .select(F.col('postcode_mm_standard').alias('pc'))
        .withColumn('pccomp', F.regexp_replace(F.col('pc'), " ", ""))
        .withColumn('ps', F.substring('pc', 1, 6))
    )


def get_pc_taxonomy(taxdf):
    """
    Extract cbkey and mailable postcodes from Taxonomy data
    """
    return (
        taxdf
        .select('cb_key_household', 'mailable_postcode')
        .distinct()
        .withColumn('pccomp', F.regexp_replace(F.col('mailable_postcode'), " ", ""))
        .drop('mailable_postcode')
    )


def logic_main(ctx, logger, mask, idg_path, tax_path, scode_lookup_path, cbk_pc_path, out_path, email_to):
    logger.info(f"running p3901_get_pc_scode_hhcount script for mask: {mask}")
    quick_stats = []

    try:
        startime = datetime.now()
        try:
            latest_pc_path = latest_hdfs_file(f"{idg_path}/pc/*/process", pattern='cv_postcode_dominants')
            logger.info(f"latest pc dominants file: {latest_pc_path}")
            
            idg_pc_df = ctx.read.parquet(latest_pc_path)
            logger.info("read pc dominants data from hdfs")

            idg_pc_fmt = format_idg_pc(idg_pc_df)
            idg_pc_fmt.cache().count()
            logger.info("formatted pc dominants data")

            update_stats(quick_stats, "Load PC Dominants Data", "Success", f"Found {idg_pc_df.count():,} postcodes in pc dominants data read from : {latest_pc_path} and formatted it")
        except Exception as e:
            update_stats(quick_stats, "Load PC Dominants Data", "Failed", str(e))
            raise

        try:
            latest_tax_path = latest_hdfs_file(tax_path, pattern='2')
            latest_tax_file = os.path.join(latest_tax_path, "process", "taxonomy.parquet")
            logger.info(f"latest taxonomy file: {latest_tax_file}")

            tax_df = ctx.read.parquet(latest_tax_file)
            logger.info("read taxonomy data")

            tax_cbkey_pc = get_pc_taxonomy(tax_df)            
            logger.info("extracted cbkey and mailable postcodes from Taxonomy data")

            cbk_pc = tax_cbkey_pc.join(idg_pc_fmt, on='pccomp', how='inner').select('cb_key_household', 'ps')
            cbk_pc.cache()
            logger.info("joined taxonomy data with pc graph")

            cbk_pc.write.parquet(cbk_pc_path, mode="overwrite")
            logger.info(f"written out cbkey-pc data to {cbk_pc_path}")

            update_stats(quick_stats, "Extract PC-HH from Taxonomy", "Success", f"Extracted {tax_cbkey_pc.count():,} combinations of CBK-PC in taxonomy read from : {latest_tax_file}, matched {cbk_pc.count():,} records in pc dominants data, wrote out to {cbk_pc_path}")
        except Exception as e:
            update_stats(quick_stats, "Extract PC-HH from Taxonomy", "Failed", str(e))
            raise

        try:            
            latest_tax_long_file = os.path.join(latest_tax_path, "process", "dt_long_cb_key_hh_s.parquet")
            logger.info(f"latest taxonomy long format file: {latest_tax_long_file}")

            tax_long_df = ctx.read.parquet(latest_tax_long_file).select('cb_key_household', 'S_Code')            
            logger.info("read taxonomy long format data and extrated scodes with their count")

            cbk_pc_scodes = tax_long_df.join(cbk_pc, 'cb_key_household', 'inner')
            cbk_pc_scodes.cache()
            logger.info("joined taxonomy long format data with cbkey-pc data to get scodes for a given cbkey-pc combination")

            update_stats(quick_stats, "Get SCodes for CBkey-PC", "Success", f"Created {cbk_pc_scodes.count():,} Cbkey-PC-SCode records for {cbk_pc.count():,} CBKey-PC combinations")            
        except Exception as e:            
            update_stats(quick_stats, "Get SCodes for CBkey-PC", "Failed", str(e))
            raise

        try:            
            pc_scodes = cbk_pc_scodes.groupby('S_Code', 'ps').count().withColumnRenamed('count', 'shh')
            logger.info("grouped scodes by postcode and counted the number of households")

            available_pc_hh = cbk_pc.groupby('ps').count().withColumnRenamed('count', 'hh')
            logger.info("grouped cbkey-pc data from taxonomy by postcode and counted the number of households")

            hh_per_pc_scode = pc_scodes.join(available_pc_hh, 'ps', 'inner')
            hh_per_pc_scode.cache().count()
            logger.info("identified count of households per postcode and scode")

            latest_lookup_file = latest_hdfs_file(scode_lookup_path, pattern='metadata')
            logger.info(f"latest scode lookup file: {latest_lookup_file}")

            lookup_data = spark.read.csv(latest_lookup_file, header=True).select('S_Code')
            logger.info("read scode lookup data")

            pc_scode_hh = lookup_data.join(hh_per_pc_scode, 'S_Code', 'inner')
            logger.info("joined peer39 scodes with postcode-scode household count data")

            pc_scode_hh.write.parquet(out_path, mode='overwrite')
            logger.info(f"written out postcode-scode with household count to {out_path}")
            
            update_stats(quick_stats, "Postcode-SCode Household Count", "Success", f"Available postcodes :{available_pc_hh.count():,}; Available scode-ccodes {lookup_data.count():,} from {latest_lookup_file}; Wrote {hh_per_pc_scode.count():,} PC-SCode records to {out_path}")
        except Exception as e:            
            update_stats(quick_stats, "Postcode-SCode Household Count", "Failed", str(e))
            raise

        success_flag = True        
    except Exception as e:
        logger.error(e)
        success_flag = False
        send_status_email("Error: p3901_get_pc_scode_hhcount script failed", e, email_to)
        raise
    finally:
        alerts_df = pd.DataFrame(quick_stats)    
        email_sub = f"***P3901 - Get PC-Scode HH Data - {STATUS_EMOJIS['green']}***" if success_flag else f"***P3901 - Get PC-Scode HH Data - {STATUS_EMOJIS['red']}***"
        send_teams_email(mask, email_sub, alerts_df.to_html(index=False))
        endtime = datetime.now()
        logger.info(f"process completed in {str(endtime - startime).split('.')[0]}")


if __name__ == "__main__":
    ## Setup Args
    parser = argparse.ArgumentParser()

    parser.add_argument("-m", "--mask", help="date on which process is run in format YYYY-MM-DD", default=TODAY_DATE)
    parser.add_argument("-igp", "--idg_path", help="idgraph parent path", default=IDG_PATH)
    parser.add_argument("-tp", "--tax_path", help="parent hdfs file path for taxonomy file", default=TAX_PATH)
    parser.add_argument("-slp", "--scode_lookup_path", help="parent hdfs file path for scode lookup data", default=f"{P39_PATH_HDFS}/*/")
    parser.add_argument("-et", "--email_to", help="recipients of email alerts", default=EMAIL_TO)
    parser.add_argument("-cbkpc", "--cbk_pc_path", help="cbkeys and their associated postcodes are written out to this hdfs file path")
    parser.add_argument("-op", "--out_path", help="peer39 pc-scode hh count data is written out to this hdfs file path")

    args = parser.parse_args()

    if args.cbk_pc_path is None:
        args.cbk_pc_path = f"{P39_PATH_HDFS}/{args.mask}/cbk_pc_{datetime.now().strftime('%H-%M-%S')}.parquet"

    if args.out_path is None:
        args.out_path = f"{P39_PATH_HDFS}/{args.mask}/pc_scodes_hhcount__{datetime.now().strftime('%H-%M-%S')}.parquet"

    ## Setup Spark and logging
    name = os.path.basename(__file__)
    logger = LogConfig(f"{LOGPATH}/{name}_{args.mask}.log").generate_logger(name)
    spark = SparkSession.builder.appName(f"{name}_{args.mask}").getOrCreate()

    ## Process starts here
    logic_main(spark, logger, args.mask, args.idg_path, args.tax_path, args.scode_lookup_path, args.cbk_pc_path, args.out_path, args.email_to)