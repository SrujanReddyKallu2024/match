import pandas as pd
import sys
from pathlib import Path
import argparse
import os
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from datetime import datetime
import time

sys.path.append(str(Path(__file__).resolve().parents[2]))

import config
import functions

def check_weird_codes(df, column_name, logger):
    weird_codes = df[column_name].where(df[column_name].str.contains("xa", regex=False)).dropna().to_list()
    weird_codes = [code for code in weird_codes if "\\" in code]
    logger.info(f"checking for weird codes in {column_name}")
    if len(weird_codes) > 0:
        logger.error(f"found weird codes in {column_name}: {weird_codes}")
        raise ValueError(f"found weird codes in {column_name}: {weird_codes}")

def replace_characters(df, column_name, char_replacements, trim_edges=True):
    for char, replacement in char_replacements.items():
        df[column_name] = df[column_name].str.replace(char, replacement, regex=False)
        if trim_edges: df[column_name] = df[column_name].str.strip()


def format_metadata(df, df_postcode_list, logger, country):
    """
    Format the marketplace file based on desired format
    """
    df1 = (
        df[
            ["Segment ID","Segment Name","Data Provider","Segment Description","Use Restrictions","Custom","Price ($CPM)","TTL","SPI Indicator"]
        ].rename({
          #  "Segment ID": "ElementId", .... TODO
        },axis=1)
    )


    df1.replace(r"N/A","",inplace=True)
    df2 = df1[df1["Segment ID"].str.match(f"{country}\d+")].copy()

    char_replacements = {
        "\\xa3": "£",
        "\\xa0": " "
    }

    replace_characters(df2, "Segment Name", char_replacements)
    replace_characters(df2, "Segment Description", char_replacements)

    check_weird_codes(df2, "Segment Name", logger)
    check_weird_codes(df2, "Segment Description", logger)

    df2['num'] = df2["Segment ID"].str.replace(country,"").astype("int")
    df2.sort_values("num",inplace=True)
    df2.drop(columns=["num"],inplace=True)
    df3 = pd.concat([df2, pd.DataFrame([{"Segment ID": pc, "Segment Name": f"{country} > Postcode {pc}", "Data Provider": "Experian", "Segment Description": pc, "TTL": 14, "Geo":"postal"} for pc in df_postcode_list])])
    df3.replace(r"N/A","",inplace=True)
    return df3


def logic_main(ctx, logger, mask, latest_mkp_file, audience_postcode_list, out_local_path, email_to, country):
    logger.info(f"running fwg00_generate_metadata script for mask: {mask}")
    quick_stats = []

    try:
        startime = datetime.now()
        try:
            
            if not latest_mkp_file.endswith("xlsx"):
                raise ValueError("Input file is not an excel file")
            
            logger.info(f"latest fwgeo file: {latest_mkp_file}")            

            input_df = pd.read_excel(latest_mkp_file, sheet_name="Experian Taxonomy", skiprows=0)


            functions.update_stats(quick_stats, "FW GEO Metadata Input", "Success", f"Found total of {input_df.shape[0]:,} rows in from Path: {latest_mkp_file}")



            postcode_list = spark.read.csv(audience_postcode_list)
            print(postcode_list)
            postcode_list = postcode_list.withColumnRenamed("_c0","postcode").select("postcode").toPandas()["postcode"].tolist()
            
            functions.update_stats(quick_stats, "FW GEO Metadata Input", "Success", f"Found total of {len(postcode_list):,} rows in from Path: {audience_postcode_list}")


            logger.info("read data from marketplace file")

        except Exception as e:
            functions.update_stats(quick_stats, "FW GEO Metadata Input", "Failed", str(e))
            raise
            
        try:
            df_formatted = format_metadata( input_df , postcode_list, logger, country)
            logger.info(f"formatted input data and filtered out non-country segments, current count: {df_formatted.shape[0]:,} rows")            
            
            output_file = f"{out_local_path}/{config.FWG_METADATA_FILENAME.format(country_code=country.lower(), YYYYMMddHHmmss=datetime.now().strftime('%Y%m%d%H%M%S'))}"
            df_formatted.to_csv(output_file, index=False)
            logger.info(f"saved formatted data to local path: {out_local_path}")            

            functions.update_stats(quick_stats, "FW GEO Metadata Output", "Success", f"Formatted and saved {df_formatted.shape[0]:,} rows to local path: {out_local_path}")
        except Exception as e:
            functions.update_stats(quick_stats, "FW GEO Metadata Output", "Failed", str(e))
            raise
        success_flag = True
    except Exception as e:
        logger.error(e)
        success_flag = False
        functions.send_status_email("Error: fwg00_generate_metadata script failed", e, email_to)
        raise
    finally:
        alerts_df = pd.DataFrame(quick_stats)    
        email_sub = f"***FWG00 - Generate FW GEO metadata - {config.STATUS_EMOJIS['green']}***" if success_flag else f"***FWG00 - Generate FW GEO metadata - {config.STATUS_EMOJIS['red']}***"
        functions.send_teams_email(mask, email_sub, alerts_df.to_html(index=False), email_to=email_to)
        endtime = datetime.now()
        logger.info(f"process completed in {str(endtime - startime).split('.')[0]}")

def setup_parser():
    parser = argparse.ArgumentParser()
    parser.add_argument("-m", "--mask", help="date on which process is run in format YYYY-MM-DD", default=config.TODAY_DATE)    
    parser.add_argument("-lmf", "--latest_mkp_file", help="file path of the actual file", required=True)    
    parser.add_argument("-apl", "--audience_postcode_list", help="file path of the audience postcode list", required=True)            
    parser.add_argument("-olp", "--out_local_path", help="formatted marketplace file sent to local file path", required=True)
    parser.add_argument("-et", "--email_to", help="recipients of email alerts", default=config.EMAIL_TO)
    parser.add_argument("-c", "--country", help="country code to filter out segments", required=True)
    return parser

if __name__ == "__main__":
    ## Setup Args
   
    parser = setup_parser()
    config_parser = config.setup_parser()
    
    # Manually add each argument from config.py to the main parser
    for action in config_parser._actions:
        parser._add_action(action)  # This adds the arguments from config.py
    
    args, unknown = parser.parse_known_args()

    ## Setup Spark and logging
    name = os.path.basename(__file__)
    logger = config.LogConfig(f"{config.LOGPATH}/{name}_{args.mask}.log").generate_logger(name)
    spark = SparkSession.builder.appName(f"{name}_{args.mask}").getOrCreate()

    # needs to be uppercase
    args.country = args.country.upper()

    ## Process starts here
    logic_main(spark, logger, args.mask, args.latest_mkp_file, args.audience_postcode_list, args.out_local_path, args.email_to, args.country)

# testing command
# note country code is DE because the data is for Germany, but the test files say TS
# docker run -it --rm -v %cd%:/hello -e PYTHONPATH=/hello/marketplaces -w /hello pysparktestboto /opt/spark/bin/spark-submit /hello/marketplaces/freewheelgeo/fwg00_generate_metadata.py -m 2025-03-03 -lmf testing/data/local/data/data_from_sts/marketplace_input_files/fwgeo_marketplacefile_ts_2025-03-03.xlsx -apl testing/data/local/data/data_from_sts/freewheelgeo/fwgeo_marketplace_ts_20202020.csv -c DE --email_to robin.potter@experian.com -olp testing/data/local/data/data_to_sts/freewheelgeo
#
# some of the automation can be tested up to a point:
# docker run -u 0 -it --rm -v %cd%\testing\data\local\data:/data -v %cd%:/home/unity/match-marketplaces -e PATH=/opt/java/openjdk/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/opt/spark/bin -w /home/unity/match-marketplaces pysparktestboto3 bash
# . bash_scripts/triggers/fwgeo_trigger.sh
# trigger_fwgeo_generation
