import pandas as pd
import sys
from pathlib import Path
import argparse
import os
from pyspark.sql import SparkSession, Window
import pyspark.sql.functions as F
import pyspark.sql.types as T
from datetime import datetime
import time

sys.path.append(
    str(Path(__file__).resolve().parents[2])
)  # should be setting PYTHONPATH

import config
import functions


def dedupe(df, id_column, date_column="date", has_source=True, top=1):
    """Create deduped ip_graph data frame"""
    if has_source:
        window_spec = Window.partitionBy(id_column).orderBy(
            F.desc(date_column), F.desc("source_count")
        )
        df = df.withColumn("source_count", F.size(F.split("source", r",")))
    else:
        window_spec = Window.partitionBy(id_column).orderBy(F.desc(date_column))

    df_with_row_num = df.withColumn("row_num", F.row_number().over(window_spec))
    return df_with_row_num.filter(F.col("row_num") <= top).drop("row_num")


def logic_main(
    spark,
    logger,
    mask,
    email_to,
    output_folder,
    out_local_path,
    metadata_path,
    segment_prefix,
    days_filter=30,
    debug=False,
):
    logger.info(f"running {__file__} script for mask: {mask}")
    quick_stats = []

    ### find most recent match2/taxonomy/*/process/dt_long_cb_key_hh_s.parquet    segments
    ### find recent "id_graph/lookup/experian/match_id_lookup_experian_*.parquet" matchid
    ### find most recent ip graph id_graph/graphs/ip/ip_*.parquet                 ip_graph
    ### find recent taxonomy file                                       segments list

    try:
        startime = datetime.now()
        try:
            section_name = "Discover Files"

            data_sets = ["maids", "uid", "ttdids"]
            graph_files = {}

            if not functions.platform.is_hdfs:
                logger.info("running in local mode")
                for id in data_sets:
                    graph_files[id] = functions.latest_local_file(
                        f"{config.IDG_GRAPH_PATH}/{id}",
                        pattern="parquet",
                        dateformat="%Y%m%d%H%M",
                        isdir=functions.platform.is_docker,
                    )
                    logger.info(f"found {id} graph: {graph_files[id]}")

                experian_taxonomy = os.path.join(
                    functions.latest_local_file(
                        config.TAX_PATH, pattern="20", dateformat="%Y-%m-%d", isdir=True
                    ),
                    "process",
                    "dt_long_cb_key_hh_s.parquet",
                )

                match_id_hh_key = functions.latest_local_file(
                    config.FW_MATCH_ID,
                    "match_id_lookup_experian",
                    dateformat="%Y%m%d%H%M",
                    isdir=True,
                )

                taxonomy = functions.latest_local_file(
                    metadata_path,
                    pattern="ttdid_marketplacefile",
                    dateformat="%Y-%m-%d",
                )

            else:

                for id in data_sets:
                    graph_files[id] = functions.latest_hdfs_file(
                        f"{config.IDG_GRAPH_PATH}/{id}"
                    )
                    logger.info(f"found {id} graph: {graph_files[id]}")

                experian_taxonomy = os.path.join(
                    functions.latest_hdfs_file(config.TAX_PATH),
                    "process",
                    "dt_long_cb_key_hh_s.parquet",
                )

                match_id_hh_key = functions.latest_hdfs_file(
                    config.FW_MATCH_ID, "match_id_lookup_experian"
                )

                taxonomy = functions.latest_hdfs_file(metadata_path, pattern="ttdid_marketplacefile")

            logme = f"{','.join([f'{id}: {graph_files[id]}' for id in data_sets])}"

            logger.info(
                f"found files: "
                f"{logme}"
                f"experian_taxonomy: {experian_taxonomy},"
                f"match_id_hh_key: {match_id_hh_key},"
                f"ttdids_taxonomy: {taxonomy}"
            )

            ding = ",\n"  # added to add in a new line for the email, backslash character is not allowed in f-strings
            functions.update_stats(
                quick_stats,
                section_name,
                "Success",
                f"{logme.replace(',',ding)},\n"
                f"experian_taxonomy: {experian_taxonomy},\n"
                f"match_id_hh_key: {match_id_hh_key},\n"
                f"ttdids_taxonomy: {taxonomy}",
            )

        except Exception as e:
            functions.update_stats(quick_stats, section_name, "Failed", str(e))
            raise

        # load segments data as hh_scode
        # load  taxonomy csv as taxonomy
        # giant select/filter (taxonomy) on hh_scode as df_hh_scode_extract
        try:

            section_name = "Load Data"
            graph_data = {}

            for id in data_sets:
                graph_data[id] = (
                    spark.read.parquet(graph_files[id])
                    .withColumn("date", F.to_date(F.col("date").cast(T.DateType())))
                    .filter((F.col('date') > F.date_sub(F.current_date(), days_filter)))
                    .withColumn("match_num", F.col("match_id").cast("bigint"))
                    .drop("match_id")
                    .withColumnRenamed("match_num", "match_id")
                    .repartition("match_id")
                    # .cache()
                )
                logger.info(f"found {id} graph: {graph_data[id]}")
                graph_data[id] = functions.writetemp(spark, graph_data[id], f"df_{id}_graph")
                logger.info(f"re-written {id} graph data with integer match_id to temp storage")

            df_experian_taxonomy = spark.read.parquet(experian_taxonomy)
            logger.info("read taxonomy data")

            df_taxonomy = (
                spark.read.option("quote", '"')
                .option("multiline", True)
                .option("escape", '"')
                .csv(taxonomy, header=True)
            )

            if debug:
                functions.logdf(df_taxonomy)

            df_taxonomy = df_taxonomy.toPandas()

            df_match_id_hh_key = (
                spark.read.parquet(match_id_hh_key)
                .withColumn("match_num", F.col("match_id").cast("bigint"))
                .drop("match_id")
                .withColumnRenamed("match_num", "match_id")
            )

            logger.info("read match id data")

            for df in graph_data:
                logger.info(f"count of {df}: {graph_data[df].count()}")

            if debug:
                df_maids_graph = graph_data["maids"]
                df_ttdids_graph = graph_data["ttdids"]
                df_uid_graph = graph_data["uid"]
                functions.logdf(df_maids_graph)
                functions.logdf(df_ttdids_graph)
                functions.logdf(df_uid_graph)

            if debug:
                functions.logdf(df_experian_taxonomy)
            if debug:
                functions.logdf(df_match_id_hh_key)
            if debug:
                logger.info(df_taxonomy)

            s_codes = (
                df_taxonomy["ElementId"]
                .str.replace(segment_prefix, "")
                .astype(int)
                .to_list()
            )
            audiences = [f"{segment_prefix}{s:07}" for s in s_codes]
            s_codes2 = [f"S{s}" for s in s_codes]
            logger.info(f"found {s_codes}")
            logger.info(f"found {audiences}")

            logger.info(
                f"count of df_experian_taxonomy: {df_experian_taxonomy.count()}"
            )
            df_hh_scode_extract = (
                df_experian_taxonomy.filter(F.col("S_Code").isin(s_codes2))
                .withColumn("S_Code2", F.col("S_Code").substr(2, 7).cast("int"))
                .drop("S_Code")
                .withColumnRenamed("S_Code2", "S_Code")
                .select("cb_key_household", "S_Code")
            )

            df_matchid_scode_extract = df_hh_scode_extract.join(
                df_match_id_hh_key, on="cb_key_household", how="left"
            ).drop("cb_key_household")

            df_matchid_scode_extract = functions.writetemp(
                spark,
                df_matchid_scode_extract.repartition("match_id","S_Code"),
                "df_matchid_scode_extract",
                partitionBy="S_Code",
            )

            df_matchid_scode_extract = df_hh_scode_extract.join(
                df_match_id_hh_key, on="cb_key_household", how="left"
            ).drop("cb_key_household")

            df_matchid_scode_extract = functions.writetemp(
                spark,
                df_matchid_scode_extract,
                "df_matchid_scode_extract",
                partitionBy="S_Code",
            )

            df_matchid_scode_extract = df_hh_scode_extract.join(
                df_match_id_hh_key, on="cb_key_household", how="left"
            ).drop("cb_key_household")

            df_matchid_scode_extract = functions.writetemp(
                spark,
                df_matchid_scode_extract,
                "df_matchid_scode_extract",
                partitionBy="S_Code",
            )

            # make sure we only get s_codes that are in the data
            real_s_codes = (
                df_matchid_scode_extract.select("S_Code").distinct().collect()
            )
            real_s_codes = [r["S_Code"] for r in real_s_codes]

            if debug:
                functions.logdf(df_matchid_scode_extract)

            logger.info(
                f"cached df_matchid_scode_extract with count: {df_matchid_scode_extract.count()}"
            )

            logger.info("data loaded")

            functions.update_stats(
                quick_stats,
                section_name,
                "Success",
                f"loaded:\n"
                f"df_match_id_hh_key ({df_match_id_hh_key.count()}),\n"
                f"df_maids_graph ({graph_data['maids'].count()}),\n"
                f"df_ttdids_graph ({graph_data['ttdids'].count()}),\n"
                f"df_uid_graph ({graph_data['uid'].count()}),\n"
                f"df_experian_taxonomy ({df_experian_taxonomy.count()}),\n"
                f"and used df_taxonomy to create df_matchid_scode_extract ({df_matchid_scode_extract.count()})",
            )
        except Exception as e:
            functions.update_stats(quick_stats, section_name, "Failed", str(e))
            raise

        # load ip data as input_ip_graph

        # load match id graph lookup as match_id_hh_key
        # window sorted by descending last_seen and descending count of source take top 1 as df_ip_graph

        # Define the window specification
        #! window_spec = Window.partitionBy("key1", "key2").orderBy(F.desc("val1"), F.desc("val2"))
        # Add a row number to each row within the window
        #! df_with_row_num = input_ip_graph.withColumn("row_num", F.row_number().over(window_spec))
        # Filter to keep only the first row in each window partition
        #! df_ip_graph = df_with_row_num.filter(F.col("row_num") <= 5).drop("row_num")

        # match df_ip_graph to match_id_hh_key as df_graph
        # match df_graph to df_hh_scode_extract

        deduped = {}

        #for id, df, lkup in zip(
        for id in data_sets:
            try:

                logger.info(f"processing {id}")

                section_name = "Dedupe ID/Match graph"
                logger.info(f"deduping {id} graph")

                deduped[id] = functions.writetemp(
                    spark,
                    dedupe(graph_data[id].select(id, "date", "source", "match_id"), id).select(
                        "match_id", id
                    ),
                    f"deduped_{id}_graph",
                ).repartition("match_id")

                logger.info("deduped id graph")

                functions.update_stats(
                    quick_stats,
                    "TTD Output Data",
                    "Success",
                    f"Found {deduped[id].count():,} deduped rows in {id}",
                )
            except Exception as e:
                functions.update_stats(quick_stats, "TTD Output Data", "Failed", str(e))
                raise

            try:

                section_name = "Join and Extract"
                logger.info(f"joining {id} graph to s_codes")

                total = len(s_codes)
                total_duration = 0
                so_far = 0
                import time
                chunk_size = 1000000

                if debug:
                    _deduped = deduped[id]
                    functions.logdf(_deduped)

                for s in real_s_codes:
                    logger.info(f"processing s_code: {s} for {id}")
                    starting = time.time()
                    temp = (
                        df_matchid_scode_extract.filter(F.col("S_Code") == s)
                        .join(
                            deduped[id].select(id, "match_id"),
                            on="match_id",
                            how="inner",
                        )
                        .select(id)
                        #.withColumnRenamed(id, "monotonic_id")
                        .distinct()
                    )

                    if debug:
                        functions.logdf(temp)

                    try:
                        rdd = temp.rdd.zipWithIndex().map(lambda x: (x[1],) + x[0])
                        temp = rdd.toDF(["chunk"] + temp.columns)
                        temp = temp.withColumn("chunk", F.col("chunk")/chunk_size)
                        temp = temp.withColumn("chunk", F.col("chunk").cast("int"))

                        ( temp
                            .write
                            .partitionBy("chunk")
                            .csv(
                                f"{output_folder}/{id}/S_Code={s}",
                                header=False,
                                compression="gzip", mode="overwrite"
                            )
                        )
                    except Exception as e:
                        logger.error(f"failed to write file for audience: {s} error: {e}")
                        if not debug:
                            raise

                    ending = time.time()
                    so_far = so_far + 1
                    duration = ending - starting
                    total_duration += duration
                    average_duration = total_duration / so_far
                    remaining = (total - so_far) * average_duration
                    units = "s"
                    if remaining > 60:
                        remaining = remaining / 60
                        units = "min"
                        if remaining > 60:
                            remaining = remaining / 60
                            units = "hr"

                    if so_far < 5:
                        logger.info(
                            f"written file for audience: {s}: {output_folder}/{id}/S_Code={s}, time remaining: ..."
                        )
                    else:
                        logger.info(
                            f"written file for audience: {s}: {output_folder}/{id}/S_Code={s}, time remaining: {remaining:.2f}{units}"
                        )

                    # hdfs_file_path = f"{output_folder}/{id}/{a}"
                    # name = f"Replace.TTDID.{a}.{id}.{config.TTD_TTDIDS_DATE_TIME}.csv"
                    # local_file_path_temp = f"{out_local_path}/tmp/{name}"
                    # if functions.platform.is_local and not os.path.exists(
                    #     f"{out_local_path}/tmp"
                    # ):
                    #     os.mkdir(f"{out_local_path}/tmp")
                    # functions.merge_files(
                    #     hdfs_file_path, local_file_path_temp, functions.platform.is_hdfs
                    # )
                    # logger.info(f"merged files for audience: {a}")

                    # time.sleep(1)

                    # local_file_path = f"{out_local_path}/{name}"
                    # functions.add_header_to_local_file(
                    #     local_file_path_temp, f"{id}", local_file_path
                    # )
                    # logger.info(f"added header to local file for audience: {a}")

                    # all_files.append(1)

                functions.update_stats(
                    quick_stats,
                    section_name,
                    "Success",
                    f"Created output file eg.: {output_folder}/{id}/{s} at {id} level",
                )
            except Exception as e:
                functions.update_stats(quick_stats, section_name, "Failed", str(e))
                raise

        success_flag = True

    except Exception as e:
        logger.error(e)
        success_flag = False
        functions.send_status_email(
            "Error: ti01_generate_data script failed", e, email_to
        )
        raise
    finally:
        alerts_df = pd.DataFrame(quick_stats)
        title = "TI01 - Generate Data"
        email_sub = (
            f"***{title} - {config.STATUS_EMOJIS['green']}***"
            if success_flag
            else f"***{title} - {config.STATUS_EMOJIS['red']}***"
        )
        functions.send_teams_email(
            mask, email_sub, alerts_df.to_html(index=False), email_to=email_to
        )
        endtime = datetime.now()
        logger.info(f"process completed in {str(endtime - startime).split('.')[0]}")


def setup_parser():
    ## Setup Args
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument(
        "-m",
        "--mask",
        help="date on which process is run in format YYYY-MM-DD",
        default=config.TODAY_DATE,
    )
    parser.add_argument(
        "-of",
        "--output_folder",
        required=True,
        help="formatted marketplace file sent to this HDFS file path",
    )
    parser.add_argument("-dbg", "--debug", help="debug mode", action="store_true")
    parser.add_argument(
        "-olp",
        "--out_local_path",
        help="ttd data file per audience is saved to this local path",
        default=config.TTD_TTDIDS_TEMP_LOCAL_PATH,
    )
    parser.add_argument(
        "-md",
        "--metadata_path",
        help="local path to the ttdids marketplace file",
        default=config.MKP_SCODES_PATH_LOCAL,
    )
    parser.add_argument(
        "-sp", "--segment_prefix", help="prefix for the segment id", default="SU"
    )
    parser.add_argument(
        "-df",
        "--days_filter",
        help="number of days to filter the data",
        default=config.TTD_TTDIDS_DAYS_FILTER,
        type=int,
    )
    return parser


if __name__ == "__main__":

    parser = setup_parser()
    config_parser = config.setup_parser()

    # Manually add each argument from config.py to the main parser
    for action in config_parser._actions:
        parser._add_action(action)  # This adds the arguments from config.py

    args, unknown = parser.parse_known_args()

    if len(unknown) > 0:
        raise Exception(f"Unknown arguments passed: {unknown}")

    ## Setup Spark and logging
    name = os.path.basename(__file__)

    logger = config.LogConfig(
        f"{config.LOGPATH}/{name}_{args.mask}.log"
    ).generate_logger(name)
    spark = SparkSession.builder.appName(f"{name}_{args.mask}").getOrCreate()
    spark.sparkContext.setLogLevel("WARN")

    logger.info(f"args are {args}")

    if functions.platform.is_local:
        logger.info(f"running windows or docker, email is {config.EMAIL_TO}")
        if "alerts" in config.EMAIL_TO:
            logger.error(
                f"Email address {config.EMAIL_TO} is not valid in local environment"
            )
            sys.exit(1)

    ## Process starts here
    logic_main(
        spark,
        logger,
        args.mask,
        config.EMAIL_TO,
        args.output_folder,
        args.out_local_path,
        args.metadata_path,
        args.segment_prefix,
        args.days_filter,
        debug=args.debug,
    )


# Testing command
# docker run -it --rm -v %cd%:/hello -e PYTHONPATH=/hello/marketplaces -w /hello pysparktestboto /opt/spark/bin/spark-submit /hello/marketplaces/ttdids/ti01_generate_data.py --mask 2022-03-04 --base_path_hdfs /hello/testing/data/hdfs/user/unity --email_to robin.potter@experian.com --debug --output_folder testing/data/hdfs/match2/marketplaces/ttdids  | findstr /V 25/02
# spark-submit marketplaces/freewheel/ti01_generate_data.py --mask 2022-02-22 --base_path_hdfs /user/unity/testing/data/hdfs/user/unity --email_to robin.potter@experian.com --debug --output_folder testing/data/hdfs/match2/marketplaces/freewheel | grep fw
# spark-submit --master yarn --queue adam marketplaces/freewheel/ti01_generate_data.py --mask $(date +%Y-%m-%d) --email_to robin.potter@experian.com --debug --output_folder /user/unity/fw_testing/data/hdfs/match2/marketplaces/freewheel | grep fw
