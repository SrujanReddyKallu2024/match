from pathlib import Path
import sys
from pyspark.sql import SparkSession, Window
import pyspark.sql.functions as F
import argparse
import time

sys.path.append(str(Path(__file__).resolve().parents[1]))

from config import *
from functions import *


def format_ip_graph(ipg, cutoff):
    """
    format the ip graph
    """    
    return (
        ipg
        .where(F.col('last_seen')> cutoff)
        .withColumn("source_array", F.split(F.col("source"),","))
        .withColumn('source_count', F.size('source_array'))
        .withColumn('chv', F.when(F.array_contains(F.col('source_array'), 'chv'), F.lit(1)).otherwise(F.lit(0)))
        .withColumn('de', F.when(F.array_contains(F.col('source_array'), 'de'), F.lit(1)).otherwise(F.lit(0)))
        .withColumn('uc', F.when(F.array_contains(F.col('source_array'), 'uc'), F.lit(1)).otherwise(F.lit(0)))        
    )


def apply_ip_rank(ipdf):
    winSpec1= (
        Window.partitionBy('match_id')
        .orderBy(
            F.col('last_seen').desc(), \
            F.col('source_count').desc(), \
            F.col('chv').desc(), \
            F.col('de').desc(), \
            F.col('uc').desc() 
        )
    )
    winSpec2= (
        Window.partitionBy('ip')
        .orderBy(
            F.col('last_seen').desc(), \
            F.col('source_count').desc(), \
            F.col('chv').desc(), \
            F.col('de').desc(), \
            F.col('uc').desc(), \
        )
    )
    return (
        ipdf
        .withColumn('rnum', F.row_number().over(winSpec1))
        .where(F.col('rnum')<= 5)
        .withColumn('rnum2', F.row_number().over(winSpec2))
        .where(F.col('rnum2')<= 3)
    )



def logic_main(ctx, logger, mask, idg_graph_path, idg_lookup_path, mid_with_scodes_path, out_path, email_to):
    logger.info(f"running preprocess stats for mask: {mask}")
    try:
        startime = datetime.now()        
        date180= (startime - datetime.timedelta(days= 180)).strftime("%Y-%m-%d")

        ##IP Graph
        idg_ip_file = latest_hdfs_file(f"{idg_graph_path}/ip", pattern='ip')
        logger.info("latest ip graph file: {idg_ip_file}}")

        idg_ip = ctx.read.parquet(idg_ip_file)
        logger.info("read latest ip graph")

        idg_ip_fmt = format_ip_graph(idg_ip, date180)
        logger.info("formatted ip graph")

        idg_ip_ranked = apply_ip_rank(idg_ip_fmt)
        logger.info("ranked ip graph")

        idg_ip_agg = (
            idg_ip_ranked
            .groupby('match_id', 'ip')
            .agg(F.max('last_seen').alias('last_seen'))
        )
        idg_ip_agg.cache().count()
        logger.info("grouped ip graph by match_id and ip and aggregated max last_seen")

        aud_lookup_file = latest_hdfs_file(f"{idg_lookup_path}/audigent", pattern = 'match_id_lookup_audigent')
        logger.info(f"audigent lookup file: {aud_lookup_file}")
        
        aud_lookup = ctx.read.parquet(aud_lookup_file)
        logger.info("read audigent lookup data")

        idg_ip_mids = aud_lookup.join(idg_ip_agg, 'match_id', 'inner').drop("match_id")
        logger.info("joined audigent lookup with ip graph")

        mid_with_scodes_file = latest_hdfs_file(mid_with_scodes_path, pattern='mid_with_scodes')
        logger.info(f"latest matchid with scodes file: {mid_with_scodes_file}")

        mid_with_scodes = ctx.read.parquet(mid_with_scodes_file)
        logger.info("read matchid with scodes data")

        final_idg_ip = (
            idg_ip_mids
            .join(mid_with_scodes, 'match_id_audigent', 'inner')
            .withColumnRenamed('match_id_audigent', 'hh_id')
            .select('hh_id', 'ip', 'last_seen', 's_code')
        )
        logger.info("joined formatted ip graph with matchid with scodes to get final audigent ip graph")

        final_idg_ip.repartition(10).write.csv(out_path, header=True, mode='overwrite', compression='gzip')
        logger.info(f"written output to path: {out_path}")

        time.sleep(60)

        ## Rename it based on Audigent format i.e. UK__experianuk_ipgraph_UK_{mask}_001.csv.gz
        all_ip_files = get_all_files(out_path)
        logger.info(f"all ip files: {all_ip_files}")

        rename_files(logger, mask, all_ip_files, 'ip')        

    except Exception as e:
        logger.error(e)
        send_status_email("Error: aud02_format_ip script failed", e, email_to)
        raise
    finally:
        endtime = datetime.now()
        logger.info(f"process completed in {str(endtime - startime).split('.')[0]}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-m", "--mask", help="date on which process is run in format YYYY-MM-DD", default=TODAY_DATE)
    parser.add_argument("-igp", "--idg_graph_path", help="idgraph parent path", default=IDG_GRAPH_PATH)
    parser.add_argument("-ilp", "--idg_lookup_path", help="idgraph parent lookup file path", default=LOOKUP_FILE_PATH)
    parser.add_argument("-mwsp", "--mid_with_scodes_file", help="parent matchid to scodes file path", default=LOOKUP_FILE_PATH)
    parser.add_argument("-op", "--out_path", help="cleaned audigent scodes are written out to this hdfs csv file path")
    parser.add_argument("-et", "--email_to", help="receipients of email alerts", default=EMAIL_TO)
    

    args = parser.parse_args()

    if args.out_path is None:
        args.out_path = f"{AUD_PATH_HDFS}/{args.mask}/audigent_ip_graph.csv"

    name = os.path.basename(__file__)
    logger = LogConfig(f"{LOGPATH}/{name}_{args.mask}.log").generate_logger(name)
    spark = SparkSession.builder.appName(f"aud02_{args.mask}").getOrCreate()
    logic_main(spark, logger, args.mask)

