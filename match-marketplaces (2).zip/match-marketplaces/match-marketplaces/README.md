## Introduction

This repository contains a collection of scripts and functions for processing and formatting data for marketplaces. The scripts are organized to perform specific tasks, from retrieving data to formatting and generating metadata.

## Design
| Directory/File      | Description                                                                 |
|---------------------|-----------------------------------------------------------------------------|
| `bash_scripts`      | Contains 3 bash scripts: `conf.sh` (configurable parameters), `functions.sh` (bash functions), and `trigger_process.sh` (triggers and runs associated scripts). |
| `garage`            | Contains original marketplace (non-automated) scripts along with disabled ones. |
| `helper_scripts`    | Contains scripts that can help in setting up the metadata.                   |
| `logs`              | Contains all logs of the process.                                            |
| `marketplaces`      | Contains all the marketplace-specific Python/PySpark-based processing scripts. |
| `metadata`          | Contains all the static lookup or marketplace-specific files.                |
| `config.py`         | Contains configuration settings used across the Python/PySpark scripts.      |
| `functions.py`      | Includes common functions used by the Python/PySpark scripts.                |


## Getting Started

1. Clone the repository.
1. Configure the parameters required in all scripts in `config.py`.
1. Run the desired scripts using spark-submit.

## Scripts Overview

### Audigent

- **aud00_generate_metadata.py**: Script to retrieve S-codes for Audigent which is dropped in by client services in /data/data_from_sts/marketplace_input_files and then attach the description from static file, this is sent to Audigent as the taxonomy file
- **aud01_matchid_with_scodes.py**: Script to attach matchids with S-codes using taxonomy and the scodes file
- **aud02_generate_data.py**: Script to format, rank and aggregate ID graphs and then attach Audigent matchids and scodes to them

#### Disabled Scripts

These scripts are currently disabled but can be enabled if needed:

- **disabled_aud01_ORIGINAL.py**: Original audigent script created by Andy
- **disabled_aud02_format_ip.py**: Script to format IP data.
- **disabled_aud03_format_hems.py**: Script to format HEMS data.
- **disabled_aud04_format_maids.py**: Script to format MAIDs data.
- **disabled_aud05_format_uid.py**: Script to format UID data.
- **disabled_aud06_format_ttdids.py**: Script to format TTDIDs data.
- **disabled_aud07_format_appnids.py**: Script to format AppNIDs data.

## Peer39

- **p3900_generate_metadata.py**: Script is used to retrieve the peer39 specific scodes and attach ccodes based on the ccode-scode lookup file
- **p3901_get_pc_scode_hhcount.py**: Script is used to attach scodes to postcode-household data using taxonomy and postcode dominants file and thereafter calculate the household counts per postcode-scode combination
- **p3902_generate_data.py**: Script contains logic to accurately flag postcode specific scodes and finally format data based on peer39 requirements

# Disabled Scripts

- **disabled_peer39_ORIGINAL.py**: Original peer39 script created by Andy

## TTD Geo

This is a process to transform the output delivered by client services and send on to the ttd markplace. No audience is generated, just transformed.

There are two scripts:

- **teug00_generate_metadata.py** - to transform the taxonomy file and copy to the facebook api location
- **teug01_generate_data.py** - transform the file from client services and copy to the facebook api location

## FreeWheel

This generates an audience and taxonomy file from the IP id graph, match to household lookup and the household to scode files. the input and trigger is a fw_marketplace*xlsx file in the /data/data_from_sts/marketplace_input_files:

- **fw00_generate_metadata.py** - reads the metadata.xlsx and spits out csv version (trigger script is used to copy the result to hdfs)
- **fw01_generate_data.py** - reads the metadata (by default uses hdfs path) and extracts the scodes needed from the household to scode file and matches the ips. the ips are validated and split into ip4 and ip6 since freewheel deal with them separately.

## Beeswax

## TTDIDs

for testing on dev

```
spark-submit testing/create-sample.py
cp metadata/ttdid_marketplacefile_2025-02-25.csv /data/data_from_sts/marketplace_input_files/
```

edit ```bash_scripts/triggersttdid_trigger``` for the data generation function and change to add the fake data paths:

```
spark-submit --master yarn --queue $QUEUE1 "${TTDIDS_SCRIPT_DIR}/ti01_generate_data.py" -of $TTDIDS_TEMP_LOCAL_PATH  -m $RUNDATE  --segment_prefix SU -md $TTDIDS_MKT_HDFS_DIR  -md /user/unity/testing/data/hdfs$TTDIDS_MKT_HDFS_DIR  --base_path_hdfs /user/unity/testing/data/hdfs/user/unity
```

source it:

```
. bash_scripts/triggers/ttdid_trigger.sh
```

then run the functions:

```
trigger_metadata_generation
trigger_data_generation





# Notes on local testing FWGEO Testing with docker

The docker image which is fairly close to the servers can be used to test similar to the real thing up to a point:

```
docker run -u 0 -it --rm -v %cd%\testing\data\local\data:/data -v %cd%:/home/unity/match-marketplaces -e PATH=/opt/java/openjdk/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/opt/spark/bin -w /home/unity/match-marketplaces pysparktestboto3 bash
```

to run the process:

```
. bash_scripts/triggers/fwgeo_trigger.sh
```